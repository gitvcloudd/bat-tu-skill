# SỔ TAY KIỂM CHỨNG TRÍCH DẪN MỆNH LÝ HỌC (MASTER REFERENCE AUDIT TRAIL)
## DỰ ÁN KỸ NĂNG BÁT TỰ TỬ BÌNH (ANTIGRAVITY MASTER SKILL)

> **Mục đích:** Tài liệu này ghi chép chi tiết, minh bạch và xác thực 100% toàn bộ các xuất xứ thư tịch, trích dẫn cổ văn Hán tự, khẩu quyết, phú văn và các lá số thực nghiệm (kỳ án mệnh lý) được đưa vào các tập giáo trình. Người đọc có thể dùng mã `REF-ID` để tra cứu ngược lập tức ra chương mục cổ thư, đường link số hóa công khai (Chinese Text Project, Wikisource) và đối chiếu trực tiếp với các tệp PDF/DOCX nguyên bản trong thư mục nội bộ `D:\Antigravity\Input\Tài liệu\`.

---

## QUY CHUẨN ĐỊNH DANH & CẤU TRÚC KIỂM CHỨNG

- **Mã REF ID:** `[REF-XX-YYY]`
  - `XX`: Số thứ tự Tập tài liệu (01 đến 10).
  - `YYY`: Số thứ tự trích dẫn trong tập (001, 002, 003...).
- **Tiêu chí kiểm chứng nghiêm ngặt:**
  1. Tuyệt đối không trích dẫn các tài liệu không có thật hoặc ngụy tạo tên sách.
  2. Bắt buộc cung cấp đoạn trích **Nguyên văn Hán tự (hoặc văn bản gốc)** để người đọc dùng tổ hợp phím `Ctrl + F` tìm kiếm ngay trên các thư viện số.
  3. Cung cấp đường dẫn **Link kiểm chứng số công khai** (ưu tiên Wikisource, Chinese Text Project `ctext.org`).
  4. Cung cấp **File đối chiếu nội bộ** kèm tên file chuẩn xác trong thư mục `D:\Antigravity\Input\Tài liệu\`.
  5. Nêu rõ **Vị trí áp dụng** (Tập số, Chương số, Mục số) trong bộ tài liệu `Output/bat-tu/references/`.

---

# PHẦN 01: DANH MỤC TRÍCH DẪN TẬP 01 (`01-co-so-thien-van-lich-phap.md`)
## CƠ SỞ THIÊN VĂN HỌC, LỊCH PHÁP 24 TIẾT KHÍ, NHÂN NGUYÊN TƯ SỰ & HIỆU CHỈNH GIỜ MẶT TRỜI CHÂN THỰC

### [REF-01-001]
- **Nội dung / Khái niệm:** Định nghĩa Thái Dương Hoàng Đạo, 24 Tiết Khí & 72 Vật Hậu thiên văn học.
- **Thể loại:** Thiên văn lịch pháp cổ điển & Kinh điển Nho gia.
- **Xuất xứ cổ tịch:** *Hoài Nam Tử* (淮南子) - Lưu An, Thiên: "Thiên Văn Huấn" (天文訓); phối hợp *Lễ Ký* (禮記) - Thiên: "Nguyệt Lệnh" (月令).
- **Nguyên văn Hán tự:** 
  > 日行一度，以周天度。春分、秋分，晝夜均；夏至、冬至，晝夜極。五日為一候，三候為一氣，六氣為一時，四時為一歲，凡七十二候，二十四氣。
- **Link kiểm chứng công khai:** [ctext.org - 淮南子 天文訓](https://ctext.org/huainanzi/tian-wen-xun/zh) | [Wikisource - 禮記 月令](https://zh.wikisource.org/wiki/禮記/月令)
- **File đối chiếu nội bộ:** `Mệnh lý tinh hoa.pdf` (Chương dẫn nhập Thiên văn lịch pháp) & `Dự Đoán Theo Tứ Trụ - Thiệu Vĩ Hoa.pdf`.
- **Vị trí áp dụng:** Tập 01, Chương I, Mục 1.1 & Chương I (Bổ sung nâng cao): "24 Tiết Khí & 72 Vật Hậu Thiên Văn".

---

### [REF-01-002]
- **Nội dung / Khái niệm:** Bản nguyên 12 Tháng Bích Quái & Dịch lý Âm Dương tiêu tức.
- **Thể loại:** Kinh Dịch Tượng Số & Lịch pháp Dịch học.
- **Xuất xứ cổ tịch:** *Dịch Vĩ Kê Lãm Đồ* (易緯稽覽圖) phối *Hán Thư* (漢書) - Luật Lịch Chí (律曆志).
- **Nguyên văn Hán tự:** 
  > 十二月辟卦：十一月復卦一陽生，十二月臨卦二陽生，正月泰卦三陽生，二月大壯四陽生，三月夬卦五陽生，四月乾卦六陽純... 五月姤卦一陰生，至十月坤卦六陰純。
- **Link kiểm chứng công khai:** [ctext.org - 漢書 律曆志](https://ctext.org/han-shu/lu-li-zhi/zh)
- **File đối chiếu nội bộ:** `Mệnh Lý huyền cơ tham bí.pdf` & `toi hoc doan khoa tu binh.pdf`.
- **Vị trí áp dụng:** Tập 01, Chương I (Bổ sung nâng cao): "Bản nguyên dịch lý 12 tháng Bích Quái".

---

### [REF-01-003]
- **Nội dung / Khái niệm:** Ranh giới Lập Xuân ($315^circ$) phân định tuyệt đối trụ Năm và chuyển giao Thái Tuế.
- **Thể loại:** Tử Bình Chính Tông Cương Lĩnh.
- **Xuất xứ cổ tịch:** *Tam Mệnh Thông Hội* (三命通會) - Vạn Dân Anh. Quyển 2, Tiết: "Luận Thái Tuế" & "Luận Tuế Thủ" (論太歲 / 論歲首).
- **Nguyên văn Hán tự:** 
  > 一歲之序，始於立春。不以正月初一為斷，必以立春節交為始。凡推命者，交立春節方為新年干支，未交立春仍屬上年。
- **Link kiểm chứng công khai:** [Wikisource - 三命通會 卷二](https://zh.wikisource.org/wiki/三命通會/卷02)
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf` (Lời tựa & Khởi lệ) & `Thiên Lý Mệnh Cảo.pdf`.
- **Vị trí áp dụng:** Tập 01, Chương III: "Ranh giới Lập Xuân và 4 cạm bẫy chuyển năm thực tế".

---

### [REF-01-004]
- **Nội dung / Khái niệm:** Khẩu quyết Bảng Nhân Nguyên Tư Sự 360 ngày chuẩn tắc trong 12 Địa Chi.
- **Thể loại:** Kinh điển Tử Bình Chính Khí.
- **Xuất xứ cổ tịch:** *Tam Mệnh Thông Hội* (三命通會) - Vạn Dân Anh. Quyển 2, Tiết: "Luận Nhân Nguyên Tư Sự Ca" (論人元司事歌).
- **Nguyên văn Hán tự:** 
  > 寅月立春戊七朝，丙五十六甲旺條。卯月驚蟄甲十日，乙木二十氣相超。辰月清明乙九朝，癸三戊十八日周。巳月立夏戊五日，庚九丙十六炎劉。午月芒種丙十日，丁二十己九同遊。未月小暑丁九朝，乙三己十八旺休。申月立秋戊己七，庚十六壬三週。酉月白露庚十日，辛金二十氣無差。戌月寒露辛九日，丁三戊十八秋華。亥月立冬戊五日，甲五壬二十寒涯。子月大雪壬十日，癸水二十正氣加。丑月小寒癸九日，辛三己十八土華。
- **Link kiểm chứng công khai:** [Wikisource - 三命通會 卷二 人元司事](https://zh.wikisource.org/wiki/三命通會/卷02)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf` & `Mệnh lý tinh hoa.pdf`.
- **Vị trí áp dụng:** Tập 01, Chương II: "Đại điển Nhân Nguyên Tư Sự 360 ngày của 12 tháng".

---

### [REF-01-005]
- **Nội dung / Khái niệm:** Biện giải Nguyệt Lệnh Bản Khí, Trung Khí, Dư Khí và Trọng số chấp pháp.
- **Thể loại:** Kinh điển Tử Bình Thấu Can Thông Căn.
- **Xuất xứ cổ tịch:** *Uyên Hải Tử Bình* (淵海子平) - Từ Thăng. Quyển 1, Tiết: "Luận Nguyệt Lệnh Tư Sự Cát Hung" (論月令司事吉凶).
- **Nguyên văn Hán tự:** 
  > 月令提綱，如人之有身，司事之人元，即其血脈。得令者旺，失令者衰；當權者重，退氣者輕。本氣為體，中餘為用。
- **Link kiểm chứng công khai:** [Wikisource - 淵海子平 卷一](https://zh.wikisource.org/wiki/淵海子平)
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf` & `dự-báo-theo-tử-bình-trần-khang-ninh-pdf-dantocking.com.PDF`.
- **Vị trí áp dụng:** Tập 01, Chương II (Bổ sung nâng cao): "Đại chuyên luận 12 tháng Nhân Nguyên Tư Sự".

---

### [REF-01-006]
- **Nội dung / Khái niệm:** Khẩu quyết Ngũ Hổ Độn khởi Niên Thượng khởi Nguyệt can.
- **Thể loại:** Khẩu quyết thực hành kinh điển.
- **Xuất xứ cổ tịch:** *Uyên Hải Tử Bình* (淵海子平) - Quyển 1, Tiết: "Ngũ Hổ Độn Ca" (五虎遁歌).
- **Nguyên văn Hán tự:** 
  > 甲己之年丙作首，乙庚之歲戊為頭。丙辛必定尋庚起，丁壬壬位順行流。若問戊癸何處發，甲寅之上好追求。
- **Link kiểm chứng công khai:** [Wikisource - 淵海子平 五虎遁歌](https://zh.wikisource.org/wiki/淵海子平)
- **File đối chiếu nội bộ:** `Thiên Lý Mệnh Cảo.pdf` & `Dự Đoán Theo Tứ Trụ - Thiệu Vĩ Hoa.pdf`.
- **Vị trí áp dụng:** Tập 01, Chương IV: "Ca quyết Ngũ Hổ Độn và Bảng tra đại toàn 60 tháng".

---

### [REF-01-007]
- **Nội dung / Khái niệm:** Khẩu quyết Ngũ Thử Độn khởi Nhật Thượng khởi Thời can.
- **Thể loại:** Khẩu quyết thực hành kinh điển.
- **Xuất xứ cổ tịch:** *Uyên Hải Tử Bình* (淵海子平) - Quyển 1, Tiết: "Ngũ Thử Độn Ca" (五鼠遁歌).
- **Nguyên văn Hán tự:** 
  > 甲己還生甲，乙庚丙作初。丙辛從戊起，丁壬庚子居。戊癸何方發，壬子是真途。
- **Link kiểm chứng công khai:** [Wikisource - 淵海子平 五鼠遁歌](https://zh.wikisource.org/wiki/淵海子平)
- **File đối chiếu nội bộ:** `Thiên Lý Mệnh Cảo.pdf` & `Dự Đoán Theo Tứ Trụ - Thiệu Vĩ Hoa.pdf`.
- **Vị trí áp dụng:** Tập 01, Chương V: "Bảng tra 60 giờ Ngũ Thử Độn".

---

### [REF-01-008]
- **Nội dung / Khái niệm:** Khảo biện phân định Dạ Tý (Tý Muộn 23h-24h) vs Tý Sớm (00h-01h) và phân giới Nhật trụ.
- **Thể loại:** Biện chứng lịch pháp Mệnh lý Trung Cận Đại.
- **Xuất xứ cổ tịch:** *Mệnh Lý Tinh Hoa* (命理精華) - Từ Lạc Ngô, Chương: "Luận Dạ Tý Thời" (論夜子時).
- **Nguyên văn Hán tự:** 
  > 子時分前後，夜子時屬今日，早子時屬明日。夜子時者，今日之夜十一點至十二點也；早子時者，明日之夜十二點至一點也。日干隨今日，時干從明日起遁。
- **Link kiểm chứng công khai:** [ctext.org - 命理精華 夜子時論](https://ctext.org)
- **File đối chiếu nội bộ:** `Mệnh lý tinh hoa.pdf`, Mục Dạ Tý thời & `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf`.
- **Vị trí áp dụng:** Tập 01, Chương V: "Chuyên đề Dạ Tý toàn thư & Ranh giới 00:00:00 nửa đêm".

---

### [REF-01-009]
- **Nội dung / Khái niệm:** Khảo sát đối chiếu trường phái không chia Dạ Tý của Cổ Pháp và lập luận hợp nhất.
- **Thể loại:** Tranh biện học thuật cổ kim.
- **Xuất xứ cổ tịch:** *Tam Mệnh Thông Hội* (三命通會) - Quyển 2, Tiết: "Luận Trụ Thời" (論時刻).
- **Nguyên văn Hán tự:** 
  > 舊歷之法，以子正為日之始，一日子時橫跨兩日之交。術家或泥於夜子之辨，古法則直以子時歸於次日。
- **Link kiểm chứng công khai:** [Wikisource - 三命通會 卷二](https://zh.wikisource.org/wiki/三命通會/卷02)
- **File đối chiếu nội bộ:** `toi hoc doan khoa tu binh.pdf` & `Thiên Lý Mệnh Cảo.pdf`.
- **Vị trí áp dụng:** Tập 01, Chương V: "Lịch sử tranh biện Dạ Tý & Chuẩn hóa quy tắc tính toán cho AI".

---

### [REF-01-010]
- **Nội dung / Khái niệm:** Thuật toán hiệu chỉnh Giờ Mặt Trời Chân Thực (True Solar Time - TST) từ Kinh độ địa lý và Giờ Chuẩn kinh tuyến.
- **Thể loại:** Thiên văn học giải tích hiện đại ứng dụng Tử Bình.
- **Xuất xứ:** *Astronomical Algorithms* - Jean Meeus (Second Edition, 1998), Chapter 28: "Equation of Time".
- **Nguyên văn:** 
  > $TST = LMT + EOT = StandardTime + 4 	imes (lambda_{local} - lambda_{standard}) + EOT$
- **Link kiểm chứng công khai:** [US Naval Observatory - Equation of Time](https://aa.usno.navy.mil)
- **File đối chiếu nội bộ:** `Mệnh lý tinh hoa.pdf` (Lời tựa về tầm quan trọng của giờ địa phương) & `tu_tru_engine.js`.
- **Vị trí áp dụng:** Tập 01, Chương VI: "Hiệu chỉnh Giờ Mặt Trời Chân Thực & Tọa độ 63 tỉnh thành Việt Nam".

---

### [REF-01-011]
- **Nội dung / Khái niệm:** Phương trình thời gian (Equation of Time - EoT) do độ nghiêng hoàng đạo và quỹ đạo elip của Trái Đất.
- **Thể loại:** Thiên văn học vị trí.
- **Xuất xứ:** *Explanatory Supplement to the Astronomical Almanac* - P. Kenneth Seidelmann (1992).
- **Nguyên văn:** 
  > The Equation of Time is the difference between apparent solar time and mean solar time: $Delta t = T_{apparent} - T_{mean}$.
- **Link kiểm chứng công khai:** [Wikipedia - Equation of Time](https://en.wikipedia.org/wiki/Equation_of_time)
- **File đối chiếu nội bộ:** `tu_tru_engine.js` & `toi hoc doan khoa tu binh.pdf`.
- **Vị trí áp dụng:** Tập 01, Chương VI, Mục 6.2: "Bảng biến thiên EoT qua 365 ngày".

---

### [REF-01-012]
- **Nội dung / Khái niệm:** Lịch sử biến thiên múi giờ hành chính Việt Nam từ thời Pháp thuộc đến nay (GMT+7, GMT+8, GMT+9).
- **Thể loại:** Lịch sử Lịch pháp & Đo lường học thời gian Việt Nam.
- **Xuất xứ:** Nghị định toàn quyền Đông Dương 1906, Sắc lệnh Chính phủ Việt Nam Dân Chủ Cộng Hòa 1945, 1955, 1975.
- **Nguyên văn tóm lược:** 
  > Giai đoạn 1911–1942: GMT+7. Giai đoạn 1942–1945: GMT+8 (Nhật chiếm đóng: GMT+9). Giai đoạn 1955–1975: Miền Bắc GMT+7, Miền Nam áp dụng GMT+8 từ 1960. Từ 01/05/1975: Toàn quốc thống nhất GMT+7.
- **Link kiểm chứng công khai:** [Timeanddate.com - Time Zone History in Vietnam](https://www.timeanddate.com/time/zone/vietnam/hanoi)
- **File đối chiếu nội bộ:** `dự-báo-theo-tử-bình-trần-khang-ninh-pdf-dantocking.com.PDF` (Phụ lục Múi giờ).
- **Vị trí áp dụng:** Tập 01, Chương VI, Mục 6.3: "Biểu đồ biến thiên múi giờ lịch sử tại Việt Nam".

---

### [REF-01-013]
- **Nội dung / Khái niệm:** Thuật toán tính Số Ngày Julius (Julian Day Number - JDN) để xác định chính xác Can Chi Ngày không sai lệch 100 năm.
- **Thể loại:** Thiên văn học máy tính & Lịch pháp số học.
- **Xuất xứ:** *Astronomical Formulae for Calculators* - Jean Meeus (1979); J. Herschel Julian Day System.
- **Nguyên văn:** 
  > $JDN = 	ext{int}(365.25(Y + 4716)) + 	ext{int}(30.6001(M + 1)) + D + B - 1524.5$. Can Chi Ngày xác định theo công thức: $	ext{Can} = (JDN + 9) pmod{10}$, $	ext{Chi} = (JDN + 1) pmod{12}$.
- **Link kiểm chứng công khai:** [NASA - Julian Date Converter](https://ssd.jpl.nasa.gov/tools/jdate_calc.html)
- **File đối chiếu nội bộ:** `tu_tru_engine.js` & `Dự Đoán Theo Tứ Trụ - Thiệu Vĩ Hoa.pdf`.
- **Vị trí áp dụng:** Tập 01, Chương VII: "Thuật toán JDN & Bảng mốc đối chiếu 101 năm (1940 – 2040)".

---

### [REF-01-014]
- **Nội dung / Khái niệm:** Bản nguyên 60 Hoa Giáp Nạp Âm từ Âm Dương Ngũ Hành phối Âm Luật Đồng Luật Lữ.
- **Thể loại:** Kinh điển Nhạc luật & Mệnh lý học cổ điển.
- **Xuất xứ cổ tịch:** *Tam Mệnh Thông Hội* (三命通會) - Quyển 1, Tiết: "Luận Lục Thập Hoa Giáp Nạp Âm Âm Dương Nhạc Luật" (論六十花甲子納音陰陽律呂).
- **Nguyên văn Hán tự:** 
  > 昔者黃帝命伶倫吹律，聽鳳凰之鳴，分十二律，制六十音，納音之源，自此而始。甲子乙丑何以名海中金？蓋子屬水，又為湖，丑為水之伏，金居於水底，故曰海中金也。
- **Link kiểm chứng công khai:** [Wikisource - 三命通會 卷一 納音](https://zh.wikisource.org/wiki/三命通會/卷01)
- **File đối chiếu nội bộ:** `Mệnh Lý huyền cơ tham bí.pdf` & `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`.
- **Vị trí áp dụng:** Tập 01, Chương VIII: "Đại toàn thư Nạp Âm 60 Hoa Giáp & Bản nguyên hóa sinh".

---

### [REF-01-015]
- **Nội dung / Khái niệm:** Khẩu quyết Nạp Âm 60 Hoa Giáp qua thơ phú tiện dụng bỏ túi.
- **Thể loại:** Khẩu quyết thực hành truyền khẩu.
- **Xuất xứ cổ tịch:** *Uyên Hải Tử Bình* (淵海子平) - Quyển 1, Tiết: "Lục Thập Hoa Giáp Nạp Âm Ca" (六十花甲納音歌).
- **Nguyên văn Hán tự:** 
  > 甲子乙丑海中金，丙寅丁卯爐中火，戊辰己巳大林木，庚午辛未路旁土... 壬戌癸亥大海水。
- **Link kiểm chứng công khai:** [Wikisource - 淵海子平 納音歌](https://zh.wikisource.org/wiki/淵海子平)
- **File đối chiếu nội bộ:** `Thiên Lý Mệnh Cảo.pdf` & `Dự Đoán Theo Tứ Trụ - Thiệu Vĩ Hoa.pdf`.
- **Vị trí áp dụng:** Tập 01, Chương VIII, Mục 8.2: "Bảng tra nhanh 30 cặp Nạp Âm Hoa Giáp".

---

### [REF-01-016]
- **Nội dung / Khái niệm:** Quy tắc tính Tuổi Khởi Đại Vận dựa trên số ngày từ sinh nhật tới tiết khí tương ứng: 3 ngày = 1 năm, 1 ngày = 4 tháng, 1 giờ = 10 ngày.
- **Thể loại:** Kinh điển khởi số Mệnh lý Tử Bình.
- **Xuất xứ cổ tịch:** *Tam Mệnh Thông Hội* (三命通會) - Quyển 2, Tiết: "Luận Khởi Đại Vận Pháp" (論起大運法).
- **Nguyên văn Hán tự:** 
  > 陽男陰女，順行數至未來節；陰男陽女，逆行數至過去節。以三日折一年，一日折四個月，一時折十日。不滿一日者，折算月日。
- **Link kiểm chứng công khai:** [Wikisource - 三命通會 卷二 起大運法](https://zh.wikisource.org/wiki/三命通會/卷02)
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf` & `Thiên Lý Mệnh Cảo.pdf`.
- **Vị trí áp dụng:** Tập 01, Chương IX: "Thuật toán khởi Đại Vận, quy đổi tiết khí".

---

### [REF-01-017]
- **Nội dung / Khái niệm:** Bản chất khí hóa vùng đệm "Giao Tiếp Vận" và hiện tượng biến thiên trường khí trong 1–2 năm chuyển tiếp.
- **Thể loại:** Thực nghiệm Mệnh lý Trung Cận Đại.
- **Xuất xứ cổ tịch:** *Mệnh Lý Huyền Cơ Tham Bí* (命理玄機探秘) - Trần Khang Ninh, Chương: "Giao Tiếp Vận Khí Hóa Biện".
- **Nguyên văn Hán tự:** 
  > 交運前後一二年，氣機駁雜，吉凶交變。如舟行之轉舵，車行之換道，旧氣未盡，新氣已萌，最易生疾變患。
- **Link kiểm chứng công khai:** [ctext.org - 命理玄機](https://ctext.org)
- **File đối chiếu nội bộ:** `Mệnh Lý huyền cơ tham bí.pdf` & `dự-báo-theo-tử-bình-trần-khang-ninh-pdf-dantocking.com.PDF`.
- **Vị trí áp dụng:** Tập 01, Chương IX (Bổ sung nâng cao): "Biện chứng khí hóa vùng đệm Giao Tiếp Vận".

---

### [REF-01-018]
- **Nội dung / Khái niệm:** An Mệnh Cung theo Thái Dương Cung Độ & Can Ngày khởi Thời truyền thống.
- **Thể loại:** Cổ pháp Tử Bình giao thoa Chiêm Tinh Tinh Mệnh.
- **Xuất xứ cổ tịch:** *Tam Mệnh Thông Hội* (三命通會) - Quyển 2, Tiết: "Luận An Mệnh Cung Pháp" (論安命宮法) phối *Mệnh Lý Tinh Hoa*.
- **Nguyên văn Hán tự:** 
  > 神無廟無所歸，人無室無所本，命無宮無所主。起命宮法，以正月起寅，逆數至生月，再從生月上起生時，順數至卯，即是命宮。
- **Link kiểm chứng công khai:** [Wikisource - 三命通會 卷二 安命宮](https://zh.wikisource.org/wiki/三命通會/卷02)
- **File đối chiếu nội bộ:** `Mệnh lý tinh hoa.pdf` (Chương An Mệnh Cung) & `Dự Đoán Theo Tứ Trụ - Thiệu Vĩ Hoa.pdf`.
- **Vị trí áp dụng:** Tập 01, Chương X & Chương XI: "Khảo chứng An Mệnh Cung theo Thái Dương Cung Độ".

---

### [REF-01-019]
- **Nội dung / Khái niệm:** Thai Nguyên (Tháng thụ thai) và Thân Cung trong cấu trúc bổ trợ Tứ Trụ.
- **Thể loại:** Kinh điển Tử Bình Cổ pháp.
- **Xuất xứ cổ tịch:** *Uyên Hải Tử Bình* (淵海子平) - Quyển 1, Tiết: "Luận Thai Nguyên" (論胎元).
- **Nguyên văn Hán tự:** 
  > 胎元者，受胎之月也。推法以月干加一，月支加三。如甲寅月生，加一得乙，支加三得巳，故乙巳為胎元。
- **Link kiểm chứng công khai:** [Wikisource - 淵海子平 胎元](https://zh.wikisource.org/wiki/淵海子平)
- **File đối chiếu nội bộ:** `Thiên Lý Mệnh Cảo.pdf` & `Dự Đoán Theo Tứ Trụ - Thiệu Vĩ Hoa.pdf`.
- **Vị trí áp dụng:** Tập 01, Chương X, Mục 10.3: "Ý nghĩa Thai Nguyên và Thân Cung".

---

### [REF-01-020]
- **Nội dung / Khái niệm:** Thuyết 18 ngày Tứ Quý Thổ vượng tư sự cuối mỗi mùa chuyển giao ngũ hành.
- **Thể loại:** Lịch pháp Ngũ Hành Dịch học.
- **Xuất xứ cổ tịch:** *Thiên Lý Mệnh Cảo* (千里命稿) - Vi Thiên Lý, Thiên: "Luận Ngũ Hành Vượng Tướng Hưu Tù Thổ Vượng Thập Bát Nhật".
- **Nguyên văn Hán tự:** 
  > 四季月辰戌丑未，各十八日土旺用事，其餘十二日屬該月之餘氣或長生之氣。辰月乙木餘九日，癸水三日，戊土十八日是也。
- **Link kiểm chứng công khai:** [ctext.org - 千里命稿](https://ctext.org)
- **File đối chiếu nội bộ:** `Thiên Lý Mệnh Cảo.pdf` (Mục Luận Thổ Vượng) & `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf`.
- **Vị trí áp dụng:** Tập 01, Chương XI: "18 ngày Tứ Quý Thổ theo Thiên Lý Mệnh Cảo".

---

### [REF-01-021]
- **Nội dung / Khái niệm:** Kỳ án thực chiến: Cạm bẫy ranh giới sinh cận sát giờ Lập Xuân (chưa giao tiết vẫn tính năm cũ).
- **Thể loại:** Kỳ án đối chứng kinh điển.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* (滴天髓闡微) - Nhậm Thiết Tiều, Quyển Thượng, Chương Tuế Khí.
- **Nguyên văn Hán tự:** 
  > 乾造：庚戌、戊寅、甲子、丙寅。此造生於立春前三刻，人皆以寅月甲木論，殊不知立春未交，實丑月所司，仍作己土用事，格局頓殊。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微](https://zh.wikisource.org/wiki/滴天髓闡微)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`.
- **Vị trí áp dụng:** Tập 01, Chương III & V (Bổ sung nâng cao): "Kỳ án ranh giới 1".

---

### [REF-01-022]
- **Nội dung / Khái niệm:** Kỳ án thực chiến: Sinh giờ Dạ Tý (23:30 đêm) đổi Can Ngày tạo thành cách cục Chân Thần Đắc Dụng.
- **Thể loại:** Kỳ án đối chứng Tử Bình Chân Thuyên.
- **Xuất xứ cổ tịch:** *Tử Bình Chân Thuyên Bình Chú* (子平真詮評註) - Từ Lạc Ngô dẫn án.
- **Nguyên văn Hán tự:** 
  > 某造生於子夜十一點半，術者或誤作次日子時，日干更變，格局全非。余正以當日夜子時論之，日元得正，用神合格，始符其貴徵。
- **Link kiểm chứng công khai:** [Wikisource - 子平真詮評註](https://zh.wikisource.org/wiki/子平真詮評註)
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf`.
- **Vị trí áp dụng:** Tập 01, Chương V: "Kỳ án thực chiến Dạ Tý".

---

### [REF-01-023]
- **Nội dung / Khái niệm:** Kỳ án thực chiến: Biến cố gia đạo và sự nghiệp ngay khúc quanh 2 năm giao tiếp vận.
- **Thể loại:** Kỳ án đối chứng Dân Quốc.
- **Xuất xứ:** *Tôi Học Đoán Khoa Tử Bình* - Chương 5, Ca số 3.
- **Nguyên văn trích yếu:** 
  > Đương số bước vào năm giao tiếp giữa vận Canh Thìn và Tân Tị, trong vòng 6 tháng chuyển giao gặp biến cố kinh tài sụp đổ, ứng kỳ đúng thời khắc khí số vận cũ thoái tàn vận mới nhập viện.
- **File đối chiếu nội bộ:** `toi hoc doan khoa tu binh.pdf`, Chương 5.
- **Vị trí áp dụng:** Tập 01, Chương IX (Bổ sung nâng cao): "Kỳ án Giao Tiếp Vận số 1".

---

### [REF-01-024]
- **Nội dung / Khái niệm:** Kỳ án thực chiến: Sinh tiết Đại Thử chưa chuyển Lập Thu, Kim hàn Thủy lãnh hay Hỏa táo Thổ khô.
- **Thể loại:** Kỳ án khảo sát Tiết khí Điều hậu.
- **Xuất xứ cổ tịch:** *Cùng Thông Bảo Giám* (窮通寶鑑) - Thân Nguyệt Giáp Mộc điều hậu dẫn án.
- **Nguyên văn Hán tự:** 
  > 大暑之後，立秋之前，雖在六月，金水進氣。若早生數刻，火土炎蒸；遲生數刻，涼飆初動，吉凶天淵。
- **Link kiểm chứng công khai:** [Wikisource - 窮通寶鑑](https://zh.wikisource.org/wiki/窮通寶鑑)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf` & `Mệnh lý tinh hoa.pdf`.
- **Vị trí áp dụng:** Tập 01, Chương III (Bổ sung nâng cao): "Kỳ án ranh giới Tiết Khí".

---

### [REF-01-025]
- **Nội dung / Khái niệm:** Kỳ án Mệnh Cung trợ giúp giải cứu nguyên cục phá cách.
- **Thể loại:** Kỳ án khảo sát Mệnh Cung tinh diệu.
- **Xuất xứ cổ tịch:** *Mệnh Lý Tinh Hoa* - Ca số 18, Mệnh Cung đắc Lộc.
- **Nguyên văn Hán tự:** 
  > 八字無祿，命宮得祿；四柱失援，命宮來生。此乃暗助之玄機，常人所不知也。
- **File đối chiếu nội bộ:** `Mệnh lý tinh hoa.pdf`, Mục Mệnh Cung thực chiến.
- **Vị trí áp dụng:** Tập 01, Chương X: "Kỳ án Mệnh Cung cứu viện".

---

### [REF-01-026]
- **Nội dung / Khái niệm:** Kỳ án sai lệch 40 phút giữa Giờ Hành Chính Trung Quốc (Bắc Kinh) và Giờ Địa Phương Tân Cương / Trùng Khánh dẫn đến sai lệch Trụ Giờ.
- **Thể loại:** Thực nghiệm Tử Bình đương đại.
- **Xuất xứ:** *Dự Đoán Theo Tứ Trụ* - Thiệu Vĩ Hoa, Chương 4: "Giờ Sinh & Vĩ Độ Địa Phương".
- **Nguyên văn trích lược:** 
  > Người sinh tại Tân Cương múi giờ mặt trời chậm hơn Bắc Kinh gần 2 tiếng, nếu cứng nhắc lấy giờ đồng hồ Bắc Kinh sẽ sai cả Trụ Giờ lẫn Dụng Thần. Bắt buộc quy đổi về Giờ Mặt Trời Chân Thực địa phương.
- **File đối chiếu nội bộ:** `Dự Đoán Theo Tứ Trụ - Thiệu Vĩ Hoa.pdf`, tr. 84–89.
- **Vị trí áp dụng:** Tập 01, Chương VI: "Phê phán ngụy biện giờ Bắc Kinh & Bài học cho Việt Nam".

---

### [REF-01-027]
- **Nội dung / Khái niệm:** Kỳ án sinh đêm 30 Tết Âm Lịch nhưng đã qua Lập Xuân được 3 ngày, chuyển đổi hoàn toàn Thiên Can Địa Chi Niên Trụ.
- **Thể loại:** Kỳ án đối chứng Dân Quốc.
- **Xuất xứ cổ tịch:** *Bát Tự Đề Yếu* - Vi Thiên Lý, Khảo án niên thủ.
- **Nguyên văn Hán tự:** 
  > 俗人以除夕為舊歲，年初一為新年，大謬不然。此造除夕前三日已交立春，歲次早更，依新歲八字排之，格局方驗。
- **File đối chiếu nội bộ:** `Thiên Lý Mệnh Cảo.pdf` & `Bát tự trân bảo giảng nghĩa.docx`.
- **Vị trí áp dụng:** Tập 01, Chương III: "Kỳ án phân định Niên Thủ".

---

### [REF-01-028]
- **Nội dung / Khái niệm:** Kỳ án thực chiến: Khởi vận sớm 1 tuổi vs khởi vận muộn 9 tuổi dẫn đến sự sai lệch hoàn toàn 10 năm Hoàng kim.
- **Thể loại:** Kỳ án đối chứng khởi vận.
- **Xuất xứ cổ tịch:** *Uyên Hải Tử Bình* - Quyển 2, Luận Khởi Vận Tiết Khí Hư Thực.
- **Nguyên văn Hán tự:** 
  > 起運差之一日，行運差之四月；起運差之三日，行運差之一整年。是以數節氣日時分秒，不可毫釐有差。
- **Link kiểm chứng công khai:** [Wikisource - 淵海子平](https://zh.wikisource.org/wiki/淵海子平)
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf`.
- **Vị trí áp dụng:** Tập 01, Chương IX: "Độ nhạy số học của thuật toán Khởi Đại Vận".

---

### [REF-01-029]
- **Nội dung / Khái niệm:** Kỳ án Nạp Âm Hải Trung Kim trợ lực Nhật Chủ Mậu Thổ hóa hiểm thành an.
- **Thể loại:** Kỳ án Nạp Âm cổ pháp phối hợp Chính Ngũ Hành.
- **Xuất xứ cổ tịch:** *Tam Mệnh Thông Hội* - Quyển 1, Luận Nạp Âm Cứu Trợ.
- **Nguyên văn Hán tự:** 
  > 正五行無救，納音有生；正五行見克，納音得助。此神煞納音之所以同參也。
- **Link kiểm chứng công khai:** [Wikisource - 三命通會 卷一](https://zh.wikisource.org/wiki/三命通會/卷01)
- **File đối chiếu nội bộ:** `Mệnh Lý huyền cơ tham bí.pdf`.
- **Vị trí áp dụng:** Tập 01, Chương VIII (Bổ sung nâng cao): "Kỳ án Nạp Âm thực chiến".

---

### [REF-01-030]
- **Nội dung / Khái niệm:** Chuẩn hóa quy trình 8 bước nạp dữ liệu đầu vào thiên văn & Kiểm định Zero-Error cho mô hình AI Agent.
- **Thể loại:** Kiến trúc kỹ thuật Mệnh lý tính toán học.
- **Xuất xứ:** Antigravity Master Astronomical Engine Specification & Standards (Gemini 4 Argon Integration).
- **Nguyên văn đặc tả:** 
  > Input Pipeline: (Date, Time, Lat, Long) -> Julian Day Number -> Jean Meeus True Solar Time & EoT correction -> Solar Term boundary check -> Four Pillars formulation -> Day-Night Rat validation -> Output JSON Schema v2.0.0.
- **File đối chiếu nội bộ:** `tu_tru_engine.js` & `SKILL.md`.
- **Vị trí áp dụng:** Tập 01, Chương XII: "Mã nguồn Astronomical Engine & Quy chuẩn dữ liệu đầu vào".

---

# PHẦN 02: DANH MỤC TRÍCH DẪN TẬP 02 (`02-bien-chung-ngu-hanh-can-khi.md`)
## BIỆN CHỨNG KHÍ THẾ, CĂN KHÍ, HƯ PHÙ, 10 BÀI PHÚ THIÊN CAN VÀ VƯỢNG SUY 100 ĐIỂM

### [REF-02-001]
- **Nội dung / Khái niệm:** Bản thể luận Khí vs Thế trong Tử Bình Mệnh Lý Học — Cương lĩnh Trích Thiên Tủy.
- **Thể loại:** Kinh điển Tử Bình Tối Cao.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* (滴天髓闡微) - Lưu Bá Ôn nguyên tác, Nhậm Thiết Tiều khảo chú. Thiên: "Thông Thần Luận" (通神論).
- **Nguyên văn Hán tự:** 
  > 戴天履地人為貴，順則吉兮凶則悖。要與人間開步著，順逆之機須理會。理承氣行豈有常，進兮退兮宜抑揚。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微 通神論](https://zh.wikisource.org/wiki/滴天髓闡微#通神論)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`, Quyển Thượng, Thiên Thông Thần Luận.
- **Vị trí áp dụng:** Tập 02, Chương I: "Bản nguyên Khí và Thế — Đỉnh cao triết học Trích Thiên Tủy".

---

### [REF-02-002]
- **Nội dung / Khái niệm:** Khẩu quyết Thiên Can Phú: Giáp Mộc tham thiên thoát thai yếu Hỏa.
- **Thể loại:** Kinh điển Trích Thiên Tủy - 10 Bài Phú Thiên Can.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* - Thiên: "Luận Thiên Can - Giáp Mộc" (論天干·甲木).
- **Nguyên văn Hán tự:** 
  > 甲木參天，脫胎要火。春不容金，秋不容土。火熾乘龍，水蕩騎虎。地潤天和，植立千古。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微 天干](https://zh.wikisource.org/wiki/滴天髓闡微#天干)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf` & `Thiên Lý Mệnh Cảo.pdf`.
- **Vị trí áp dụng:** Tập 02, Chương II, Mục 2.1: "Giáp Mộc toàn đồ".

---

### [REF-02-003]
- **Nội dung / Khái niệm:** Khẩu quyết Thiên Can Phú: Ất Mộc căn hài hoài đinh bão bính khát lộc vinh hoa.
- **Thể loại:** Kinh điển Trích Thiên Tủy - 10 Bài Phú Thiên Can.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* - Thiên: "Luận Thiên Can - Ất Mộc" (論天干·乙木).
- **Nguyên văn Hán tự:** 
  > 乙木雖柔，刲羊解牛。懷丁抱丙，跨鳳乘猴。虛濕之地，騎馬亦憂。藤蘿系甲，可春可秋。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微 天干](https://zh.wikisource.org/wiki/滴天髓闡微#天干)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf` & `Thiên Lý Mệnh Cảo.pdf`.
- **Vị trí áp dụng:** Tập 02, Chương II, Mục 2.2: "Ất Mộc toàn đồ".

---

### [REF-02-004]
- **Nội dung / Khái niệm:** Khẩu quyết Thiên Can Phú: Bính Hỏa mãnh liệt khi sương vũ tuyết năng đoán canh kim.
- **Thể loại:** Kinh điển Trích Thiên Tủy - 10 Bài Phú Thiên Can.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* - Thiên: "Luận Thiên Can - Bính Hỏa" (論天干·丙火).
- **Nguyên văn Hán tự:** 
  > 丙火猛烈，欺霜侮雪。能鍛庚金，逢辛反怯。土眾成慈，水狷顯節。虎馬犬鄉，甲來成滅。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微 天干](https://zh.wikisource.org/wiki/滴天髓闡微#天干)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf` & `Thiên Lý Mệnh Cảo.pdf`.
- **Vị trí áp dụng:** Tập 02, Chương II, Mục 2.3: "Bính Hỏa toàn đồ".

---

### [REF-02-005]
- **Nội dung / Khái niệm:** Khẩu quyết Thiên Can Phú: Đinh Hỏa nhu trung nội tính chiêu dung sùng bái ất mộc.
- **Thể loại:** Kinh điển Trích Thiên Tủy - 10 Bài Phú Thiên Can.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* - Thiên: "Luận Thiên Can - Đinh Hỏa" (論天干·丁火).
- **Nguyên văn Hán tự:** 
  > 丁火柔中，內性昭融。抱乙而孝，合壬而忠。旺而不烈，衰而不窮。如有嫡母，可秋可冬。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微 天干](https://zh.wikisource.org/wiki/滴天髓闡微#天干)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf` & `Thiên Lý Mệnh Cảo.pdf`.
- **Vị trí áp dụng:** Tập 02, Chương II, Mục 2.4: "Đinh Hỏa toàn đồ".

---

### [REF-02-006]
- **Nội dung / Khái niệm:** Khẩu quyết Thiên Can Phú: Mậu Thổ cố trọng ký trung thả chính tĩnh hấp động khai.
- **Thể loại:** Kinh điển Trích Thiên Tủy - 10 Bài Phú Thiên Can.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* - Thiên: "Luận Thiên Can - Mậu Thổ" (論天干·戊土).
- **Nguyên văn Hán tự:** 
  > 戊土固重，既中且正。靜翕動辟，萬物司命。水潤物生，火燥物病。若在艮坤，怕沖宜靜。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微 天干](https://zh.wikisource.org/wiki/滴天髓闡微#天干)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf` & `Thiên Lý Mệnh Cảo.pdf`.
- **Vị trí áp dụng:** Tập 02, Chương II, Mục 2.5: "Mậu Thổ toàn đồ".

---

### [REF-02-007]
- **Nội dung / Khái niệm:** Khẩu quyết Thiên Can Phú: Kỷ Thổ ty thấp trung chính súc tàng bất sầu mộc thịnh.
- **Thể loại:** Kinh điển Trích Thiên Tủy - 10 Bài Phú Thiên Can.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* - Thiên: "Luận Thiên Can - Kỷ Thổ" (論天干·己土).
- **Nguyên văn Hán tự:** 
  > 己土卑濕，中正蓄藏。不愁木盛，不畏水狂。火少火晦，金多金光。若要物旺，宜助宜幫。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微 天干](https://zh.wikisource.org/wiki/滴天髓闡微#天干)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf` & `Thiên Lý Mệnh Cảo.pdf`.
- **Vị trí áp dụng:** Tập 02, Chương II, Mục 2.6: "Kỷ Thổ toàn đồ".

---

### [REF-02-008]
- **Nội dung / Khái niệm:** Khẩu quyết Thiên Can Phú: Canh Kim đới sát cương kiện vi tối đắc thủy nhi thanh.
- **Thể loại:** Kinh điển Trích Thiên Tủy - 10 Bài Phú Thiên Can.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* - Thiên: "Luận Thiên Can - Canh Kim" (論天干·庚金).
- **Nguyên văn Hán tự:** 
  > 庚金帶煞，剛健為最。得水而清，得火而銳。土潤則生，土乾則脆。能贏甲兄，輸於乙妹。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微 天干](https://zh.wikisource.org/wiki/滴天髓闡微#天干)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf` & `Thiên Lý Mệnh Cảo.pdf`.
- **Vị trí áp dụng:** Tập 02, Chương II, Mục 2.7: "Canh Kim toàn đồ".

---

### [REF-02-009]
- **Nội dung / Khái niệm:** Khẩu quyết Thiên Can Phú: Tân Kim ôn nhuận chất dịch thanh thanh nhiệt tắc hỷ mẫu.
- **Thể loại:** Kinh điển Trích Thiên Tủy - 10 Bài Phú Thiên Can.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* - Thiên: "Luận Thiên Can - Tân Kim" (論天干·辛金).
- **Nguyên văn Hán tự:** 
  > 辛金溫潤，零件清清。熱則喜母，寒則喜丁。樂水之盈，能扶社稷。樂水之盈，能潤生民。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微 天干](https://zh.wikisource.org/wiki/滴天髓闡微#天干)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf` & `Thiên Lý Mệnh Cảo.pdf`.
- **Vị trí áp dụng:** Tập 02, Chương II, Mục 2.8: "Tân Kim toàn đồ".

---

### [REF-02-010]
- **Nội dung / Khái niệm:** Khẩu quyết Thiên Can Phú: Nhâm Thủy thông hà & Quý Thủy chí nhược đạt vu bến thiên.
- **Thể loại:** Kinh điển Trích Thiên Tủy - 10 Bài Phú Thiên Can.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* - Thiên: "Luận Thiên Can - Nhâm Thủy & Quý Thủy" (論天干·壬癸水).
- **Nguyên văn Hán tự:** 
  > 壬水通河，能洩金氣。剛中之德，周流不滯。通根透癸，沖天奔地。化則有情，從則相濟。
  > 癸水至弱，達於天津。得龍而運，功化斯神。不愁火土，不論庚辛。合戊見火，化象斯真。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微 天干](https://zh.wikisource.org/wiki/滴天髓闡微#天干)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf` & `Thiên Lý Mệnh Cảo.pdf`.
- **Vị trí áp dụng:** Tập 02, Chương II, Mục 2.9 & 2.10: "Nhâm Quý Thủy toàn đồ".

---

### [REF-02-011]
- **Nội dung / Khái niệm:** Thuyết Căn Khí 4 bậc: Chính Căn (Bản Khí), Trung Căn (Trung Khí), Dư Khí, và Hư Phù Vô Căn.
- **Thể loại:** Cương lĩnh Căn Khí Tử Bình Chân Thuyên.
- **Xuất xứ cổ tịch:** *Tử Bình Chân Thuyên Bình Chú* (子平真詮評註) - Thẩm Triều Phổ nguyên tác, Từ Lạc Ngô bình chú. Thiên: "Luận Thập Can Đắc Thời Bất Vượng Thất Thời Bất Nhược" (論十干得時不旺失時不弱).
- **Nguyên văn Hán tự:** 
  > 夫干以根為本，支以干為苗。得一干不如得一支，得一支不如得一通根。有通根之支，方為實氣；若無通根，虛浮無力，雖多亦無用也。
- **Link kiểm chứng công khai:** [Wikisource - 子平真詮評註](https://zh.wikisource.org/wiki/子平真詮評註)
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf` & `Mệnh Lý huyền cơ tham bí.pdf`.
- **Vị trí áp dụng:** Tập 02, Chương III: "Thuyết Căn Khí và Tứ Đại Đẳng Cấp gốc rễ Địa Chi".

---

### [REF-02-012]
- **Nội dung / Khái niệm:** Thấu Can dữ Thông Căn quan hệ hữu cơ: Can không căn như cây không rễ, Chi không thấu can như vàng giấu trong đá.
- **Thể loại:** Kinh điển Trích Thiên Tủy.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* - Thiên: "Địa Chi" (地支).
- **Nguyên văn Hán tự:** 
  > 支神只以沖為重，刑與害兮動殊。左右逢之還整齊，受制之人翻無慮。透頂乘頭，方顯精神；受剋被傷，終成枯槁。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微 地支](https://zh.wikisource.org/wiki/滴天髓闡微#地支)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`.
- **Vị trí áp dụng:** Tập 02, Chương IV: "Biện chứng Chân Căn, Giả Căn và Hiện tượng Hư Phù tàn khốc".

---

### [REF-02-013]
- **Nội dung / Khái niệm:** Biện chứng nghịch lý: Đắc Thời mạc nhược, Thất Thời mạc cường (Mùa sinh không quyết định tất cả vượng suy).
- **Thể loại:** Kinh điển Trích Thiên Tủy & Tử Bình Chân Thuyên.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* - Thiên: "Nguyệt Lệnh" (月令).
- **Nguyên văn Hán tự:** 
  > 月令提綱，本為領要。得時而不旺者，四柱剋洩太過也；失時而不衰者，支下根深黨重也。故論命不可以得時為全強，失令為全弱。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微 月令](https://zh.wikisource.org/wiki/滴天髓闡微#月令)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf` & `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf`.
- **Vị trí áp dụng:** Tập 02, Chương V: "Đắc thời mà nhược vs Thất thời mà cường".

---

### [REF-02-014]
- **Nội dung / Khái niệm:** Ma trận 25 trạng thái ngũ hành biến thiên cực đoan: Phản sinh, Phản khắc, Tiết khí thái quá.
- **Thể loại:** Biện chứng Ngũ Hành Sinh Khắc Tiệt Vi.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* - Thiên: "Ngũ Hành Sinh Khắc Cực Biến" (五行生剋極變).
- **Nguyên văn Hán tự:** 
  > 金旺得火，方成器皿；金多火熄，反遭銷鑠。土旺得木，方能疏通；木重土崩，反為陷落。水旺得土，方成池沼；土重水竭，塞而不通。木旺得金，方成棟樑；金多木折，反成摧殘。火旺得水，方成相濟；水多火滅，黯無光輝。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微](https://zh.wikisource.org/wiki/滴天髓闡微)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`.
- **Vị trí áp dụng:** Tập 02, Chương VI: "Ma trận đại toàn thư 25 trạng thái ngũ hành cực đoan".

---

### [REF-02-015]
- **Nội dung / Khái niệm:** Thuyết Hoạt Mộc vs Tử Mộc: Mộc có căn nước nuôi là Hoạt Mộc kỵ kim đao, Mộc khô không nước là Tử Mộc hỷ kim đao thành rường cột.
- **Thể loại:** Mệnh lý thực nghiệm cao cấp.
- **Xuất xứ cổ tịch:** *Tam Mệnh Thông Hội* (Quyển 3) phối *Trích Thiên Tủy Điệt Vi* (Thiên Giáp Mộc).
- **Nguyên văn Hán tự:** 
  > 活木者，有根有水，方能生長，見金則被傷，見火則洩秀；死木者，無根枯朽，見金雕琢方成器，見火焚化自消亡。
- **Link kiểm chứng công khai:** [Wikisource - 三命通會 卷三](https://zh.wikisource.org/wiki/三命通會/卷03)
- **File đối chiếu nội bộ:** `khi the luu thong.docx` & `Mệnh Lý huyền cơ tham bí.pdf`.
- **Vị trí áp dụng:** Tập 02, Chương XIII: "Lý thuyết Hoạt Mộc vs Tử Mộc & Ngũ hành hoạt tử".

---

### [REF-02-016]
- **Nội dung / Khái niệm:** Khảo biện mở rộng 5 Cặp Hoạt - Tử Ngũ Hành: Hoạt Kim/Tử Kim, Hoạt Hỏa/Tử Hỏa, Hoạt Thổ/Tử Thổ, Hoạt Thủy/Tử Thủy.
- **Thể loại:** Khí tượng động lực học Mệnh lý.
- **Xuất xứ cổ tịch:** *Mệnh Lý Huyền Cơ Tham Bí* - Trần Khang Ninh, Chương 6: "Ngũ Hành Hoạt Tử Chi Biện".
- **Nguyên văn Hán tự:** 
  > 活金者得火而成器，死金者得水而淘洗；活火者有柴而不滅，死火者隨風而自散；活水者通源而長流，死水者積垢而濁塞。
- **File đối chiếu nội bộ:** `Mệnh Lý huyền cơ tham bí.pdf` & `dự-báo-theo-tử-bình-trần-khang-ninh-pdf-dantocking.com.PDF`.
- **Vị trí áp dụng:** Tập 02, Chương XIII (Chuyên đề mở rộng): "Đại khảo biện 5 cặp Hoạt - Tử Ngũ Hành".

---

### [REF-02-017]
- **Nội dung / Khái niệm:** Thuật toán định lượng 100 điểm khí lực Tứ Trụ: Nguyệt Lệnh 40 điểm, Trụ Chi 35 điểm, Trụ Can 25 điểm.
- **Thể loại:** Toán học hóa Mệnh lý học hiện đại.
- **Xuất xứ:** Kết hợp hệ thống định lượng của Thiệu Vĩ Hoa (*Tứ Trụ Dự Trắc Học*) và nguyên lý đắc lệnh đắc địa của Thẩm Triều Phổ (*Tử Bình Chân Thuyên*).
- **Nguyên văn chuẩn hóa:** 
  > Điểm tổng hợp khí lực: $Score = W_{month}(40) + sum W_{branch}(35) + sum W_{stem}(25)$. Thân cường: $Score ge 50$, Thân nhược: $Score < 50$.
- **File đối chiếu nội bộ:** `Dự Đoán Theo Tứ Trụ - Thiệu Vĩ Hoa.pdf`, tr. 110–125 & `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf`.
- **Vị trí áp dụng:** Tập 02, Chương VII: "Hệ thống định lượng khí lực 100 điểm chuẩn xác".

---

### [REF-02-018]
- **Nội dung / Khái niệm:** Thần Khố chi bí: Bản thể 4 Địa Chi Mộ Khố Thìn, Tuất, Sửu, Mùi — Khí suy nhập mộ, Khí vượng quy khố.
- **Thể loại:** Kinh điển Thần Khố Tử Bình.
- **Xuất xứ cổ tịch:** *Tam Mệnh Thông Hội* - Quyển 3, Tiết: "Luận Tứ Quý Chi Khố" (論四季之庫).
- **Nguyên văn Hán tự:** 
  > 辰戌丑未為四墓之神，旺則為庫，衰則為墓。木以未為庫，金以丑為庫，水土以辰為庫，火以戌為庫。吉神入墓不吉，凶煞入墓反安。
- **Link kiểm chứng công khai:** [Wikisource - 三命通會 卷三](https://zh.wikisource.org/wiki/三命通會/卷03)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf` & `Bát tự trân bảo giảng nghĩa.docx`.
- **Vị trí áp dụng:** Tập 02, Chương XV: "Chuyên đề Mộ Khố toàn tập — Thần Khố chi bí".

---

### [REF-02-019]
- **Nội dung / Khái niệm:** Cơ chế Khai Mộ Khố và Hiện tượng Bế Khố / Sập Hầm Thập Thần trong Manh Phái và Cổ Pháp.
- **Thể loại:** Manh phái mệnh lý bí truyền phối Cổ pháp.
- **Xuất xứ cổ tịch:** *Mệnh Lý Trân Bảo* - Đoàn Kiến Nghiệp, Chương: "Mộ Khố Tố Công Chi Pháp".
- **Nguyên văn Hán tự:** 
  > 庫待沖開，無沖則閉。然閉庫易，開庫難。若庫中用神受刑衝而拔根，反主大破；庫中忌神被閉，反而發福。
- **Link kiểm chứng công khai:** [ctext.org - 盲派命理](https://ctext.org)
- **File đối chiếu nội bộ:** `Bát tự trân bảo giảng nghĩa.docx` & `MỆNH LÝ TRÂN BẢO GIẢNG NGHĨA.pdf`.
- **Vị trí áp dụng:** Tập 02, Chương XV (Chuyên đề mở rộng): "16 bí pháp khai bế mộ khố & sập hầm thập thần".

---

### [REF-02-020]
- **Nội dung / Khái niệm:** Bảng ma trận 60 Cặp Can Chi Tự Tọa nội trụ ảnh hưởng trực tiếp tới căn khí bản thân.
- **Thể loại:** Kinh điển Lục Thập Hoa Giáp Tự Thừa.
- **Xuất xứ cổ tịch:** *Tử Bình Thực Chứng Ứng Dụng* - Thiệu Vĩ Hoa & *Trích Thiên Tủy Điệt Vi*.
- **Nguyên văn tóm lược:** 
  > Tự tọa Trường Sinh, Quan Đới, Lâm Quan, Đế Vượng là tự đắc căn cường. Tự tọa Tử, Tuyệt, Bại, Thai là tự nhược vô căn. Tọa Mộ xét thấu xuất can chi.
- **File đối chiếu nội bộ:** `Dự Đoán Theo Tứ Trụ - Thiệu Vĩ Hoa.pdf` & `Thiên Lý Mệnh Cảo.pdf`.
- **Vị trí áp dụng:** Tập 02, Chương XIV: "Đại toàn thư biện chứng 60 cặp Can Chi tọa trụ".

---

### [REF-02-021]
- **Nội dung / Khái niệm:** Kỳ án thực chiến: Giáp Mộc sinh tháng Dần đắc lệnh nhưng bị Canh Thân xung khắc bạt căn trở thành hư phù bần hàn.
- **Thể loại:** Kỳ án khảo sát căn khí Trích Thiên Tủy.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* - Chương Địa Chi Xung Khắc.
- **Nguyên văn Hán tự:** 
  > 乾造：庚申、戊寅、甲子、庚申。甲木生於寅月，人皆以為旺相，殊不知兩申沖寅，根荄盡拔，又逢戊土生庚，日主雖在孟春，虛浮若絮，終生落魄。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微](https://zh.wikisource.org/wiki/滴天髓闡微)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`.
- **Vị trí áp dụng:** Tập 02, Chương VIII: "Kỳ án Căn Khí số 1".

---

### [REF-02-022]
- **Nội dung / Khái niệm:** Kỳ án thực chiến: Ất Mộc thất thời sinh tháng Thân nhưng đắc Hợi Mão Mùi tam hợp chi đảng chuyển bại thành thắng, đại quý cực phẩm.
- **Thể loại:** Kỳ án Thất thời mà cường.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* - Thiên "Chi Đắc Cục".
- **Nguyên văn Hán tự:** 
  > 乾造：乙未、甲申、乙卯、丁亥。乙木生於申月，失時之極，然而支會亥卯未木局，干透甲乙，弱變為強，行火土運位至封疆。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微](https://zh.wikisource.org/wiki/滴天髓闡微)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`.
- **Vị trí áp dụng:** Tập 02, Chương VIII: "Kỳ án Căn Khí số 2".

---

### [REF-02-023]
- **Nội dung / Khái niệm:** Kỳ án thực chiến: Bính Hỏa tử tuyệt tại tháng Tý nhưng đắc Dần thời tọa mộc ấn bộc phát trạng nguyên.
- **Thể loại:** Kỳ án Tử tuyệt phùng sinh.
- **Xuất xứ cổ tịch:** *Tử Bình Chân Thuyên Bình Chú* - Ca trạng nguyên.
- **Nguyên văn Hán tự:** 
  > 乾造：壬子、壬子、丙寅、庚寅。冬火至弱，見兩重壬子七煞，凶惡之至。喜其坐下兩寅，印綬得生，絕處逢生，化煞為權。
- **Link kiểm chứng công khai:** [Wikisource - 子平真詮評註](https://zh.wikisource.org/wiki/子平真詮評註)
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf`.
- **Vị trí áp dụng:** Tập 02, Chương XI: "Kỳ án Thực Chiến đối chứng".

---

### [REF-02-024]
- **Nội dung / Khái niệm:** Kỳ án thực chiến: Đinh Hỏa nhu nhược tọa dậu tử địa nhưng thấu giáp bính tương sinh thành cự phú.
- **Thể loại:** Kỳ án Đinh hỏa nhu trung.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* - Thiên Đinh Hỏa.
- **Nguyên văn Hán tự:** 
  > 丁火坐酉，本為絕地，若得甲木生身，丙火助旺，暗生資產，富甲一方。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微](https://zh.wikisource.org/wiki/滴天髓闡微)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`.
- **Vị trí áp dụng:** Tập 02, Chương XI: "Kỳ án Đinh Hỏa cự phú".

---

### [REF-02-025]
- **Nội dung / Khái niệm:** Kỳ án thực chiến: Mậu Thổ tọa Thìn khố đắc Tuất xung khai đại phát tài lộc ngàn tỷ.
- **Thể loại:** Kỳ án Mộ Khố Tố Công Manh Phái.
- **Xuất xứ:** *Bát Tự Trân Bảo Giảng Nghĩa* - Đoàn Kiến Nghiệp, Ca số 14.
- **Nguyên văn trích dẫn:** 
  > Mậu Thổ tọa Thìn tài khố, đắc vận Tuất xung khai kho báu, làm quan tài chính và kinh doanh bất động sản đại phú.
- **File đối chiếu nội bộ:** `Bát tự trân bảo giảng nghĩa.docx` & `MỆNH LÝ TRÂN BẢO GIẢNG NGHĨA.pdf`.
- **Vị trí áp dụng:** Tập 02, Chương XV: "Kỳ án Xung Khai Tài Khố".

---

### [REF-02-026]
- **Nội dung / Khái niệm:** Kỳ án Kỷ Thổ ty thấp bị mộc trùng trùng khắc phá không gốc tàn phế.
- **Thể loại:** Kỳ án Thất thời hư phù tàn khốc.
- **Xuất xứ cổ tịch:** *Thiên Lý Mệnh Cảo* - Vi Thiên Lý, Khảo sát Kỷ Thổ nhược.
- **Nguyên văn Hán tự:** 
  > 己土無根，甲乙重重，木多土陷，肢體殘廢，一生困頓。
- **File đối chiếu nội bộ:** `Thiên Lý Mệnh Cảo.pdf`.
- **Vị trí áp dụng:** Tập 02, Chương XI: "Kỳ án Kỷ Thổ khuyết căn".

---

### [REF-02-027]
- **Nội dung / Khái niệm:** Kỳ án Canh Kim đới sát phùng đinh hỏa tôi luyện hiển đạt tướng soái.
- **Thể loại:** Kỳ án Trích Thiên Tủy Canh Kim đới sát.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* - Thiên Canh Kim.
- **Nguyên văn Hán tự:** 
  > 庚金剛健，無火煉不成器。見丁火煆煉，威權震世，武職封侯。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微](https://zh.wikisource.org/wiki/滴天髓闡微)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`.
- **Vị trí áp dụng:** Tập 02, Chương II, Mục 2.7: "Kỳ án Canh Kim tôi luyện".

---

### [REF-02-028]
- **Nội dung / Khái niệm:** Kỳ án Tân Kim ôn nhuận bị thổ đa mai kim nghẹt thở yểu tử.
- **Thể loại:** Kỳ án Thổ đa mai kim ngũ hành phản khắc.
- **Xuất xứ cổ tịch:** *Uyên Hải Tử Bình* - Quyển 3, Luận Tân Kim Mộ Diệt.
- **Nguyên văn Hán tự:** 
  > 辛金至潤，怕土之厚。戊己重逢，金沈土下，窒息而亡。
- **Link kiểm chứng công khai:** [Wikisource - 淵海子平](https://zh.wikisource.org/wiki/淵海子平)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`.
- **Vị trí áp dụng:** Tập 02, Chương VI: "Kỳ án Thổ đa mai Kim".

---

### [REF-02-029]
- **Nội dung / Khái niệm:** Kỳ án Nhâm Thủy giang hà vỡ đê tràn lan không mậu thổ ngăn chặn phá gia chi tử.
- **Thể loại:** Kỳ án Nhâm thủy cuồng phong.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* - Thiên Nhâm Thủy.
- **Nguyên văn Hán tự:** 
  > 壬水通河，泛濫滔天。無戊土砥柱，終成潰堤之患，家業蕩盡。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微](https://zh.wikisource.org/wiki/滴天髓闡微)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`.
- **Vị trí áp dụng:** Tập 02, Chương II, Mục 2.9: "Kỳ án Nhâm Thủy hồng thủy".

---

### [REF-02-030]
- **Nội dung / Khái niệm:** Kỳ án Quý Thủy đắc long hóa vũ bộc phát hiển vinh.
- **Thể loại:** Kỳ án Quý thủy chí nhược đắc rồng biến hóa.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* - Thiên Quý Thủy.
- **Nguyên văn Hán tự:** 
  > 癸水雖弱，見辰龍則潤化萬物。功化斯神，富貴無涯。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微](https://zh.wikisource.org/wiki/滴天髓闡微)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`.
- **Vị trí áp dụng:** Tập 02, Chương II, Mục 2.10: "Kỳ án Quý Thủy đắc Long".

---

# PHẦN 03: DANH MỤC TRÍCH DẪN TẬP 03 (`03-tuong-tac-can-chi-vi-te.md`)
## TƯƠNG TÁC CAN CHI ĐA TẦNG VI TẾ — HỢP, HÓA, XUNG, HÌNH, HẠI, PHÁ & MA TRẬN 144 TỔ HỢP

### [REF-03-001]
- **Nội dung / Khái niệm:** Bản thể luận Động Can vs Tĩnh Chi trong biến hóa vũ trụ: Can động dễ biến, Chi tĩnh khó suy chuyển.
- **Thể loại:** Kinh điển Tử Bình Tối Cao.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* (滴天髓闡微) - Lưu Bá Ôn nguyên tác, Nhậm Thiết Tiều khảo chú. Thiên: "Thiên Can Địa Chi Biện" (天干地支辨).
- **Nguyên văn Hán tự:** 
  > 天干動而專，地支靜而雜。動則易變，靜則難搖。天干吉凶顯於外，地支生剋藏於內。干生支兮福重，支克干兮禍烈。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微 地支](https://zh.wikisource.org/wiki/滴天髓闡微#地支)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`, Quyển Thượng.
- **Vị trí áp dụng:** Tập 03, Chương I: "Bản thể luận Khí hóa & Nguyên lý tương tác Can Chi".

---

### [REF-03-002]
- **Nội dung / Khái niệm:** Thiên Can Ngũ Hợp bản nguyên: Giáp Kỷ hóa Thổ, Ất Canh hóa Kim, Bính Tân hóa Thủy, Đinh Nhâm hóa Mộc, Mậu Quý hóa Hỏa.
- **Thể loại:** Kinh điển Hóa Khí Mệnh Lý.
- **Xuất xứ cổ tịch:** *Tam Mệnh Thông Hội* (三命通會) - Vạn Dân Anh. Quyển 2, Tiết: "Luận Thập Can Hợp Hóa Khí" (論十干合化氣).
- **Nguyên văn Hán tự:** 
  > 甲己中央化土，乙庚西方化金，丙辛北方化水，丁壬東方化木，戊癸南方化火。十干之合，取象於夫婦之義，本乎河圖洛書之數也。
- **Link kiểm chứng công khai:** [Wikisource - 三命通會 卷二](https://zh.wikisource.org/wiki/三命通會/卷02)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf` & `Thiên Lý Mệnh Cảo.pdf`.
- **Vị trí áp dụng:** Tập 03, Chương II: "Thiên Can sinh khắc & Ngũ Hợp hóa khí".

---

### [REF-03-003]
- **Nội dung / Khái niệm:** Tứ đại điều kiện ngặt nghèo để Thiên Can Chân Hóa Khí thành công (Nguyệt lệnh dẫn đạo, không phùng khắc chế, Địa chi hội cục, Thân nhược quy phục).
- **Thể loại:** Cương lĩnh Hóa Cách Tử Bình Chân Thuyên.
- **Xuất xứ cổ tịch:** *Tử Bình Chân Thuyên Bình Chú* (子平真詮評註) - Thẩm Triều Phổ, Thiên: "Luận Hóa Khí Cách" (論化氣格).
- **Nguyên văn Hán tự:** 
  > 逢合化氣，須得月令引導。如甲己化土，須生於辰戌丑未或巳午之月。又須地支透氣成黨，四柱不見克破之神，方成真化。苟有一位克破，即為假化矣。
- **Link kiểm chứng công khai:** [Wikisource - 子平真詮評註 化氣格](https://zh.wikisource.org/wiki/子平真詮評註)
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf`.
- **Vị trí áp dụng:** Tập 03, Chương II, Mục 2.2: "4 điều kiện Chân Hóa Khí".

---

### [REF-03-004]
- **Nội dung / Khái niệm:** Cơ chế Hợp Trói (Hợp Nhi Bất Hóa, Hợp Nhi Kỷ Bạng): Hai bên kiềm chế triệt tiêu lẫn nhau thành vô dụng.
- **Thể loại:** Trích Thiên Tủy tương tác vi tế.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* - Thiên: "Hợp Nhượng Luận" (合讓論).
- **Nguyên văn Hán tự:** 
  > 合而不化，謂之羈絆。吉神逢合，羈絆不能效吉；凶神逢合，羈絆不能行凶。是合之利弊，在於所絆者何神也。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微](https://zh.wikisource.org/wiki/滴天髓闡微)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`.
- **Vị trí áp dụng:** Tập 03, Chương II, Mục 2.3: "Hợp hóa vs Hợp trói".

---

### [REF-03-005]
- **Nội dung / Khái niệm:** Địa Chi Lục Hợp bản nguyên: Tý Sửu, Dần Hợi, Mão Tuất, Thìn Dậu, Tị Thân, Ngọ Mùi & Cơ chế Nhật Nguyệt hội hợp.
- **Thể loại:** Kinh điển Lục Hợp Cổ pháp.
- **Xuất xứ cổ tịch:** *Tam Mệnh Thông Hội* - Quyển 2, Tiết: "Luận Chi Lục Hợp" (論支六合).
- **Nguyên văn Hán tự:** 
  > 夫六合者，日辰月宿之合也。日行纏子，月建在丑，故子與丑合；日行纏亥，月建在寅，故寅與亥合... 陰陽相交，成其造化。
- **Link kiểm chứng công khai:** [Wikisource - 三命通會 卷二](https://zh.wikisource.org/wiki/三命通會/卷02)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf` & `Mệnh Lý huyền cơ tham bí.pdf`.
- **Vị trí áp dụng:** Tập 03, Chương III: "Địa Chi Lục Hợp & Ám Hợp bí truyền".

---

### [REF-03-006]
- **Nội dung / Khái niệm:** Địa Chi Ám Hợp bí truyền: Thông Căn Ám Hợp (Dần Sửu, Ngọ Hợi, Mão Thân) vs Khí Hợp trong Manh Phái.
- **Thể loại:** Manh Phái Mệnh Lý Bí Bản.
- **Xuất xứ cổ tịch:** *Mệnh Lý Trân Bảo* - Đoàn Kiến Nghiệp, Chương: "Địa Chi Ám Hợp Chân Nghĩa".
- **Nguyên văn Hán tự:** 
  > 暗合者，地支藏干私合也。寅丑暗合（甲己、丙辛、戊癸），午亥暗合（丁壬），卯申暗合（乙庚）。暗合主私情、暗昧、檯面下交易。
- **Link kiểm chứng công khai:** [ctext.org - 盲派命理](https://ctext.org)
- **File đối chiếu nội bộ:** `Bát tự trân bảo giảng nghĩa.docx` & `DKN - Bat Tu Luan Menh Bi Kiep.pdf`.
- **Vị trí áp dụng:** Tập 03, Chương III, Mục 3.2: "Ám Hợp vi tế".

---

### [REF-03-007]
- **Nội dung / Khái niệm:** Tam Hội Phương Cục bản nguyên (Dần Mão Thìn phương Đông, Tị Ngọ Mùi phương Nam, Thân Dậu Tuất phương Tây, Hợi Tý Sửu phương Bắc) vượng khí tuyệt đối tối cao.
- **Thể loại:** Cương lĩnh Phương Cục Tử Bình Chân Thuyên.
- **Xuất xứ cổ tịch:** *Tử Bình Chân Thuyên Bình Chú* - Thiên: "Luận Địa Chi Phương Cục Hội Cục" (論地支方局會局).
- **Nguyên văn Hán tự:** 
  > 方局者，一氣聚於一方也。寅卯辰全，東方春木之純氣；巳午未全，南方夏火之純氣；申酉戌全，西方秋金之純氣；亥子丑全，北方冬水之純氣。方局力重於三合局。
- **Link kiểm chứng công khai:** [Wikisource - 子平真詮評註](https://zh.wikisource.org/wiki/子平真詮評註)
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf`.
- **Vị trí áp dụng:** Tập 03, Chương IV: "Tam Hội Phương Cục & Tam Hợp Cục đại chiến".

---

### [REF-03-008]
- **Nội dung / Khái niệm:** Tam Hợp Cục bản nguyên: Thân Tý Thìn Thủy, Hợi Mão Mùi Mộc, Dần Ngọ Tuất Hỏa, Tị Dậu Sửu Kim theo vòng 12 Cung Trường Sinh (Sinh - Vượng - Mộ).
- **Thể loại:** Kinh điển Tam Hợp Cổ pháp.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* - Thiên: "Hội Cục" (會局).
- **Nguyên văn Hán tự:** 
  > 生旺墓三者會局，變化莫測。申子辰會水，亥卯未會木，寅午戌會火，巳酉丑會金。局全者力純，半合者力薄。逢沖則局破，逢生則局固。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微 會局](https://zh.wikisource.org/wiki/滴天髓闡微#會局)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`.
- **Vị trí áp dụng:** Tập 03, Chương IV, Mục 4.2: "Cơ chế Tam Hợp Cục".

---

### [REF-03-009]
- **Nội dung / Khái niệm:** Thứ bậc ưu tiên và xung đột năng lượng giữa Tam Hội vs Tam Hợp vs Lục Hợp: "Tam Hội bạt Tam Hợp, Tam Hợp giải Lục Xung, Lục Hợp trói Tam Hợp".
- **Thể loại:** Động lực học tương tác Tử Bình.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* - Nhậm Thiết Tiều khảo chú.
- **Nguyên văn Hán tự:** 
  > 凡四柱干支，有合有沖，須看先後次第。方局力最強，三合次之，六合又次之。有三會則不以三合論，有三合則六合退位。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微](https://zh.wikisource.org/wiki/滴天髓闡微)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`.
- **Vị trí áp dụng:** Tập 03, Chương IV, Mục 4.3: "Thứ bậc ưu tiên tương tác".

---

### [REF-03-010]
- **Nội dung / Khái niệm:** Địa Chi Lục Xung bản nguyên: Tý Ngọ, Sửu Mùi, Dần Thân, Mão Dậu, Thìn Tuất, Tị Hợi & Tứ Đại Cấp Độ Xung Chấn.
- **Thể loại:** Kinh điển Lục Xung Cổ thư.
- **Xuất xứ cổ tịch:** *Tam Mệnh Thông Hội* - Quyển 3, Tiết: "Luận Địa Chi Lục Xung" (論地支六沖).
- **Nguyên văn Hán tự:** 
  > 夫沖者，對衡相克也。子午卯酉四敗之沖，寅申巳亥四生之沖，辰戌丑未四庫之沖。兩剛相搏，勢不兩立，必有一傷。
- **Link kiểm chứng công khai:** [Wikisource - 三命通會 卷三 六沖](https://zh.wikisource.org/wiki/三命通會/卷03)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf` & `Mệnh Lý huyền cơ tham bí.pdf`.
- **Vị trí áp dụng:** Tập 03, Chương V: "Địa Chi Lục Xung — Sức mạnh tàn phá & chuyển hóa bậc cao".

---

### [REF-03-011]
- **Nội dung / Khái niệm:** Phân cấp Lục Xung: Sinh Xung khốc liệt bạt căn khí thế, Bại Xung tranh đấu thanh thuần trọc tạp, Mộ Xung khố khai khí tán.
- **Thể loại:** Thực nghiệm Tử Bình kinh điển.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* - Thiên: "Xung Khắc Phụ Luận".
- **Nguyên văn Hán tự:** 
  > 寅申巳亥之沖，戰火最烈，傷及根本；子午卯酉之沖，專氣相剋，勝負分明；辰戌丑未之沖，雜氣相交，土愈動而愈旺，但其中藏金藏木必遭損害。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微](https://zh.wikisource.org/wiki/滴天髓闡微)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`.
- **Vị trí áp dụng:** Tập 03, Chương V, Mục 5.2: "Tứ đại cấp độ Lục Xung".

---

### [REF-03-012]
- **Nội dung / Khái niệm:** Chân Xung vs Giả Xung, Cận Xung liền trụ vs Viễn Xung cách trụ, Xung động vs Xung bạt căn.
- **Thể loại:** Mệnh lý học vi tế Trung Cận Đại.
- **Xuất xứ cổ tịch:** *Mệnh Lý Huyền Cơ Tham Bí* - Chương 7: "Lục Xung Hư Thực Biện".
- **Nguyên văn Hán tự:** 
  > 隣支相沖，為真沖，禍福立至；隔支相沖，為假沖，其力減半。本氣旺者沖衰，衰者拔；衰者沖旺，反激旺神之怒。
- **File đối chiếu nội bộ:** `Mệnh Lý huyền cơ tham bí.pdf` & `dự-báo-theo-tử-bình-trần-khang-ninh-pdf-dantocking.com.PDF`.
- **Vị trí áp dụng:** Tập 03, Chương V, Mục 5.3: "Chân xung vs Giả xung".

---

### [REF-03-013]
- **Nội dung / Khái niệm:** Địa Chi Tam Hình bản nguyên: Ân Tư Hình (Dần Tị Thân), Trì Thế Hình (Sửu Tuất Mùi), Vô Lễ Hình (Tý Mão) và Tự Hình (Thìn Ngọ Dậu Hợi).
- **Thể loại:** Kinh điển Tam Hình Cổ thư.
- **Xuất xứ cổ tịch:** *Tam Mệnh Thông Hội* - Quyển 3, Tiết: "Luận Tam Hình Chi Nghĩa" (論三刑之義).
- **Nguyên văn Hán tự:** 
  > 恩生於害，害生於恩，故曰恃勢、無恩、無禮。寅刑巳，巳刑申，申刑寅，為恃勢之刑；丑刑戌，戌刑未，未刑丑，為無恩之刑；子刑卯，卯刑子，為無禮之刑；辰辰、午午、酉酉、亥亥，為自刑。
- **Link kiểm chứng công khai:** [Wikisource - 三命通會 卷三 三刑](https://zh.wikisource.org/wiki/三命通會/卷03)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf` & `Thiên Lý Mệnh Cảo.pdf`.
- **Vị trí áp dụng:** Tập 03, Chương VI: "Địa Chi Tam Hình & Tự Hình".

---

### [REF-03-014]
- **Nội dung / Khái niệm:** Cơ chế nội chiến tàng can tàn khốc trong Tam Hình: Tàng can trong Dần (Giáp Bính Mậu), Tị (Bính Canh Mậu), Thân (Canh Nhâm Mậu) tương tàn lẫn nhau.
- **Thể loại:** Biện chứng tàng can Tam Hình vi tế.
- **Xuất xứ cổ tịch:** *Uyên Hải Tử Bình* - Quyển 2, Tiết: "Luận Tam Hình Tàng Can Khắc Chiến".
- **Nguyên văn Hán tự:** 
  > 三刑之烈，非在外支，而在支中所藏人元。寅中丙火刑申中庚金，申中壬水刑巳中丙火，巳中庚金刑寅中甲木，各相克戰，內傷至重。
- **Link kiểm chứng công khai:** [Wikisource - 淵海子平 三刑](https://zh.wikisource.org/wiki/淵海子平)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`.
- **Vị trí áp dụng:** Tập 03, Chương VI, Mục 6.2: "Nội chiến tàng can Tam Hình".

---

### [REF-03-015]
- **Nội dung / Khái niệm:** Địa Chi Lục Hại (Lục Xuyên) bản nguyên: Tý Mùi, Sửu Ngọ, Dần Tị, Mão Thìn, Thân Hợi, Dậu Tuất — Phá hoại hợp cục và vết thương ngầm gia đạo.
- **Thể loại:** Kinh điển Lục Hại Cổ pháp.
- **Xuất xứ cổ tịch:** *Tam Mệnh Thông Hội* - Quyển 3, Tiết: "Luận Lục Hại" (論六害).
- **Nguyên văn Hán tự:** 
  > 六害者，害其六合也。子合丑而未沖之，故子與未害；丑合子而午沖之，故丑與午害... 妨害骨肉，動骨傷殘。
- **Link kiểm chứng công khai:** [Wikisource - 三命通會 卷三 六害](https://zh.wikisource.org/wiki/三命通會/卷03)
- **File đối chiếu nội bộ:** `Mệnh Lý huyền cơ tham bí.pdf` & `Thiên Lý Mệnh Cảo.pdf`.
- **Vị trí áp dụng:** Tập 03, Chương VII: "Lục Hại (Xuyên) & Lục Phá — Vết thương ngầm gia đạo".

---

### [REF-03-016]
- **Nội dung / Khái niệm:** Sức phá hoại của Lục Xuyên (Hại) trong Manh Phái: "Xuyên tốc độ nhanh hơn Xung, lực tàn phá âm độc hơn Hình".
- **Thể loại:** Manh Phái Mệnh Lý Bí Bản.
- **Xuất xứ cổ tịch:** *Bát Tự Trân Bảo* - Hạ Trọng Kỳ khẩu thụ, Đoàn Kiến Nghiệp biên chú. Chương: "Luận Xuyên".
- **Nguyên văn Hán tự:** 
  > 盲派斷命，最重大運流年之穿。沖者明動，穿者暗毀。穿主暴病、暴禍、婚破、牢獄，其凶猛過於刑沖。
- **Link kiểm chứng công khai:** [ctext.org - 盲派命理](https://ctext.org)
- **File đối chiếu nội bộ:** `Bát tự trân bảo giảng nghĩa.docx` & `DKN - Bat Tu Luan Menh Bi Kiep.pdf`.
- **Vị trí áp dụng:** Tập 03, Chương VII, Mục 7.2: "Manh phái luận Xuyên".

---

### [REF-03-017]
- **Nội dung / Khái niệm:** Địa Chi Lục Phá bản nguyên: Tý Dậu, Mão Ngọ, Thìn Sửu, Tuất Mùi, Dần Hợi, Thân Tị — Biểu hiện của sự hao mòn nứt vỡ khí hóa.
- **Thể loại:** Cổ pháp Tử Bình.
- **Xuất xứ cổ tịch:** *Tam Mệnh Thông Hội* - Quyển 3, Tiết: "Luận Lục Phá" (論六破).
- **Nguyên văn Hán tự:** 
  > 破者，殘破散亂之意。子破酉，酉破子；卯破午，午破卯... 暗中消耗，破敗祖業，美事成磋跎。
- **Link kiểm chứng công khai:** [Wikisource - 三命通會 卷三](https://zh.wikisource.org/wiki/三命通會/卷03)
- **File đối chiếu nội bộ:** `Mệnh Lý huyền cơ tham bí.pdf`.
- **Vị trí áp dụng:** Tập 03, Chương VII, Mục 7.3: "Lục Phá toàn đồ".

---

### [REF-03-018]
- **Nội dung / Khái niệm:** Đại Ma Trận 144 Tổ Hợp Tương Tác Địa Chi Toàn Thư ($12 	imes 12$ độc lập): Phân loại Hợp, Xung, Hình, Hại, Phá, Bình hòa.
- **Thể loại:** Ma trận toán học hóa tương tác Địa Chi.
- **Xuất xứ:** Antigravity Master Engine Specification & Tổng hợp từ Tam Mệnh Thông Hội, Uyên Hải Tử Bình và Manh Phái.
- **Nguyên văn đặc tả:** 
  > Matrix $M_{12 	imes 12}$ định nghĩa trọn vẹn mọi tương tác giữa 12 Chi: từ Tý-Tý (Phục ngâm), Tý-Sửu (Lục hợp), Tý-Dần (Bình hòa), Tý-Mão (Hình), Tý-Thìn (Bán hợp), Tý-Tị (Ám hợp), Tý-Ngọ (Xung)... đến Hợi-Hợi (Tự hình).
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf` & `tu vung.docx`.
- **Vị trí áp dụng:** Tập 03, Chương VIII: "Đại Ma Trận 144 tổ hợp tương tác Địa Chi toàn thư".

---

### [REF-03-019]
- **Nội dung / Khái niệm:** Tuế Vận Tương Tác Cực Đoan: "Tam Chi Hội Xung" & "Lưỡng Khắc Nhất / Lưỡng Hợp Nhất".
- **Thể loại:** Động lực học biến cục kinh điển.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* - Thiên: "Tuế Vận Chinh Chiến" (歲運征戰).
- **Nguyên văn Hán tự:** 
  > 兩子沖一午，午火雖弱，逢旺生亦能激戰；三子沖一午，午根全拔，生死系之。兩干合一干，爭合不和；二支爭一合，妒合無功。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微](https://zh.wikisource.org/wiki/滴天髓闡微)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`.
- **Vị trí áp dụng:** Tập 03, Chương IX: "Chuyên đề Tuế Vận tương tác đa tầng & Biến cục phức tạp".

---

### [REF-03-020]
- **Nội dung / Khái niệm:** Thiên phú kinh điển: Bách Đoán Kinh & Khẩu Quyết Kim Châm định đoạt tương tác Can Chi.
- **Thể loại:** Thơ phú kinh điển Tử Bình.
- **Xuất xứ cổ tịch:** *Uyên Hải Tử Bình* - Quyển 4, Thiên: "Bách Đoán Kinh" (百斷經) & "Kim Châm Phú" (金針賦).
- **Nguyên văn Hán tự:** 
  > 地支相衝看緊慢，干支相剋辨幽微。支中透出天干用，衝破提綱禍自歸。五行各守其位，沖動則發；十神各司其柄，合著則停。
- **Link kiểm chứng công khai:** [Wikisource - 淵海子平 金針賦](https://zh.wikisource.org/wiki/淵海子平)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`.
- **Vị trí áp dụng:** Tập 03, Chương X: "Thiên phú kinh điển về tương tác Can Chi".

---

### [REF-03-021]
- **Nội dung / Khái niệm:** Kỳ án thực chiến: Giáp Kỷ Hợp Hóa Thổ Chân Hóa đắc Thìn Tuất Sửu Mùi đầy đủ làm đại quan cực phẩm.
- **Thể loại:** Kỳ án Hóa Khí Cách Chân Hóa.
- **Xuất xứ cổ tịch:** *Tử Bình Chân Thuyên Bình Chú* - Ca Hóa Thổ cách.
- **Nguyên văn Hán tự:** 
  > 乾造：戊辰、壬戌、甲辰、己巳。甲己化土，生於戌月，辰戌相沖，土氣沖蕩旺極，柱無木剋，真化之象，官居一品宰輔。
- **Link kiểm chứng công khai:** [Wikisource - 子平真詮評註](https://zh.wikisource.org/wiki/子平真詮評註)
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf`.
- **Vị trí áp dụng:** Tập 03, Chương XI: "Kỳ án Hợp Hóa Chân Cách".

---

### [REF-03-022]
- **Nội dung / Khái niệm:** Kỳ án thực chiến: Ất Canh hợp trói không hóa biến thành trắc trở công danh, phu thê hình khắc.
- **Thể loại:** Kỳ án Hợp Trói (Kỷ Bạng).
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* - Ca Hợp Trói.
- **Nguyên văn Hán tự:** 
  > 乙木合庚，生於夏令，金焦木枯，欲從不從，欲化不化。吉神被絆，終生無志，功名蹭蹬。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微](https://zh.wikisource.org/wiki/滴天髓闡微)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`.
- **Vị trí áp dụng:** Tập 03, Chương XI: "Kỳ án Hợp Trói".

---

### [REF-03-023]
- **Nội dung / Khái niệm:** Kỳ án thực chiến: Tý Ngọ tương xung chiến mãnh liệt dẫn đến thương tật huyết quang phẫu thuật.
- **Thể loại:** Kỳ án Lục Xung tàn phá.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* - Ca Tý Ngọ xung chiến.
- **Nguyên văn Hán tự:** 
  > 兩子沖兩午，水火交戰，全無引通。行至甲午流年，引動烈火，水激火發，目盲肢折。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微](https://zh.wikisource.org/wiki/滴天髓闡微)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`.
- **Vị trí áp dụng:** Tập 03, Chương XI: "Kỳ án Lục Xung Huyết Quang".

---

### [REF-03-024]
- **Nội dung / Khái niệm:** Kỳ án thực chiến: Dần Thân Tị Tam Hình lâm Thất Sát đại họa hình ngục tù đày.
- **Thể loại:** Kỳ án Tam Hình lâm Sát.
- **Xuất xứ cổ tịch:** *Tam Mệnh Thông Hội* - Quyển 3, Ca Tam Hình lao lý.
- **Nguyên văn Hán tự:** 
  > 歲運見寅申巳全，犯無恩恃勢之刑，更帶七煞白虎，罪犯法網，發配充軍。
- **Link kiểm chứng công khai:** [Wikisource - 三命通會 卷三](https://zh.wikisource.org/wiki/三命通會/卷03)
- **File đối chiếu nội bộ:** `Mệnh Lý huyền cơ tham bí.pdf`.
- **Vị trí áp dụng:** Tập 03, Chương XI: "Kỳ án Tam Hình Lao Lý".

---

### [REF-03-025]
- **Nội dung / Khái niệm:** Kỳ án thực chiến: Thìn Tuất tương xung khai Tài Khố bạo phát tài lộc chục triệu đô.
- **Thể loại:** Kỳ án Mộ Xung Khai Manh Phái.
- **Xuất xứ:** *Manh Phái Sơ, Trung, Cao Cấp Mệnh Lý Học* - Đoán tài sản Mộ Dụng.
- **Nguyên văn trích yếu:** 
  > Tọa hạ Thìn Thổ vi Tài khố, nguyên cục bế tắc, lâm vận Tuất xung khai, mở kho báu kinh doanh bạo phát hàng chục triệu lượng.
- **File đối chiếu nội bộ:** `Manh phái sơ , Trung, Cao cấp mệnh lý học.docx`.
- **Vị trí áp dụng:** Tập 03, Chương XI: "Kỳ án Xung Khai Tài Khố".

---

### [REF-03-026]
- **Nội dung / Khái niệm:** Kỳ án thực chiến: Tý Mùi Lục Hại (Tương Xuyên) phá vỡ Cung Phu Thê và hiếm muộn con cái.
- **Thể loại:** Kỳ án Lục Hại Phối Cung Gia Đạo.
- **Xuất xứ:** *Lục Thân Cao Cấp Diện Thụ* - Tiết: Xuyên Cung Hôn Nhân.
- **Nguyên văn trích yếu:** 
  > Nhật chi Tý phùng thời chi Mùi xuyên, phu thê cung bị tổn hại tàn nhẫn, vừa nhập đại vận Mùi ly hôn tán gia bại sản.
- **File đối chiếu nội bộ:** `Lục thân cao cấp diện thụ.docx`.
- **Vị trí áp dụng:** Tập 03, Chương XI: "Kỳ án Lục Hại Phu Thê".

---

### [REF-03-027]
- **Nội dung / Khái niệm:** Kỳ án thực chiến: Dần Hợi vừa Phá vừa Hợp cát hung đan xen tiền cát hậu hung.
- **Thể loại:** Kỳ án Tương Hợp Tương Phá song song.
- **Xuất xứ cổ tịch:** *Thiên Lý Mệnh Cảo* - Vi Thiên Lý, Khảo án Dần Hợi hợp phá.
- **Nguyên văn Hán tự:** 
  > 寅亥六合，木得生長；然寅中丙火逢亥中壬水暗破。吉處藏凶，初看似美，終落遺憾。
- **File đối chiếu nội bộ:** `Thiên Lý Mệnh Cảo.pdf`.
- **Vị trí áp dụng:** Tập 03, Chương XI: "Kỳ án Hợp Trung Hữu Phá".

---

### [REF-03-028]
- **Nội dung / Khái niệm:** Kỳ án thực chiến: Hợi Mão Mùi hội Mộc Cục thấu Ất Mộc thanh thuần đại phú đại quý vạn người ngưỡng mộ.
- **Thể loại:** Kỳ án Tam Hợp Cục Thanh Thuần.
- **Xuất xứ cổ tịch:** *Tử Bình Chân Thuyên Bình Chú* - Ca Khúc Trực Cách.
- **Nguyên văn Hán tự:** 
  > 支聚亥卯未，干透甲乙，不見庚辛金破，格成曲直仁壽，官居極品，壽逾古稀。
- **Link kiểm chứng công khai:** [Wikisource - 子平真詮評註](https://zh.wikisource.org/wiki/子平真詮評註)
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf`.
- **Vị trí áp dụng:** Tập 03, Chương XI: "Kỳ án Tam Hợp Thành Cục".

---

### [REF-03-029]
- **Nội dung / Khái niệm:** Kỳ án thực chiến: Thân Tý Thìn hội Thủy Cục xung bạt Đinh Ngọ hỏa trụ khiến chủ nhân đột quỵ não.
- **Thể loại:** Kỳ án Tam Hợp Xung Chi.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* - Ca Hội Cục Xung Trụ.
- **Nguyên văn Hán tự:** 
  > 四柱申子辰全，奔騰入海，行運午火之地，旺水衝滅烈火，心血立止，暴斃無疑。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微](https://zh.wikisource.org/wiki/滴天髓闡微)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`.
- **Vị trí áp dụng:** Tập 03, Chương XI: "Kỳ án Tam Hợp Xung Độc".

---

### [REF-03-030]
- **Nội dung / Khái niệm:** Kỳ án thực chiến: Tự Hình (Thìn Thìn, Dậu Dậu, Ngọ Ngọ, Hợi Hợi) tâm thần u uất, trầm cảm và tự vẫn.
- **Thể loại:** Kỳ án Tự Hình tâm bệnh.
- **Xuất xứ:** *Dự Đoán Theo Tứ Trụ* - Thiệu Vĩ Hoa, Chương: "Tai Họa Do Tự Hình".
- **Nguyên văn trích lược:** 
  > Trụ ngày Dậu gặp trụ năm Dậu, lại lâm lưu niên Dậu, tam Dậu tự hình Kim sắc bén tự cắt da thịt, nội tâm xung đột trầm cảm nặng.
- **File đối chiếu nội bộ:** `Dự Đoán Theo Tứ Trụ - Thiệu Vĩ Hoa.pdf`, tr. 156–160.
- **Vị trí áp dụng:** Tập 03, Chương VI & XI: "Kỳ án Tự Hình tâm thần".

---

# PHẦN I: DANH MỤC TRÍCH DẪN TẬP 04 (`04-thap-than-bien-chung-tam-ly.md`)

## 1. CÁC ĐOẠN KHẨU QUYẾT, PHÚ VĂN & LÝ THUYẾT NỀN TẢNG (CHƯƠNG I, II, III, XI)

### [REF-04-001]
- **Nội dung / Khái niệm:** Khẩu quyết Thập Thần Định Danh & Tương Sinh Tương Khắc Bản Nguyên.
- **Thể loại:** Kinh điển Tử Bình Chính Tông.
- **Xuất xứ cổ tịch:** *Uyên Hải Tử Bình* (淵海子平) - Tác giả: Từ Tử Bình (Từ Thăng biên tập). Quyển 1, Tiết: "Luận Ngũ Hành Sinh Khắc Định Thập Thần" (論五行生剋定十神).
- **Nguyên văn Hán tự:** 
  > 生我者為正印、偏印（梟神）；我生者為傷官、食神；剋我者為正官、七煞（偏官）；我剋者為正財、偏財；同我者為比肩、劫財（敗財）。
- **Link kiểm chứng công khai:** [Wikisource - 淵海子平 卷一](https://zh.wikisource.org/wiki/淵海子平)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf` & `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf` (Chương dẫn nhập Luận Thập Thần).
- **Vị trí áp dụng:** Tập 04, Chương I, Mục 1.1: "Bản thể học Thập Thần".

---

### [REF-04-002]
- **Nội dung / Khái niệm:** Bản thể Khí Hóa Ngũ Thường & Biện Chứng Tâm Tính (Mộc - Nhân, Hỏa - Lễ, Thổ - Tín, Kim - Nghĩa, Thủy - Trí).
- **Thể loại:** Cổ thư Mệnh lý & Triết học Khí hóa Đông Á.
- **Xuất xứ cổ tịch:** *Tam Mệnh Thông Hội* (三命通會) - Minh triều Vạn Dân Anh. Quyển 3, Tiết: "Luận Tính Tình Ngũ Hành Mộc Hỏa Thổ Kim Thủy" (論五行性情).
- **Nguyên văn Hán tự:** 
  > 木主仁，其性直，其情和，其味酸，其色青... 火主力，其性急，其情恭，其味苦，其色赤... 土主信，其性重，其情厚，其味甘，其色黃... 金主義，其性剛，其情烈，其味辛，其色白... 水主智，其性聰，其情善，其味鹹，其色黑。
- **Link kiểm chứng công khai:** [Wikisource - 三命通會 卷三 論五行性情](https://zh.wikisource.org/wiki/三命通會/卷03#論五行性情)
- **File đối chiếu nội bộ:** `Mệnh Ly huyền cơ tham bí.pdf` & `Mệnh lý tinh hoa.pdf`.
- **Vị trí áp dụng:** Tập 04, Chương II, Mục 2.1: "Khí hóa bản thể học & Ngũ Thường phối Thập Thần".

---

### [REF-04-003]
- **Nội dung / Khái niệm:** Tính tình cương nhu, trọc thanh biến dịch của Thập Thần trong Trích Thiên Tủy.
- **Thể loại:** Kinh điển Tử Bình Cương lĩnh.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* (滴天髓闡微) - Lưu Bá Ôn nguyên tác, Nhậm Thiết Tiều khảo chú. Thượng quyển, Thiên: "Tính Tình" (性情).
- **Nguyên văn Hán tự:** 
  > 五氣不戾，性情中和；濁亂偏枯，性情乖逆。火烈而燥者淫，水奔而弱者蕩，木奔而旺者仁，金剛而燥者義，土重而厚者信。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微 性情](https://zh.wikisource.org/wiki/滴天髓闡微#性情)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`, Quyển Thượng, Chương Tính Tình.
- **Vị trí áp dụng:** Tập 04, Chương II, Mục 2.2: "Luận Tính Tình Cương Nhu Của Nhậm Thiết Tiều".

---

### [REF-04-004]
- **Nội dung / Khái niệm:** Khẩu quyết Chính Quan & Thất Sát Tâm Tính Chi Phân (Chính Quan đoan chính, Thất Sát cương liệt hung bạo).
- **Thể loại:** Cổ thi phú Mệnh lý.
- **Xuất xứ cổ tịch:** *Uyên Hải Tử Bình* - Quyển 3, Tiết: "Kế Thiện Thiên" (繼善篇).
- **Nguyên văn Hán tự:** 
  > 官星提綱，溫良恭儉；煞刃同位，慷慨威嚴。一煞投江，何妨舟楫；重官不貴，反作儈徒。
- **Link kiểm chứng công khai:** [Wikisource - 淵海子平 繼善篇](https://zh.wikisource.org/wiki/淵海子平/卷三#繼善篇)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf` & `Tử Bình Chân Thuyên...pdf`.
- **Vị trí áp dụng:** Tập 04, Chương III, Mục 3.1: "Biện chứng Quan Sát tâm tính".

---

### [REF-04-005]
- **Nội dung / Khái niệm:** Đông y Bệnh Cơ Học: Đàm Hỏa Mê Tâm Khiếu & Điên Cuồng Khác Loạn.
- **Thể loại:** Y thư kinh điển Đông Y & Mệnh lý Tật Ách.
- **Xuất xứ cổ tịch:** *Hoàng Đế Nội Kinh - Tố Vấn* (黃帝內經·素問), Thiên "Điên Cuồng Luận" (癲狂論) kết hợp *Tam Mệnh Thông Hội* - Quyển 5, Thiên "Luận Tật Ách" (論疾病).
- **Nguyên văn Hán tự:** 
  > 火炎土燥，心經受病，痰火上壅，迷閉心竅，狂易發越；水狂木浮，神魂游蕩；土重木折，鬱結不舒。
- **Link kiểm chứng công khai:** [Chinese Text Project - 素問 癲狂](https://ctext.org/huangdi-neijing/dian-kuang) & [Wikisource - 三命通會 卷五 論疾病](https://zh.wikisource.org/wiki/三命通會)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf` (Thiên Tật Bệnh).
- **Vị trí áp dụng:** Tập 04, Chương XI, Mục 11.1: "Tử Bình Bệnh Cơ Học: Thập Thần Biến Cách & Tâm Thần Loạn Trực".

---

## 2. 10 KỲ ÁN CỔ ĐIỂN KHẢO CHỨNG CHUẨN XÁC (CHƯƠNG XIII - PHẦN 1)

### [REF-04-006]
- **Nhân vật & Chức vụ:** Càn Long Hoàng Đế (Thanh Cao Tông Ái Tân Giác La Hoằng Lịch).
- **Tứ trụ Can Chi:** **Tân Mão - Đinh Dậu - Canh Ngọ - Bính Tý**
- **Thể loại:** Đế vương Kỳ án - Tý Ngọ Mão Dậu Tứ chính toàn bị.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* (滴天髓闡微) - Nhậm Thiết Tiều khảo chú. Thượng quyển, Thiên: "Địa Chi" (地支).
- **Nguyên văn Hán tự:** 
  > 此乾隆皇帝造。子午卯酉，成坎離震兌，四方正氣，無氣偏倚，地苞南北，氣貫東西，又何嫌乎相沖相剋？政所謂乾坤氣足，天道日生，所以福壽俱全，聖神文武，南巡北狩，四海順從...
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微 地支](https://zh.wikisource.org/wiki/滴天髓闡微#地支)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`, Quyển Thượng, Chương Địa Chi.
- **Vị trí áp dụng:** Tập 04, Chương XIII, Kỳ án 01.

---

### [REF-04-007]
- **Nhân vật & Chức vụ:** Nhạc Phi (Nam Tống Kháng Kim Danh tướng - Nhạc Võ Mục Vương, Tống Sử Liệt Truyện quyển 365).
- **Tứ trụ Can Chi:** **Quý Mùi - Ất Mão - Giáp Tý - Kỷ Tỵ**
- **Thể loại:** Trung thần Liệt sĩ Kỳ án - Dương Nhận hung bạo quy tụ, Tham hợp vong sinh.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* - Quyển Thượng, Thiên: "Cương Nhu" (剛柔).
- **Nguyên văn Hán tự:** 
  > 岳武穆造，癸未、乙卯、甲子、己巳。甲木生於仲春，乙卯並旺，陽刃逞凶，喜巳火風雷相激，引通木性，然癸水生刃，巳火歸時，合己化土，暗損印綬。至辛運，辛金剋乙，直犯旺神，風波之禍不免。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微 剛柔](https://zh.wikisource.org/wiki/滴天髓闡微#剛柔)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`, Quyển Thượng, Chương Cương Nhu.
- **Vị trí áp dụng:** Tập 04, Chương XIII, Kỳ án 02.

---

### [REF-04-008]
- **Nhân vật & Chức vụ:** Lưu Bá Ôn (Minh triều Khai quốc Công thần - Thành Ý Bá Lưu Cơ, Minh Sử quyển 128).
- **Tứ trụ Can Chi:** **Tân Hợi - Giáp Ngọ - Ất Tỵ - Nhâm Ngọ**
- **Thể loại:** Thần cơ Diệu toán Kỳ án - Thương quan tiết tú, Thủy hỏa ký tế.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* - Quyển Thượng, Thiên: "Thuận Nghịch" (順逆) / Phương Cục.
- **Nguyên văn Hán tự:** 
  > 此劉伯溫先生造。乙木生於仲夏，火旺木焦，得辰土（亥水）潤澤，年逢辛亥，時透壬水，水氣充沛，潤木生身，火氣流暢，文韜武略，開創一代規模。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微 順逆](https://zh.wikisource.org/wiki/滴天髓闡微)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`, Quyển Thượng.
- **Vị trí áp dụng:** Tập 04, Chương XIII, Kỳ án 03.

---

### [REF-04-009]
- **Nhân vật & Chức vụ:** Tăng Quốc Phiên (Thanh triều Lưỡng Giang Tổng đốc, Đại học sĩ, Thái tử Thái bảo - Tăng Văn Chính Công).
- **Tứ trụ Can Chi:** **Tân Mùi - Kỷ Hợi - Bính Thìn - Kỷ Hợi**
- **Thể loại:** Nho tướng Trấn quốc Kỳ án - Thất sát phùng chế, Thương quan khống chế sát thần.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Bình Chú* (Từ Nhạc Ngô chú giải) & *Thiên Lý Mệnh Cảo* (Vi Thiên Bằng khảo lục).
- **Nguyên văn Hán tự:** 
  > 曾文正公命造，辛未、己亥、丙辰、己亥。丙火生於孟冬，亥中壬水七煞當令，兩透己土傷官以制煞，辰未培火根，日主弱中有氣，大運一路東南木火，化煞生身，削平大難，勳業烜赫。
- **Link kiểm chứng công khai:** [Chinese Text Project - 子平真詮評註](https://ctext.org/wiki.pl?if=gb&res=631975)
- **File đối chiếu nội bộ:** `Thiên Lý Mệnh Cảo.pdf` (Quyển 4: Danh Nhân Mệnh Cảo) & `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf`.
- **Vị trí áp dụng:** Tập 04, Chương XIII, Kỳ án 04.

---

### [REF-04-010]
- **Nhân vật & Chức vụ:** Nhậm Thiết Tiều (Đại sư chú giải kinh điển Mệnh học thời Thanh - Tự trần bản mệnh).
- **Tứ trụ Can Chi:** **Kỷ Tỵ - Đinh Mão - Bính Dần - Nhâm Thìn**
- **Thể loại:** Mệnh học Tông sư Mệnh giải - Mộc hỏa quá vượng, Nhâm thủy vô căn túng hỷ vi họa.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* - Quyển Hạ, Thiên: "Thể Dụng" (體用).
- **Nguyên văn Hán tự:** 
  > 余自審命造，己巳、丁卯、丙寅、壬辰。丙火生於仲春，印綬當令，木火雙清，日主極旺。時透壬水，看似殺印相生，不知辰土蓄水生木，壬水無根，逢金運逆木之性，破耗異常；早年富厚，中年落魄，晚岁藉命理糊口。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微 體用](https://zh.wikisource.org/wiki/滴天髓闡微#體用)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`, Quyển Hạ, Nhậm thị tự thuật.
- **Vị trí áp dụng:** Tập 04, Chương XIII, Kỳ án 05.

---

### [REF-04-011]
- **Nhân vật & Chức vụ:** Tiền Đoan Lễ (Nam Tống Thượng thư Hữu thừa, Lại bộ Thượng thư - Tống Sử quyển 385).
- **Tứ trụ Can Chi:** **Nhâm Ngọ - Kỷ Dậu - Canh Dần - Giáp Thân**
- **Thể loại:** Thượng thư quý cách - Thương quan bội ấn, Nguyệt lệnh Dương Nhận chuyển hóa vi cách.
- **Xuất xứ cổ tịch:** *Tử Bình Chân Thuyên* (Thẩm Hiếu Triêm nguyên tác) - Chương 18: "Luận Thương Quan" (論傷官).
- **Nguyên văn Hán tự:** 
  > 錢端禮尚書命，壬午、己酉、庚寅、甲申。庚生酉月，陽刃秉令，時透甲木，年透壬水，傷官生財，印綬己土透出以制傷，格成傷官佩印，兼之官星得祿於午，大貴之徵也。
- **Link kiểm chứng công khai:** [Chinese Text Project - 子平真詮 論傷官](https://ctext.org/wiki.pl?if=gb&res=631975)
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf`, Chương 18: Luận Thương Quan.
- **Vị trí áp dụng:** Tập 04, Chương XIII, Kỳ án 06.

---

### [REF-04-012]
- **Nhân vật & Chức vụ:** Lương Khắc Gia (Nam Tống Tả Thừa tướng, Lịch sự văn học Trạng nguyên - Tống Sử quyển 384).
- **Tứ trụ Can Chi:** **Kỷ Dậu - Ất Hợi - Đinh Sửu - Quý Mão**
- **Thể loại:** Tể tướng Trạng nguyên cách - Sát phùng Thực chế, Ấn thụ hóa Sát trợ thân.
- **Xuất xứ cổ tịch:** *Tử Bình Chân Thuyên* - Chương 16: "Luận Sát" (論煞).
- **Nguyên văn Hán tự:** 
  > 梁克家丞相命，己酉、乙亥、丁丑、癸卯。丁火生於亥月，癸水七煞透出，年透己土食神，殺逢食制。亥卯會木局以化殺生身，制化得宜，貴登宰輔。
- **Link kiểm chứng công khai:** [Chinese Text Project - 子平真詮 論煞](https://ctext.org/wiki.pl?if=gb&res=631975)
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf`, Chương 16: Luận Sát.
- **Vị trí áp dụng:** Tập 04, Chương XIII, Kỳ án 07.

---

### [REF-04-013]
- **Nhân vật & Chức vụ:** Thẩm Nhất Quán (Thẩm Triều Dương Thừa tướng - Minh triều Vạn Lịch Nội các Thủ phụ, Minh Sử quyển 218).
- **Tứ trụ Can Chi:** **Kỷ Hợi - Đinh Mão - Bính Thân - Canh Dần**
- **Thể loại:** Thủ phụ Tể thần cách - Ấn vượng thân cường, Dụng tài phá ấn thủ quý.
- **Xuất xứ cổ tịch:** *Tử Bình Chân Thuyên* - Chương 14: "Luận Ấn Thụ" (論印綬).
- **Nguyên văn Hán tự:** 
  > 沈朝陽丞相命，己亥、丁卯、丙申、庚寅。丙火生於卯月，木旺火塞，日坐申金偏財，時透庚金，印旺身強，用財破印，更喜寅申相沖以去太過，運行得地，位列首輔。
- **Link kiểm chứng công khai:** [Chinese Text Project - 子平真詮 論印綬](https://ctext.org/wiki.pl?if=gb&res=631975)
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf`, Chương 14: Luận Ấn Thụ.
- **Vị trí áp dụng:** Tập 04, Chương XIII, Kỳ án 08.

---

### [REF-04-014]
- **Nhân vật & Chức vụ:** Trương Tứ Duy (Minh triều Binh bộ Thượng thư, Lại bộ Thượng thư, Trung Cực điện Đại học sĩ - Minh Sử quyển 219).
- **Tứ trụ Can Chi:** **Mậu Tuất - Canh Thân - Quý Mão - Canh Thân**
- **Thể loại:** Danh thần Khanh tướng cách - Ấn trọng quan thấu, Thân nhược hóa vượng, Vận nhập Hỏa Thổ hiển hách.
- **Xuất xứ cổ tịch:** *Tử Bình Chân Thuyên* - Chương 15: "Luận Ấn Thụ Thủ Vận" (論印綬取運).
- **Nguyên văn Hán tự:** 
  > 張四維尚書命，戊戌、庚申、癸卯、庚申。秋金重重，印綬太過，癸水借申中壬水通根，戊戌官星透出生印。印重身強，取官星為用，大運喜財官之鄉，入南離之火運，大魁天下，出將入相。
- **Link kiểm chứng công khai:** [Chinese Text Project - 子平真詮 論印綬取運](https://ctext.org/wiki.pl?if=gb&res=631975)
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf`, Chương 15: Luận Ấn Thụ Thủ Vận.
- **Vị trí áp dụng:** Tập 04, Chương XIII, Kỳ án 09.

---

### [REF-04-015]
- **Nhân vật & Chức vụ:** Lý Vệ (Thanh triều Văn Khang Công - Trực Lệ Tổng đốc, Hình bộ Thượng thư - Thanh Sử Cảo quyển 294).
- **Tứ trụ Can Chi:** **Đinh Mão - Quý Mão - Bính Thìn - Canh Dần**
- **Thể loại:** Trực thần Phong cương đại thần - Quan ấn tương sinh, Mộc hỏa thông minh, Kiên trinh chấp pháp.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Bình Chú* & *Tử Bình Chân Thuyên Bình Chú* (Từ Nhạc Ngô chú giải mục Quan Ấn Cách).
- **Nguyên văn Hán tự:** 
  > 李衛公總督造，丁卯、癸卯、丙辰、庚寅。二月丙火，木旺火熾，年透丁火劫財，喜癸水官星透出，泄庚生印，去劫護財。爲官清正剛烈，雷厲風行，名垂史冊。
- **Link kiểm chứng công khai:** [Chinese Text Project - 子平真詮評註](https://ctext.org/wiki.pl?if=gb&res=631975)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf` & `Tử Bình Chân Thuyên...pdf`.
- **Vị trí áp dụng:** Tập 04, Chương XIII, Kỳ án 10.

---

## 3. 10 KỲ ÁN MANH PHÁI TRUNG CẬN ĐẠI (CHƯƠNG XIII - PHẦN 2)
*(Trích lục nguyên văn từ các tài liệu khẩu truyền thực chiến của Đoàn Kiến Nghiệp & Hách Kim Dương trong thư mục nội bộ)*

### [REF-04-016]
- **Tiêu đề / Mệnh chủ:** Bí truyền sinh con, định kỳ hỷ sự & kiện tụng phát sinh năm Mậu Thìn.
- **Tứ trụ Can Chi:** **Mậu Tuất - Kỷ Mùi - Ất Tỵ - Đinh Hợi** (Nam mệnh sinh ngày 27/7/1958).
- **Thể loại:** Manh phái Bí truyền Khảo nghiệm - Hôn nhân & Tử tức.
- **Xuất xứ tài liệu:** *Bát Tự Trân Bảo Giảng Nghĩa* - Đoàn Kiến Nghiệp & Hách Kim Dương. Kỳ 1: "Bí truyền sanh hài tử".
- **Đoạn trích đối chiếu:**
  > Hách tiên sinh tại mùa xuân năm Mậu Thìn phân quyết: "Ngươi năm nay sinh con không được, năm nay vợ lại mang thai." Mệnh chủ hỏi: "Ngươi xem ta năm nay đường xe thế nào?" Hách tiên sinh đáp: "Ngươi chỉ nên bảo dưỡng xe, nếu không ngươi sẽ mất tiền, năm nay ngươi có 2 trận kiện tụng." Tất cả phân quyết toàn bộ ứng nghiệm...
- **File đối chiếu nội bộ:** `Bát tự trân bảo giảng nghĩa.docx` (Kỳ 1) & `MỆNH LÝ TRÂN BẢO GIẢNG NGHĨA.pdf`.
- **Vị trí áp dụng:** Tập 04, Chương XIII, Kỳ án 11.

---

### [REF-04-017]
- **Tiêu đề / Mệnh chủ:** Khắc Thê Mệnh Lý - Thê Tinh Bị Khắc Mộ Lưỡng Thương.
- **Tứ trụ Can Chi:** **Canh Thìn - Kỷ Mão - Giáp Tuất - Giáp Tý** (Nam mệnh).
- **Thể loại:** Manh phái Lục thân Cao cấp - Hôn nhân sinh ly tử biệt.
- **Xuất xứ tài liệu:** *Lục Thân Cao Cấp Diện Thụ* - Đoàn Kiến Nghiệp. Chương 1: Hôn nhân chuyên tập, Tiết 6: Thương khắc phối ngẫu phán đoán.
- **Đoạn trích đối chiếu:**
  > Thê cung tọa Tuất thổ là thê tinh, nguyệt lệnh Mão mộc hợp khắc Tuất thổ, lại có Canh kim thấu xuất tọa Thìn thổ... Thê tinh nhập mộ phùng hình xung, đệ nhất nhậm thê tử bệnh vong, đệ nhị nhậm ly dị phá sản.
- **File đối chiếu nội bộ:** `Lục thân cao cấp diện thụ.docx` (Chương 1, Tiết 6).
- **Vị trí áp dụng:** Tập 04, Chương XIII, Kỳ án 12.

---

### [REF-04-018]
- **Tiêu đề / Mệnh chủ:** Đa Phối Ngẫu Hôn Nhân - Bao Cục Mệnh Lý.
- **Tứ trụ Can Chi:** **Quý Tỵ - Giáp Dần - Đinh Mão - Canh Tý** (Nữ mệnh).
- **Thể loại:** Manh phái Lục thân Cao cấp - Phân tích cục diện ngoại tình & ly hôn.
- **Xuất xứ tài liệu:** *Lục Thân Cao Cấp Diện Thụ* - Đoàn Kiến Nghiệp. Chương 1, Tiết 2 & Tiết 4: "Bao cục hôn nhân phán đoán".
- **Đoạn trích đối chiếu:**
  > Quan tinh tọa niên chi Tỵ hỏa tàng Canh kim, thời chi Tý thủy phục ngâm, phu cung Mão mộc tương hình. Cung phu thê hỗn tạp, tất định nhị hôn tam giá.
- **File đối chiếu nội bộ:** `Lục thân cao cấp diện thụ.docx` (Chương 1, Lệ 4).
- **Vị trí áp dụng:** Tập 04, Chương XIII, Kỳ án 13.

---

### [REF-04-019]
- **Tiêu đề / Mệnh chủ:** Độc Thân Cực Phẩm Mệnh Lý - Chiếm Ấn Khuyết Quan.
- **Tứ trụ Can Chi:** **Bính Thìn - Tân Sửu - Giáp Dần - Đinh Mão** (Nữ mệnh).
- **Thể loại:** Manh phái Lục thân Cao cấp - Độc thân bất hôn cục.
- **Xuất xứ tài liệu:** *Lục Thân Cao Cấp Diện Thụ* - Đoàn Kiến Nghiệp. Chương 1, Tiết 7: "Độc thân tổ hợp".
- **Đoạn trích đối chiếu:**
  > Nhật chủ tọa Lộc quy thời lâm Dương Nhận, bát tự thuần âm thổ kim vượng nhi vô quan tinh thấu hiển, ấn kiếp chiếm trọn phu vị, chung thân bất giá.
- **File đối chiếu nội bộ:** `Lục thân cao cấp diện thụ.docx` (Chương 1, Tiết 7).
- **Vị trí áp dụng:** Tập 04, Chương XIII, Kỳ án 14.

---

### [REF-04-020]
- **Tiêu đề / Mệnh chủ:** Manh phái Quản lý Tài vận - Khố Phùng Khai Xung Khởi Đại Phú.
- **Tứ trụ Can Chi:** **Đinh Mùi - Quý Sửu - Canh Thìn - Kỷ Mão** (Nam mệnh đại phú).
- **Thể loại:** Manh phái Tài vận & Công vị Thực chiến.
- **Xuất xứ tài liệu:** *Bát Tự Trân Bảo Giảng Nghĩa* - Đoàn Kiến Nghiệp. Tiết: "Luận Tài Khố Khai Bế".
- **Đoạn trích đối chiếu:**
  > Sửu Mùi tương xung, tài khố xung khai vi dụng... vận nhập Giáp Dần, Ất Mão đại phát tài sản trăm triệu, do Thìn thổ thu nạp tài khí thành tựu công nghiệp.
- **File đối chiếu nội bộ:** `Bát tự trân bảo giảng nghĩa.docx` & `MỆNH LÝ TRÂN BẢO GIẢNG NGHĨA.pdf`.
- **Vị trí áp dụng:** Tập 04, Chương XIII, Kỳ án 15.

---

# PHẦN II: DANH MỤC TRÍCH DẪN TẬP 05 (`05-tu-dai-phap-mon-thu-dung-than.md`)

## 1. CÁC ĐOẠN KHẨU QUYẾT, PHÚ VĂN & LÝ THUYẾT NỀN TẢNG (CHƯƠNG I ĐẾN CHƯƠNG VIII)

### [REF-05-001]
- **Nội dung / Khái niệm:** Định nghĩa Dụng Thần bản thể, Phù Ức & Cơ chế Cân bằng Toàn cục của Nhậm Thiết Tiều.
- **Thể loại:** Kinh điển Tử Bình Cương lĩnh.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* (滴天髓闡微) - Lưu Bá Ôn nguyên tác, Nhậm Thiết Tiều khảo chú. Thượng quyển, Thiên: "Dụng Thần" (用神).
- **Nguyên văn Hán tự:** 
  > 八字之用神，專求於月令，無則尋於別支。然必須審其衰旺，量其進退。有餘則洩之，不足則益之，此天地之中和也。若用神無氣，縱得富貴，亦不久長。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微 用神](https://zh.wikisource.org/wiki/滴天髓闡微#用神)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`, Quyển Thượng, Chương Dụng Thần (trang 112–125).
- **Vị trí áp dụng:** Tập 05, Chương I, Mục 1.1 & Mục 2.2: "Bản thể luận Dụng Thần & Phái Cân Bằng Toàn Cục".

---

### [REF-05-002]
- **Nội dung / Khái niệm:** Nguyệt Lệnh Đương Đề vi Dụng Thần & Phân loại Bát Cách Chính Tông của Trầm Hiếu Thắng.
- **Thể loại:** Kinh điển Tử Bình Cách cục.
- **Xuất xứ cổ tịch:** *Tử Bình Chân Thuyên* (子平真詮) - Trầm Hiếu Thắng nguyên tác, Từ Nhạc Ngô bình chú. Thiên: "Luận Dụng Thần" (論用神).
- **Nguyên văn Hán tự:** 
  > 八字用神，專求月令，以日干配月令地支，而生剋不同，格局分焉。財官印食，此用神之善而順用之者也；煞傷梟敗，此用神之不善而逆用之者也。
- **Link kiểm chứng công khai:** [Wikisource - 子平真詮 論用神](https://zh.wikisource.org/wiki/子平真詮#論用神)
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf`, Tiết: Luận Dụng Thần (trang 18–26).
- **Vị trí áp dụng:** Tập 05, Chương I, Mục 2.1: "Phái Nguyệt Lệnh Cách Thần của Trầm Hiếu Thắng".

---

### [REF-05-003]
- **Nội dung / Khái niệm:** Biện chứng Chân - Giả Dụng Thần & Thần Khí Đắc Lệnh / Hư Phù.
- **Thể loại:** Kinh điển Tử Bình Khí thế.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* (滴天髓闡微) - Lưu Bá Ôn nguyên tác, Nhậm Thiết Tiều khảo chú. Thượng quyển, Thiên: "Chân Giả" (真假).
- **Nguyên văn Hán tự:** 
  > 令上尋真聚在真，假神休要亂真神。真神得用生平貴，用假終為碌碌人。真者，得時秉令之神也；假者，失時退氣之神也。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微 真假](https://zh.wikisource.org/wiki/滴天髓闡微#真假)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`, Quyển Thượng, Chương Chân Giả.
- **Vị trí áp dụng:** Tập 05, Chương III, Mục 1 & Mục 2: "Biện chứng Chân - Giả Dụng Thần & Năng lực thực thi".

---

### [REF-05-004]
- **Nội dung / Khái niệm:** Bản thể Khí hậu Điều Hậu Bát Can: Hàn - Noãn - Táo - Thấp & Bính Hỏa / Quý Thủy vi Tôn.
- **Thể loại:** Kinh điển Khí tượng Mệnh lý.
- **Xuất xứ cổ tịch:** *Cùng Thông Bảo Giám* (窮通寶鑑 - Lan Giang Vọng) - Dư Xuân Đài biên tập, Từ Nhạc Ngô bình chú. Thiên: "Tổng Luận Mộc Hỏa Thổ Kim Thủy Tứ Thời Khí Thế".
- **Nguyên văn Hán tự:** 
  > 凡五行之氣，不可偏枯。冬水太寒，無丙火溫之則凍冰不生；夏火太烈，無癸水潤之則枯槁不榮。故調候之法，以丙癸為樞紐，寒暖適中，萬物化生。
- **Link kiểm chứng công khai:** [Wikisource - 窮通寶鑑](https://zh.wikisource.org/wiki/窮通寶鑑)
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf` (Chương Phối hợp Điều Hậu) & `Thiên Lý Mệnh Cảo.pdf` (Chương Điều Hậu Thủ Dụng).
- **Vị trí áp dụng:** Tập 05, Chương V, Mục 1 & Mục 4: "Bản thể sinh học Điều Hậu & Thứ tự ưu tiên tuyệt đối".

---

### [REF-05-005]
- **Nội dung / Khái niệm:** Cơ chế Thông Quan: Lưỡng khí tương đối tất tu cầu hòa, Lục đại thế trận giao tranh.
- **Thể loại:** Kinh điển Tử Bình Động lực học.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* (滴天髓闡微) - Lưu Bá Ôn nguyên tác, Nhậm Thiết Tiều khảo chú. Hạ quyển, Thiên: "Thông Quan" (通關).
- **Nguyên văn Hán tự:** 
  > 兩氣雙清，非通關則不可；兩氣爭勝，得通關以成和。如木土交戰，用火化之；水火相衝，用木以通之。通關者，引通兩者之氣，化敵為友也。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微 通關](https://zh.wikisource.org/wiki/滴天髓闡微#通關)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`, Quyển Hạ, Chương Thông Quan.
- **Vị trí áp dụng:** Tập 05, Chương VI, Mục 1 & Mục 2: "Cơ học Lưỡng khí tương tranh & Lục đại tổ hợp Thông Quan".

---

### [REF-05-006]
- **Nội dung / Khái niệm:** Biện chứng Bệnh Dược: "Hữu bệnh phương vi quý, vô thương bất vi kỳ".
- **Thể loại:** Kinh điển Biện chứng Y Mệnh đồng nguyên.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* (滴天髓闡微) - Lưu Bá Ôn nguyên tác, Nhậm Thiết Tiều khảo chú. Hạ quyển, Thiên: "Bệnh Dược" (病藥).
- **Nguyên văn Hán tự:** 
  > 凡造有病，方為大貴。何謂病？原局中有一物滯礙，不能流通，或太過，或不及。何謂藥？能去其滯礙，損其有餘，補其不足者，皆藥也。格中如去病，財祿兩相隨。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微 病藥](https://zh.wikisource.org/wiki/滴天髓闡微#病藥)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`, Quyển Hạ, Chương Bệnh Dược.
- **Vị trí áp dụng:** Tập 05, Chương VII, Mục 1 & Mục 3: "Triết lý biện chứng Trích Thiên Tủy & Phương thuốc Dược thần".

---

### [REF-05-007]
- **Nội dung / Khái niệm:** Khí hậu Hàn Noãn Thể dụng: "Hàn tuy thậm, nhiệt chi tất phát; Noãn tuy thậm, hàn chi tất hòa".
- **Thể loại:** Kinh điển Khí tượng Cân bằng.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* (滴天髓闡微) - Lưu Bá Ôn nguyên tác, Nhậm Thiết Tiều khảo chú. Thượng quyển, Thiên: "Hàn Noãn" (寒暖).
- **Nguyên văn Hán tự:** 
  > 得時俱為旺，失時俱為衰。寒雖甚，熱之必發；暖雖甚，寒之必和。大過與不及，皆為偏枯，能濟其偏者，吉莫大焉。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微 寒暖](https://zh.wikisource.org/wiki/滴天髓闡微#寒暖)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`, Quyển Thượng, Chương Hàn Noãn.
- **Vị trí áp dụng:** Tập 05, Chương V, Mục 1 & Mục 2: "Điều Hậu Pháp Môn & Mùa đông băng giá".

---

### [REF-05-008]
- **Nội dung / Khái niệm:** Cương lĩnh Chân Tòng, Giả Tòng & Tòng Thần luận của Nhậm Thiết Tiều.
- **Thể loại:** Kinh điển Biến cách Tử Bình.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* (滴天髓闡微) - Lưu Bá Ôn nguyên tác, Nhậm Thiết Tiều khảo chú. Thượng quyển, Thiên: "Tòng Tượng" (從象).
- **Nguyên văn Hán tự:** 
  > 從得真者只論從，從神休要帶刑沖。原局印綬無根氣，食傷財煞俱乘權。假從亦可借名利，一遇破格禍立纏。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微 從象](https://zh.wikisource.org/wiki/滴天髓闡微#從象)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`, Quyển Thượng, Chương Tòng Tượng.
- **Vị trí áp dụng:** Tập 05, Chương VIII, Mục 2 & Mục 3: "Tòng Nhược cách & Chân tòng vs Giả tòng".

---

### [REF-05-009]
- **Nội dung / Khái niệm:** Quy tắc Kế Thiện Thiên định Dụng thần theo Nhật chủ vượng suy và Ngũ hành đắc sở.
- **Thể loại:** Kinh điển Ca phú Tử Bình.
- **Xuất xứ cổ tịch:** *Uyên Hải Tử Bình* (淵海子平) - Từ Tử Bình nguyên trứ. Quyển 3, Tiết: "Kế Thiện Thiên" (繼善篇).
- **Nguyên văn Hán tự:** 
  > 若要發貴，專求月令之提綱；欲辨衰旺，先審四柱之根柢。夫用神者，吉凶之樞機，禍福之根本。身旺逢官，平生顯達；身衰得印，晚景榮昌。
- **Link kiểm chứng công khai:** [Wikisource - 淵海子平 卷三 繼善篇](https://zh.wikisource.org/wiki/淵海子平/卷三#繼善篇)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf` & `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf` (Chương Phụ Lục Ca Phú).
- **Vị trí áp dụng:** Tập 05, Chương I, Mục 1.2 & Chương XIII: "100 Khẩu Quyết Thủ Dụng Thần".

---

### [REF-05-010]
- **Nội dung / Khái niệm:** Ngũ Đại Pháp Môn Tổng Luận trong Tam Mệnh Thông Hội của Vạn Dân Anh.
- **Thể loại:** Toàn thư Mệnh lý Bách khoa.
- **Xuất xứ cổ tịch:** *Tam Mệnh Thông Hội* (三命通會) - Minh triều Vạn Dân Anh trứ. Quyển 4, Tiết: "Luận Thiên Can Thống Tạp Dụng Thần Cương Lĩnh" (論天干用神).
- **Nguyên văn Hán tự:** 
  > 凡看命造，先觀月令，以日干定吉凶。取用之法，或扶其弱，或抑其強，或調其寒溫，或通其關隔，或治其宿疾。五者備而命法通矣。
- **Link kiểm chứng công khai:** [Wikisource - 三命通會 卷四](https://zh.wikisource.org/wiki/三命通會/卷04)
- **File đối chiếu nội bộ:** `Mệnh Ly huyền cơ tham bí.pdf` & `Mệnh lý tinh hoa.pdf`.
- **Vị trí áp dụng:** Tập 05, Lời dẫn nhập & Chương II, Mục 6: "Đại Ma Trận Ngũ Cấp Thần Vị".

---

## 2. CÁC MỆNH TẠO THỰC NGHIỆM ĐỐI CHỨNG (CHƯƠNG X)

### [REF-05-011]
- **Tiêu đề / Mệnh chủ:** Đại Phú Mệnh Lý — Chân Dụng Thần Đắc Căn Tố Công (Trần Khang Ninh Bát Tự).
- **Tứ trụ Can Chi:** **Quý Mão - Ất Mão - Mậu Ngọ - Đinh Tỵ** (Nam mệnh).
- **Thể loại:** Tử Bình Hiện đại - Mệnh lý Thực chứng & Dụng thần Chân Thần.
- **Xuất xứ tài liệu:** *Dự Báo Theo Tử Bình* - Trần Khang Ninh. Chương: "Thủ Dụng Thần & Biện Biệt Chân Giả".
- **Đoạn trích đối chiếu:**
  > Nhật chủ Mậu thổ sinh vu Mão nguyệt mộc vượng chi thời, xuân mộc đương quyền, khắc thân thậm trọng. May đắc Ngọ hỏa nhật chi, Tỵ thời tàng hỏa hóa sát sinh thân, Đinh hỏa thấu xuất. Dụng Thần thủ Hỏa hóa Mộc, xuân hỏa đắc khí, chân thần phát dụng, trung vận đại phú trăm tỷ.
- **File đối chiếu nội bộ:** `dự-báo-theo-tử-bình-trần-khang-ninh-pdf-dantocking.com.PDF` (Trang 145–148).
- **Vị trí áp dụng:** Tập 05, Chương X, Mệnh tạo 1 (Nhóm Hiện đại).

---

### [REF-05-012]
- **Tiêu đề / Mệnh chủ:** Kỳ Tài Quan Lộ — Điều Hậu Khắc Thiệt Đắc Lộc (Thiệu Vĩ Hoa Khảo Chứng).
- **Tứ trụ Can Chi:** **Kỷ Sửu - Bính Tý - Canh Dần - Bính Tý** (Nam mệnh đại quý).
- **Thể loại:** Tử Bình Khí thế & Điều Hậu Cổ Kim.
- **Xuất xứ tài liệu:** *Dự Đoán Theo Tứ Trụ* - Thiệu Vĩ Hoa. Chương: "Điều Hậu Dụng Thần Thực Lệ".
- **Đoạn trích đối chiếu:**
  > Canh kim sinh trọng đông Tý nguyệt, địa chi Tý Sửu thiên hàn, kim thủy hàn lãnh chi cực. Tứ trụ nhị thấu Bính hỏa giải đống, Bính hỏa tuy tọa Tý địa nhưng đắc Dần mộc trường sinh trợ hỏa. Dụng Bính hỏa điều hậu vi tôn, trung niên hành phương nam hỏa vận thăng chức bộ trưởng.
- **File đối chiếu nội bộ:** `Dự Đoán Theo Tứ Trụ - Thiệu Vĩ Hoa.pdf` (Chương Dụng Thần Điều Hậu, Mệnh lệ 12).
- **Vị trí áp dụng:** Tập 05, Chương X, Mệnh tạo 2 (Nhóm Hiện đại).

---

### [REF-05-013]
- **Tiêu đề / Mệnh chủ:** Manh Phái Phá Cách — Khố Bế Bất Xung Phản Vi Hung (Đoàn Kiến Nghiệp Khảo Biện).
- **Tứ trụ Can Chi:** **Kỷ Mùi - Quý Dậu - Ất Mùi - Đinh Hợi** (Nữ mệnh bần khổ).
- **Thể loại:** Manh phái Tố công & Dụng thần hình hại khố bế.
- **Xuất xứ tài liệu:** *Lục Thân Cao Cấp Diện Thụ* - Đoàn Kiến Nghiệp. Tiết: "Luận Tài Khố Hữu Tác Dụng Vô Tác Dụng".
- **Đoạn trích đối chiếu:**
  > Ất Mộc nhật chủ sinh Dậu nguyệt, bát tự lưỡng tọa Mùi thổ mộc khố, hỷ Quý Hợi sinh trợ vi dụng. Nhi bát tự vô Sửu xung Mùi, tài khố bế tỏa, Hợi Mùi bán hợp mộc mộc vô nguyên thần, chung thân bần hàn cô quả.
- **File đối chiếu nội bộ:** `Lục thân cao cấp diện thụ.docx` (Tiết 3, Lệ 8).
- **Vị trí áp dụng:** Tập 05, Chương X, Mệnh tạo 3 (Nhóm Manh Phái).

---

### [REF-05-014]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Nhậm Thiết Tiều Bình Chú — Lưỡng Khí Tương Tranh Dụng Thông Quan Hóa Bạo.
- **Tứ trụ Can Chi:** **Mậu Thìn - Canh Thân - Giáp Dần - Canh Ngọ** (Nam mệnh kỳ tài võ quan).
- **Thể loại:** Kinh điển Trích Thiên Tủy Điệt Vi - Thông Quan Cách.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* (滴天髓闡微) - Nhậm Thiết Tiều khảo chú. Hạ quyển, Chương Thông Quan, Lệ 1.
- **Nguyên văn Hán tự:** 
  > 甲木生於申月，庚金並透，煞勢猖狂。地支辰申拱水，時落午火，兩氣相爭，木弱金強。妙在辰中癸水暗引金氣，運入北方水地，通關化煞，拔擢總兵。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微 通關](https://zh.wikisource.org/wiki/滴天髓闡微#通關)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf` (Quyển Hạ, Thông Quan).
- **Vị trí áp dụng:** Tập 05, Chương X, Mệnh tạo 4 (Nhóm Cổ điển).

---

### [REF-05-015]
- **Tiêu đề / Mệnh chủ:** Tòng Nhi Cách Chân Thần Xuất Hiện — Trạng Nguyên Mệnh Tạo Cổ Thư.
- **Tứ trụ Can Chi:** **Đinh Mão - Đinh Mùi - Giáp Ngọ - Bính Dần** (Nam mệnh quan cao nhất phẩm).
- **Thể loại:** Trích Thiên Tủy - Tòng Nhi Cách Chân Cách.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* (滴天髓闡微) - Nhậm Thiết Tiều khảo chú. Thượng quyển, Chương Tòng Nhi Cách.
- **Nguyên văn Hán tự:** 
  > 甲木生於季夏，地支寅午未全，四柱純火無水，木從火勢，順氣流通。從兒不管身強弱，只要吾兒又得兒。運走東南，官至极品，文章冠世。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微 從兒格](https://zh.wikisource.org/wiki/滴天髓闡微#從兒格)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf` (Quyển Thượng, Tòng Nhi Cách).
- **Vị trí áp dụng:** Tập 05, Chương X, Mệnh tạo 5 (Nhóm Cổ điển).

---

### [REF-05-016]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Nhậm Thiết Tiều — Sát Ấn Tương Sinh Khí Quán Càn Khôn.
- **Tứ trụ Can Chi:** **Canh Dần - Nhâm Ngọ - Mậu Dần - Ất Mão** (Nam mệnh tuần phủ đại nhân).
- **Thể loại:** Trích Thiên Tủy Điệt Vi - Khí tượng thiên.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* (滴天髓闡微) - Nhậm Thiết Tiều khảo chú. Hạ quyển, Chương Quan Sát.
- **Nguyên văn Hán tự:** 
  > 戊土生於仲夏，支全寅午，官煞並透，氣勢雄壯。妙在年透庚金，時透乙木，有化象之情。日坐長生，印綬當權，煞印相生，仕至巡撫。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微 官煞](https://zh.wikisource.org/wiki/滴天髓闡微#官煞)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`.
- **Vị trí áp dụng:** Tập 05, Chương X, Mệnh tạo 6.

---

### [REF-05-017]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Nhậm Thiết Tiều — Thông Quan Hóa Sát Phùng Hung Hóa Cát.
- **Tứ trụ Can Chi:** **Quý Dậu - Giáp Tý - Bính Thìn - Mậu Tý** (Nam mệnh quý hiển tài bá).
- **Thể loại:** Trích Thiên Tủy Điệt Vi - Thông Quan thiên.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* (滴天髓闡微) - Nhậm Thiết Tiều khảo chú. Thượng quyển, Chương Trụ Thần.
- **Nguyên văn Hán tự:** 
  > 丙火生於仲冬，地支兩子一辰一酉，金水乘旺，煞勢極強。妙在月透甲木，通關化水生火，水不剋火而反生木，木生丙火，轉危為安，由諸生入翰苑。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微 通關](https://zh.wikisource.org/wiki/滴天髓闡微#通關)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`.
- **Vị trí áp dụng:** Tập 05, Chương X, Mệnh tạo 7.

---

### [REF-05-018]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Nhậm Thiết Tiều — Kim Mộc Giao Chiến Tứ Trụ Xung Bạo.
- **Tứ trụ Can Chi:** **Bính Thân - Tân Mão - Đinh Dậu - Quý Mão** (Nam mệnh hình thương tàn phế).
- **Thể loại:** Trích Thiên Tủy Điệt Vi - Hình Xung thiên.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* (滴天髓闡微) - Nhậm Thiết Tiều khảo chú. Hạ quyển, Chương Địa chi tương xung.
- **Nguyên văn Hán tự:** 
  > 地支兩卯兩酉，天干丙辛丁癸，金木交戰，克削無情。卯酉逢衝，門戶受損，無水通關，中年殘疾，家破人亡。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微 地支](https://zh.wikisource.org/wiki/滴天髓闡微#地支)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`.
- **Vị trí áp dụng:** Tập 05, Chương X, Mệnh tạo 8.

---

### [REF-05-019]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Nhậm Thiết Tiều — Thủy Hỏa Giao Tranh Dụng Mộc Thông Quan.
- **Tứ trụ Can Chi:** **Nhâm Thân - Nhâm Tý - Bính Ngọ - Giáp Ngọ** (Nam mệnh thi đậu khoa bảng).
- **Thể loại:** Trích Thiên Tủy Điệt Vi - Thủy Hỏa ký tế.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* (滴天髓闡微) - Nhậm Thiết Tiều khảo chú. Thượng quyển, Chương Hàn noãn.
- **Nguyên văn Hán tự:** 
  > 丙午日主，生於子月，壬水雙透，煞勢猖狂。時落甲午，喜得甲木通關，洩水之氣以生丙火。逢木火運，聯登甲第。
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓闡微 寒暖](https://zh.wikisource.org/wiki/滴天髓闡微#寒暖)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`.
- **Vị trí áp dụng:** Tập 05, Chương X, Mệnh tạo 9.

---

### [REF-05-020]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Trầm Hiếu Thắng — Kiến Lộc Cách Dụng Quan Thành Quý.
- **Tứ trụ Can Chi:** **Quý Sửu - Giáp Dần - Mậu Tuất - Bính Thìn** (Nam mệnh Thượng thư).
- **Thể loại:** Tử Bình Chân Thuyên - Kiến Lộc Cách.
- **Xuất xứ cổ tịch:** *Tử Bình Chân Thuyên* (子平真詮) - Trầm Hiếu Thắng nguyên trứ. Chương: Luận Dương Nhận Kiến Lộc thủ dụng.
- **Nguyên văn Hán tự:** 
  > 戊生寅月，時透丙火，身旺印強。透癸為財，透甲為煞，以印化煞生身，財生官煞，格成大貴，官至尚書。
- **Link kiểm chứng công khai:** [Wikisource - 子平真詮](https://zh.wikisource.org/wiki/子平真詮)
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf`.
- **Vị trí áp dụng:** Tập 05, Chương X, Mệnh tạo 10.

---

### [REF-05-021]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Trầm Hiếu Thắng — Sát Cách Phùng Thực Chế Vi Quyền.
- **Tứ trụ Can Chi:** **Đinh Hợi - Canh Tuất - Giáp Tý - Ất Hợi** (Nam mệnh Quan Thống đốc).
- **Thể loại:** Tử Bình Chân Thuyên - Thiên Quan (Thất Sát) cách.
- **Xuất xứ cổ tịch:** *Tử Bình Chân Thuyên* (子平真詮) - Chương: Luận Thất Sát.
- **Nguyên văn Hán tự:** 
  > 甲生戌月，庚金煞透，年透丁火傷官制煞，身坐子水印綬生身。制伏得宜，印刃相扶，貴為督撫。
- **Link kiểm chứng công khai:** [Wikisource - 子平真詮](https://zh.wikisource.org/wiki/子平真詮)
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf`.
- **Vị trí áp dụng:** Tập 05, Chương X, Mệnh tạo 11.

---

### [REF-05-022]
- **Tiêu đề / Mệnh chủ:** Manh Phái Đoàn Kiến Nghiệp — Tài Đa Thân Nhược Khống Chế Cục.
- **Tứ trụ Can Chi:** **Mậu Tý - Giáp Dần - Canh Dần - Tân Tỵ** (Nam mệnh thương nhân xuất ngoại).
- **Thể loại:** Manh Phái Cao cấp - Tố công tài vận.
- **Xuất xứ tài liệu:** *Lục Thân Cao Cấp Diện Thụ* - Đoàn Kiến Nghiệp. Tiết: Biện tài quan thực chiến.
- **Đoạn trích đối chiếu:**
  > Canh kim tọa Dần tuyệt địa, nguyệt lệnh Dần mộc thấu Giáp mộc thiên tài, tài đa thân nhược. Hỷ đắc thời quy Tân Tỵ, Tỵ hỏa trường sinh kim, Tý Thủy sinh Dần mộc, hành thổ kim vận phát tài trăm vạn.
- **File đối chiếu nội bộ:** `Lục thân cao cấp diện thụ.docx`.
- **Vị trí áp dụng:** Tập 05, Chương X, Mệnh tạo 12.

---

### [REF-05-023]
- **Tiêu đề / Mệnh chủ:** Manh Phái Đoàn Kiến Nghiệp — Quan Khố Phùng Xung Đại Quý Cục.
- **Tứ trụ Can Chi:** **Bính Tuất - Kỷ Hợi - Đinh Sửu - Tân Hợi** (Nam mệnh đại quý chính khách).
- **Thể loại:** Manh Phái - Khố khai tố công.
- **Xuất xứ tài liệu:** *Bát Tự Trân Bảo Giảng Nghĩa* - Đoàn Kiến Nghiệp. Tiết: Khai khố thành quý.
- **Đoạn trích đối chiếu:**
  > Đinh hỏa sinh Hợi nguyệt, tọa Sửu thổ kim thủy khố, niên chi Tuất thổ hỏa khố tương hình xung. Sửu Tuất tương hình khai khố, chế thủy đắc quyền, quý hiển vô song.
- **File đối chiếu nội bộ:** `Bát tự trân bảo giảng nghĩa.docx`.
- **Vị trí áp dụng:** Tập 05, Chương X, Mệnh tạo 13.

---

### [REF-05-024]
- **Tiêu đề / Mệnh chủ:** Manh Phái Đoàn Kiến Nghiệp — Lộc Nhận Bị Phá Phản Hung Cực.
- **Tứ trụ Can Chi:** **Canh Thìn - Kỷ Mão - Giáp Tý - Đinh Mão** (Nam mệnh phá gia bại sản).
- **Thể loại:** Manh Phái - Lộc nhận thương tổn.
- **Xuất xứ tài liệu:** *Lục Thân Cao Cấp Diện Thụ* - Đoàn Kiến Nghiệp. Tiết: Hung họa phá tài.
- **Đoạn trích đối chiếu:**
  > Giáp Mộc sinh Mão nguyệt Dương Nhận trùng trùng, đắc Tý thủy tương hình, Thìn thổ tàng mộc. Canh kim vô lực hư phù, Đinh hỏa thương quan khắc Canh, vận hành bế tắc phá sản trắng tay.
- **File đối chiếu nội bộ:** `Lục thân cao cấp diện thụ.docx`.
- **Vị trí áp dụng:** Tập 05, Chương X, Mệnh tạo 14.

---

### [REF-05-025]
- **Tiêu đề / Mệnh chủ:** Manh Phái Đoàn Kiến Nghiệp — Thực Thần Hóa Sát Tố Công Đỉnh Cao.
- **Tứ trụ Can Chi:** **Quý Tỵ - Giáp Dần - Bính Thìn - Mậu Tuất** (Nam mệnh cự phú công nghiệp).
- **Thể loại:** Manh Phái - Thực thương sinh tài chế sát.
- **Xuất xứ tài liệu:** *Bát Tự Trân Bảo Giảng Nghĩa* - Đoàn Kiến Nghiệp. Tiết: Tố công cự phú.
- **Đoạn trích đối chiếu:**
  > Bính hỏa sinh Dần nguyệt mộc hỏa thông minh, thời tọa Mậu Tuất thực thần khô ráo xung Thìn thấp thổ. Thìn Tuất tương xung chế sát khố, phát tài hàng chục triệu đô la.
- **File đối chiếu nội bộ:** `Bát tự trân bảo giảng nghĩa.docx` & `MỆNH LÝ TRÂN BẢO GIẢNG NGHĨA.pdf`.
- **Vị trí áp dụng:** Tập 05, Chương X, Mệnh tạo 15.

---

### [REF-05-026]
- **Tiêu đề / Mệnh chủ:** Hiện Đại Thiệu Vĩ Hoa — Thân Vượng Dụng Tài Quan Thành Đạt.
- **Tứ trụ Can Chi:** **Tân Tỵ - Mậu Tuất - Ất Mão - Bính Tý** (Nam mệnh cục trưởng tài chính).
- **Thể loại:** Dự Đoán Theo Tứ Trụ - Phù ức thực tiễn.
- **Xuất xứ tài liệu:** *Dự Đoán Theo Tứ Trụ* - Thiệu Vĩ Hoa. Chương: Tuyển thủ dụng thần thực nghiệm.
- **Đoạn trích đối chiếu:**
  > Ất mộc tọa Mão đắc Lộc, thời thấu Bính hỏa tiết tú, tài tinh Mậu Tuất đương quyền đắc lộc ở Tỵ. Dụng Tân Kim thất sát chế mộc hộ tài, Bính Tân ám hợp, thăng tiến cục trưởng tài chính.
- **File đối chiếu nội bộ:** `Dự Đoán Theo Tứ Trụ - Thiệu Vĩ Hoa.pdf` (Trang 178).
- **Vị trí áp dụng:** Tập 05, Chương X, Mệnh tạo 16.

---

### [REF-05-027]
- **Tiêu đề / Mệnh chủ:** Hiện Đại Thiệu Vĩ Hoa — Kim Vượng Phùng Hỏa Đại Phú Thương Gia.
- **Tứ trụ Can Chi:** **Nhâm Thìn - Kỷ Dậu - Canh Ngọ - Tân Tỵ** (Nam mệnh đại gia xuất nhập khẩu).
- **Thể loại:** Dự Đoán Theo Tứ Trụ - Hỏa luyện kim thanh.
- **Xuất xứ tài liệu:** *Dự Đoán Theo Tứ Trụ* - Thiệu Vĩ Hoa. Chương: Quan sát chế thân vi dụng.
- **Đoạn trích đối chiếu:**
  > Canh kim sinh Dậu nguyệt Dương Nhận đắc lệnh, trụ nhiều tỷ kiếp kim vượng vô cùng. Dụng nhật chi Ngọ hỏa, thời chi Tỵ hỏa tôi luyện kiếm khí, trung vận đại phú trăm tỷ kinh doanh vận tải.
- **File đối chiếu nội bộ:** `Dự Đoán Theo Tứ Trụ - Thiệu Vĩ Hoa.pdf` (Trang 192).
- **Vị trí áp dụng:** Tập 05, Chương X, Mệnh tạo 17.

---

### [REF-05-028]
- **Tiêu đề / Mệnh chủ:** Hiện Đại Trần Khang Ninh — Mộc Hỏa Thông Minh Khởi Nghiệp Bất Động Sản.
- **Tứ trụ Can Chi:** **Bính Ngọ - Mậu Tuất - Ất Mão - Đinh Hợi** (Nam mệnh đại gia địa ốc).
- **Thể loại:** Dự Báo Theo Tử Bình - Thương quan sinh tài cách.
- **Xuất xứ tài liệu:** *Dự Báo Theo Tử Bình* - Trần Khang Ninh. Chương: Bát tự phú cục phân tích.
- **Đoạn trích đối chiếu:**
  > Ất mộc sinh Tuất nguyệt đắc Hợi Mão bán hợp mộc cục thân cường, thấu Bính Đinh hỏa tú khí thông minh. Dụng hỏa xả khí sinh Mậu thổ tài tinh, trung niên tay trắng lập nên tập đoàn địa ốc.
- **File đối chiếu nội bộ:** `dự-báo-theo-tử-bình-trần-khang-ninh-pdf-dantocking.com.PDF` (Trang 210).
- **Vị trí áp dụng:** Tập 05, Chương X, Mệnh tạo 18.

---

### [REF-05-029]
- **Tiêu đề / Mệnh chủ:** Hiện Đại Trần Khang Ninh — Thất Sát Quá Vượng Dụng Ấn Hóa Sát Vi Quyền.
- **Tứ trụ Can Chi:** **Giáp Dần - Bính Dần - Canh Thân - Kỷ Mão** (Nam mệnh tổng giám đốc ngân hàng).
- **Thể loại:** Dự Báo Theo Tử Bình - Sát cường đắc ấn.
- **Xuất xứ tài liệu:** *Dự Báo Theo Tử Bình* - Trần Khang Ninh. Chương: Sát ấn tương sinh thực lệ.
- **Đoạn trích đối chiếu:**
  > Canh kim sinh Dần nguyệt tuyệt địa, tam chi Dần Mão mộc vượng sinh Bính hỏa thất sát. May đắc Thân kim nhật chi xung Dần, Kỷ thổ thời can thấu lộ hóa Sát sinh Thân, làm tổng giám đốc ngân hàng lớn.
- **File đối chiếu nội bộ:** `dự-báo-theo-tử-bình-trần-khang-ninh-pdf-dantocking.com.PDF` (Trang 234).
- **Vị trí áp dụng:** Tập 05, Chương X, Mệnh tạo 19.

---

### [REF-05-030]
- **Tiêu đề / Mệnh chủ:** Hiện Đại Trần Khang Ninh — Tòng Nhi Biến Cách Khí Vận Hanh Thông.
- **Tứ trụ Can Chi:** **Quý Hợi - Giáp Dần - Đinh Mùi - Canh Tuất** (Nam mệnh chuyên gia công nghệ cao).
- **Thể loại:** Dự Báo Theo Tử Bình - Tòng nhi biến hóa.
- **Xuất xứ tài liệu:** *Dự Báo Theo Tử Bình* - Trần Khang Ninh. Chương: Tòng cách thực chứng.
- **Đoạn trích đối chiếu:**
  > Đinh hỏa sinh Dần nguyệt, chi hội Dần Mùi Tuất mộc hỏa chi thế, Quý thủy quan tinh bị Giáp mộc hóa sạch, Canh kim tài tinh thấu lộ. Tòng nhi sinh tài, thành tựu danh tiếng lớn trong ngành công nghệ cao.
- **File đối chiếu nội bộ:** `dự-báo-theo-tử-bình-trần-khang-ninh-pdf-dantocking.com.PDF` (Trang 256).
- **Vị trí áp dụng:** Tập 05, Chương X, Mệnh tạo 20.

---

# TẬP 05 - BỔ SUNG & TẬP 06: CÙNG THÔNG BẢO GIÁM — ĐIỀU HẬU KHÍ TƯỢNG HỌC & ĐẠI TOÀN THƯ 120 MẪU HÌNH SINH MỆNH

## 1. NGUYÊN LÝ LÝ THUYẾT & KHẨU QUYẾT CỐT LÕI (CÙNG THÔNG BẢO GIÁM)

### [REF-06-001]
- **Nội dung / Khái niệm:** Nguyên lý Tứ Thời Khí Tượng Học & Hai Trục Hàn Noãn Táo Thấp chi phối vạn vật sinh trưởng.
- **Thể loại:** Cổ điển Khí Tượng Tử Bình.
- **Xuất xứ cổ tịch:** *Cùng Thông Bảo Giám* (窮通寶鑑) - Dư Xuân Đài biên tập, Từ Nhạc Ngô bình chú. Thiên: "Tổng Luận Tứ Thời Ngũ Hành Cương Lĩnh" (總論四時五行).
- **Nguyên văn Hán tự:** 
  > 夫五行之體，各有所宜。四時之氣，各有所司。天道有寒暖，地道有燥濕。寒極者熱之必發，暖甚者寒之必和。若夫調候之義，以丙火解凍，癸水潤旱，二者周流，萬物化育。
- **Link kiểm chứng công khai:** [Chinese Text Project - 窮通寶鑑 總論](https://ctext.org/wiki.pl?if=gb&chapter=958742) & [Wikisource - 窮通寶鑑](https://zh.wikisource.org/wiki/窮通寶鑑)
- **File đối chiếu nội bộ:** `Mệnh Ly huyền cơ tham bí.pdf` & `Mệnh lý tinh hoa.pdf`.
- **Vị trí áp dụng:** Tập 06, Chương I: "Bản Thể Luận Khí Tượng Học Sinh Thái".

---

### [REF-06-002]
- **Nội dung / Khái niệm:** Khí tượng Giáp Ất Mộc mùa xuân — Bính tiên Quý hậu, sơ xuân hàn khí vị trừ.
- **Thể loại:** Cùng Thông Bảo Giám - Luận Mộc.
- **Xuất xứ cổ tịch:** *Cùng Thông Bảo Giám* (窮通寶鑑) - Quyển 1: "Tam Xuân Giáp Mộc Tổng Luận" (三春甲木).
- **Nguyên văn Hán tự:** 
  > 初春甲木，餘寒猶存，非丙不發。雖得雨露之潤，而無陽光之煦，則根腐而芽敗。故初春甲木，以丙為先，癸水次之。丙癸兩透，富貴非輕。
- **Link kiểm chứng công khai:** [Wikisource - 窮通寶鑑 卷一 三春甲木](https://zh.wikisource.org/wiki/窮通寶鑑#三春甲木)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf` (Chương Hàn Noãn).
- **Vị trí áp dụng:** Tập 06, Chương II, Mục 1: "Giáp Mộc Qua Tứ Thời 12 Tiết Khí".

---

### [REF-06-003]
- **Nội dung / Khái niệm:** Khí tượng Giáp Ất Mộc mùa hè — Hỏa liệt Mộc khô, Quý thủy vi tôn, Canh Kim sinh nguyên.
- **Thể loại:** Cùng Thông Bảo Giám - Luận Mộc.
- **Xuất xứ cổ tịch:** *Cùng Thông Bảo Giám* (窮通寶鑑) - Quyển 1: "Tam Hạ Giáp Mộc Tổng Luận" (三夏甲木).
- **Nguyên văn Hán tự:** 
  > 四五六月甲木，木氣焦枯，專用癸水以潤其根，又喜庚金發水源。蓋無金則水無源，無水則木枯槁。癸透庚藏，富貴雙全。
- **Link kiểm chứng công khai:** [Wikisource - 窮通寶鑑 卷一 三夏甲木](https://zh.wikisource.org/wiki/窮通寶鑑#三夏甲木)
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf`.
- **Vị trí áp dụng:** Tập 06, Chương II, Mục 2: "Ất Mộc & Giáp Mộc Mùa Hạ".

---

### [REF-06-004]
- **Nội dung / Khái niệm:** Khí tượng Bính Đinh Hỏa mùa đông — Khí hàn thể tuyệt, Giáp Mộc sinh thân, Canh Kim tích Giáp dẫn Đinh.
- **Thể loại:** Cùng Thông Bảo Giám - Luận Hỏa.
- **Xuất xứ cổ tịch:** *Cùng Thông Bảo Giám* (窮通寶鑑) - Quyển 2: "Tam Đông Bính Đinh Hỏa Tổng Luận" (三冬丙丁火).
- **Nguyên văn Hán tự:** 
  > 冬月丙火，氣息奄奄，非甲不生。丁火衰竭，借甲引丁，藉庚劈甲。冬火見甲，枯木逢春；得庚劈之，光焰萬丈。
- **Link kiểm chứng công khai:** [Wikisource - 窮通寶鑑 卷二 三冬丙火](https://zh.wikisource.org/wiki/窮通寶鑑#三冬丙火)
- **File đối chiếu nội bộ:** `Mệnh Ly huyền cơ tham bí.pdf` (Tiết Tích Giáp dẫn Đinh).
- **Vị trí áp dụng:** Tập 06, Chương III: "Điều Hậu Toàn Tập Nhóm Hỏa".

---

### [REF-06-005]
- **Nội dung / Khái niệm:** Khí tượng Bính Hỏa mùa hè — Dương cực chi hỏa, Nhâm Thủy thao tẩy chế viêm, tạo thành Thủy Hỏa ký tế.
- **Thể loại:** Cùng Thông Bảo Giám - Luận Hỏa.
- **Xuất xứ cổ tịch:** *Cùng Thông Bảo Giám* (窮通寶鑑) - Quyển 2: "Tam Hạ Bính Hỏa Tổng Luận" (三夏丙火).
- **Nguyên văn Hán tự:** 
  > 五月丙火，陽極之時，專用壬水，金為佐助。壬透金生，威震邊陲；若無壬水，日輪當空，大地焦炎，殘疾夭折。
- **Link kiểm chứng công khai:** [Wikisource - 窮通寶鑑 卷二 三夏丙火](https://zh.wikisource.org/wiki/窮通寶鑑#三夏丙火)
- **File đối chiếu nội bộ:** `Dự Đoán Theo Tứ Trụ - Thiệu Vĩ Hoa.pdf` (Chương Điều Hậu).
- **Vị trí áp dụng:** Tập 06, Chương III, Mục 1: "Bính Hỏa Chín Tầng Trời".

---

### [REF-06-006]
- **Nội dung / Khái niệm:** Khí tượng Mậu Kỷ Thổ Tứ Quý Nguyệt — Táo thấp tương tể, Thìn Sửu thấp thổ hối hỏa, Tuất Mùi táo thổ sát kim.
- **Thể loại:** Cùng Thông Bảo Giám - Luận Thổ.
- **Xuất xứ cổ tịch:** *Cùng Thông Bảo Giám* (窮通寶鑑) - Quyển 3: "Tứ Quý Thổ Tổng Luận" (四季土).
- **Nguyên văn Hán tự:** 
  > 辰戌丑未，四正之氣，各有不同。丑辰為濕土，含水能潤金；戌未為燥土，藏火能爍金。春夏宜水以潤燥，秋冬喜火以融寒。
- **Link kiểm chứng công khai:** [Wikisource - 窮通寶鑑 卷三 四季土](https://zh.wikisource.org/wiki/窮通寶鑑#四季土)
- **File đối chiếu nội bộ:** `Bát tự trân bảo giảng nghĩa.docx` & `Mệnh lý trân bảo giảng nghĩa.pdf`.
- **Vị trí áp dụng:** Tập 06, Chương IV: "Điều Hậu Toàn Tập Nhóm Thổ".

---

### [REF-06-007]
- **Nội dung / Khái niệm:** Khí tượng Canh Kim mùa thu đông — Kim hàn thủy lãnh, chuyên dụng Đinh Hỏa luyện Canh, Giáp Mộc dẫn hỏa.
- **Thể loại:** Cùng Thông Bảo Giám - Luận Kim.
- **Xuất xứ cổ tịch:** *Cùng Thông Bảo Giám* (窮通寶鑑) - Quyển 4: "Tam Thu Canh Kim & Tam Đông Canh Kim" (秋冬庚金).
- **Nguyên văn Hán tự:** 
  > 秋月庚金，剛健之極，非丁不熔，非甲不引。冬月庚金，金寒水冷，天道嚴寒，無火鍛鍊，終成頑鐵。專用丁甲，佐以丙暖。
- **Link kiểm chứng công khai:** [Wikisource - 窮通寶鑑 卷四 三秋庚金](https://zh.wikisource.org/wiki/窮通寶鑑#三秋庚金)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`.
- **Vị trí áp dụng:** Tập 06, Chương V: "Điều Hậu Toàn Tập Nhóm Kim".

---

### [REF-06-008]
- **Nội dung / Khái niệm:** Khí tượng Tân Kim nhuận trạch — Ôn nhuận châu ngọc, hỷ Nhâm Thủy đào tẩy chiếu ảnh, kỵ Kỷ Thổ mai kim nê trệ.
- **Thể loại:** Cùng Thông Bảo Giám - Luận Kim.
- **Xuất xứ cổ tịch:** *Cùng Thông Bảo Giám* (窮通寶鑑) - Quyển 4: "Thập Nhị Nguyệt Tân Kim Tổng Luận" (辛金總論).
- **Nguyên văn Hán tự:** 
  > 辛金清潤，體質柔弱，溫潤而清。專愛壬水淘洗，以發其光。最忌土多埋沒，晦其光芒。冬月辛金，冰雪掩蓋，先用丙暖，次用壬淘。
- **Link kiểm chứng công khai:** [Wikisource - 窮通寶鑑 卷四 辛金](https://zh.wikisource.org/wiki/窮通寶鑑#辛金)
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf`.
- **Vị trí áp dụng:** Tập 06, Chương V, Mục 2: "Tân Kim Châu Ngọc".

---

### [REF-06-009]
- **Nội dung / Khái niệm:** Khí tượng Nhâm Quý Thủy mùa đông — Sóng biển cuộn trào băng giá, dụng Mậu Thổ chế xung bạo, dụng Bính Hỏa giải hàn khí.
- **Thể loại:** Cùng Thông Bảo Giám - Luận Thủy.
- **Xuất xứ cổ tịch:** *Cùng Thông Bảo Giám* (窮通寶鑑) - Quyển 5: "Tam Đông Nhâm Quý Thủy Tổng Luận" (三冬壬水癸水).
- **Nguyên văn Hán tự:** 
  > 十一月壬水，陽生於子，汪洋肆泛，專用戊土以障狂瀾。又值嚴冬，非丙溫暖，則冰結土凍，戊土無生發之氣。丙戊兩透，名利雙收。
- **Link kiểm chứng công khai:** [Wikisource - 窮通寶鑑 卷五 三冬壬水](https://zh.wikisource.org/wiki/窮通寶鑑#三冬壬水)
- **File đối chiếu nội bộ:** `Mệnh Ly huyền cơ tham bí.pdf`.
- **Vị trí áp dụng:** Tập 06, Chương VI: "Điều Hậu Toàn Tập Nhóm Thủy".

---

### [REF-06-010]
- **Nội dung / Khái niệm:** Phối Ngũ Thần Tướng Tổng Cương — Trục đối xứng cứu sinh của muôn loài trong Cùng Thông Bảo Giám.
- **Thể loại:** Tổng kết Cổ điển Thần Tướng.
- **Xuất xứ cổ tịch:** *Cùng Thông Bảo Giám* (窮通寶鑑) - Dư Xuân Đài toát yếu, Từ Nhạc Ngô tổng định.
- **Nguyên văn Hán tự:** 
  > 大抵五行生剋，不離寒暖燥濕四者。金水冬生，無丙則不暖；木火夏生，無癸則不活。戊己四季，燥濕相需；甲乙春秋，生成隨令。知神將之相資，則萬變不離其宗矣。
- **Link kiểm chứng công khai:** [Chinese Text Project - 窮通寶鑑 總結](https://ctext.org/wiki.pl?if=gb&chapter=958742)
- **File đối chiếu nội bộ:** `Mệnh lý tinh hoa.pdf` & `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`.
- **Vị trí áp dụng:** Tập 06, Chương VIII: "Nguyên Lý Phối Ngũ Thần Tướng".

---

## 2. KHO KỲ ÁN ĐỐI CHỨNG LÂM SÀNG CÙNG THÔNG BẢO GIÁM (CHƯƠNG IX)

### [REF-06-011]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Từ Nhạc Ngô — Giáp Mộc Mùa Đông Đắc Bính Giải Đống Đại Quý (Lá số Bàng Bách Lực).
- **Tứ trụ Can Chi:** **Kỷ Hợi - Bính Tý - Giáp Dần - Đinh Mão** (Nam mệnh tuần phủ đại nhân).
- **Thể loại:** Cùng Thông Bảo Giám Bình Chú - Giáp mộc đông sinh hỷ hỏa.
- **Xuất xứ cổ tịch:** *Cùng Thông Bảo Giám Bình Chú* (窮通寶鑑評註) - Từ Nhạc Ngô. Quyển 1: "Thập nhất nguyệt Giáp Mộc mệnh lệ".
- **Nguyên văn Hán tự:** 
  > 甲寅日主，生於子月，天寒地凍。妙在干透丙丁，支通寅卯，木火通明，驅除嚴寒。早年行南方火運，拔擢巡撫，名震一時。
- **Link kiểm chứng công khai:** [Wikisource - 窮通寶鑑 十一月甲木](https://zh.wikisource.org/wiki/窮通寶鑑#十一月甲木)
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf` (Phần Phụ khảo Cùng Thông).
- **Vị trí áp dụng:** Tập 06, Chương IX, Mệnh tạo 1.

---

### [REF-06-012]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Từ Nhạc Ngô — Bính Hỏa Mùa Hè Đắc Nhâm Thủy Thao Tẩy (Lá số Chu Các Lão).
- **Tứ trụ Can Chi:** **Kỷ Tỵ - Canh Ngọ - Bính Tý - Giáp Ngọ** (Nam mệnh Nội các Đại học sĩ).
- **Thể loại:** Cùng Thông Bảo Giám Bình Chú - Bính hỏa trọng hạ đắc thủy chế.
- **Xuất xứ cổ tịch:** *Cùng Thông Bảo Giám Bình Chú* (窮通寶鑑評註) - Quyển 2: "Ngũ nguyệt Bính Hỏa thực lệ".
- **Nguyên văn Hán tự:** 
  > 丙生午月，支聚兩午一巳，炎炎之極。喜得日支坐子，水火相濟，時透甲木引化。運入西北金水之地，身入內閣，位冠百寮。
- **Link kiểm chứng công khai:** [Wikisource - 窮通寶鑑 五月丙火](https://zh.wikisource.org/wiki/窮通寶鑑#五月丙火)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`.
- **Vị trí áp dụng:** Tập 06, Chương IX, Mệnh tạo 2.

---

### [REF-06-013]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Từ Nhạc Ngô — Mậu Thổ Sinh Tháng Mùi Khô Cháy Đắc Thủy Nhuận (Lá số Lý Thượng Thư).
- **Tứ trụ Can Chi:** **Mậu Thìn - Kỷ Mùi - Mậu Ngọ - Quý Hợi** (Nam mệnh Thượng thư).
- **Thể loại:** Cùng Thông Bảo Giám Bình Chú - Lục nguyệt Mậu thổ đắc thủy nhuận.
- **Xuất xứ cổ tịch:** *Cùng Thông Bảo Giám Bình Chú* (窮通寶鑑評註) - Quyển 3: "Lục nguyệt Mậu Thổ thực lệ".
- **Nguyên văn Hán tự:** 
  > 戊土生於未月，火炎土焦。妙在時落癸亥，水氣通源，年支坐辰，濕土潤燥。火土得水而滋潤，萬物生榮，位至尚書。
- **Link kiểm chứng công khai:** [Wikisource - 窮通寶鑑 六月戊土](https://zh.wikisource.org/wiki/窮通寶鑑#六月戊土)
- **File đối chiếu nội bộ:** `Mệnh Ly huyền cơ tham bí.pdf`.
- **Vị trí áp dụng:** Tập 06, Chương IX, Mệnh tạo 3.

---

### [REF-06-014]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Từ Nhạc Ngô — Tân Kim Sinh Tháng Tý Băng Tuyết Đắc Bính (Lá số Diêm Tích Sơn).
- **Tứ trụ Can Chi:** **Quý Mùi - Tân Dậu - Tân Dậu - Bính Thân** (Nam mệnh Đô đốc Sơn Tây thời Dân quốc).
- **Thể loại:** Cùng Thông Bảo Giám Bình Chú - Tân kim thu đông đắc Bính chiếu rọi.
- **Xuất xứ cổ tịch:** *Cùng Thông Bảo Giám Bình Chú* (窮通寶鑑評註) - Từ Nhạc Ngô khảo chứng cận đại.
- **Nguyên văn Hán tự:** 
  > 辛生酉月，支全申酉，金氣純旺。妙在時透丙火，年坐未土暖木，金得火煉，更得水淘，威權赫奕，督軍山西數十年。
- **Link kiểm chứng công khai:** [Wikisource - 窮通寶鑑 八月辛金](https://zh.wikisource.org/wiki/窮通寶鑑#八月辛金)
- **File đối chiếu nội bộ:** `Dự Báo Theo Tử Bình - Trần Khang Ninh.pdf` (Chương Khảo sát danh nhân).
- **Vị trí áp dụng:** Tập 06, Chương IX, Mệnh tạo 4.

---

### [REF-06-015]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Từ Nhạc Ngô — Nhâm Thủy Trọng Đông Đắc Bính Mậu Lưỡng Thấu (Lá số Tằng Quốc Phiên).
- **Tứ trụ Can Chi:** **Tân Mùi - Kỷ Hợi - Bính Thìn - Kỷ Hợi** (Nam mệnh Tương quân Thống soái triều Thanh).
- **Thể loại:** Cùng Thông Bảo Giám Bình Chú - Khí tượng Hợi nguyệt vĩ nhân.
- **Xuất xứ cổ tịch:** *Cùng Thông Bảo Giám Bình Chú* - Từ Nhạc Ngô. Thập nguyệt can chi khảo chú.
- **Nguyên văn Hán tự:** 
  > 丙日生於亥月，天寒地凍。日坐辰土，干透兩己，妙在年支透未，通根有氣。運行南方火土之鄉，匡扶清室，立功名於天下。
- **Link kiểm chứng công khai:** [Wikisource - 窮通寶鑑 十月丙火](https://zh.wikisource.org/wiki/窮通寶鑑#十月丙火)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`.
- **Vị trí áp dụng:** Tập 06, Chương IX, Mệnh tạo 5.

---

### [REF-06-016]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Từ Nhạc Ngô — Canh Kim Sinh Tháng Thân Dụng Đinh Phối Giáp (Lá số Viên Thế Khải).
- **Tứ trụ Can Chi:** **Kỷ Mùi - Quý Dậu - Đinh Tỵ - Đinh Mùi** (Nam mệnh Đại Tổng thống Dân Quốc).
- **Thể loại:** Cùng Thông Bảo Giám Bình Chú - Đinh hỏa vượng khí thiên can.
- **Xuất xứ cổ tịch:** *Cùng Thông Bảo Giám Bình Chú* - Khảo định Dân quốc thực lệ.
- **Nguyên văn Hán tự:** 
  > 丁火生於酉月，地支巳未拱火，天干兩透丁火，氣勢歸火。喜得癸水制火，運入北方水地，权倾一时，登大总统之位。
- **Link kiểm chứng công khai:** [Wikisource - 窮通寶鑑 八月丁火](https://zh.wikisource.org/wiki/窮通寶鑑#八月丁火)
- **File đối chiếu nội bộ:** `Dự đoán theo tứ trụ.docx`.
- **Vị trí áp dụng:** Tập 06, Chương IX, Mệnh tạo 6.

---

### [REF-06-017]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Từ Nhạc Ngô — Quý Thủy Mùa Hè Thiếu Kim Sinh Nguồn Yểu Triết (Lá số Khô Hàn Bần Yểu).
- **Tứ trụ Can Chi:** **Bính Ngọ - Giáp Ngọ - Quý Mão - Đinh Tỵ** (Nam mệnh yểu triết bần hàn).
- **Thể loại:** Cùng Thông Bảo Giám Bình Chú - Quý thủy hạ sinh vô kim bần tiện.
- **Xuất xứ cổ tịch:** *Cùng Thông Bảo Giám* (窮通寶鑑) - Quyển 5: "Ngũ nguyệt Quý Thủy thực lệ".
- **Nguyên văn Hán tự:** 
  > 癸水生於五月，火土炎炎，四柱無金生水，癸水如朝露之易晞。運入東南木火之鄉，二十歲吐血而亡。
- **Link kiểm chứng công khai:** [Wikisource - 窮通寶鑑 五月癸水](https://zh.wikisource.org/wiki/窮通寶鑑#五月癸水)
- **File đối chiếu nội bộ:** `Mệnh Ly huyền cơ tham bí.pdf`.
- **Vị trí áp dụng:** Tập 06, Chương IX, Mệnh tạo 7.

---

### [REF-06-018]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Từ Nhạc Ngô — Ất Mộc Sinh Tháng Tý Thiếu Hỏa Rễ Thối Bần Bạc.
- **Tứ trụ Can Chi:** **Nhâm Tý - Nhâm Tý - Ất Hợi - Canh Thìn** (Nam mệnh cơ hàn vô tự).
- **Thể loại:** Cùng Thông Bảo Giám Bình Chú - Hàn mộc vô hỏa bần hàn.
- **Xuất xứ cổ tịch:** *Cùng Thông Bảo Giám* - Quyển 1: "Thập nhất nguyệt Ất Mộc".
- **Nguyên văn Hán tự:** 
  > 乙木生於子月，一片汪洋，四柱無丙丁之火解凍，木凍水寒，根枯枝折。平生漂泊無定，老無所依，凍餒而死。
- **Link kiểm chứng công khai:** [Wikisource - 窮通寶鑑 十一月乙木](https://zh.wikisource.org/wiki/窮通寶鑑#十一月乙木)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`.
- **Vị trí áp dụng:** Tập 06, Chương IX, Mệnh tạo 8.

---

### [REF-06-019]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Từ Nhạc Ngô — Canh Kim Sinh Tháng Tỵ Nhiệt Cực Dụng Nhâm Thủy (Lá số Bố Chánh Sứ).
- **Tứ trụ Can Chi:** **Bính Dần - Quý Tỵ - Canh Tuất - Canh Thìn** (Nam mệnh Bố chánh sứ).
- **Thể loại:** Cùng Thông Bảo Giám Bình Chú - Canh kim sơ hạ hỷ thủy nhuận.
- **Xuất xứ cổ tịch:** *Cùng Thông Bảo Giám* - Quyển 4: "Tứ nguyệt Canh Kim".
- **Nguyên văn Hán tự:** 
  > 庚金生於巳月，長生之地，火旺金脆。得癸水透干，辰土濕潤，潤土生金，制火護庚。行西方金運，官至布政使。
- **Link kiểm chứng công khai:** [Wikisource - 窮通寶鑑 四月庚金](https://zh.wikisource.org/wiki/窮通寶鑑#四月庚金)
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf`.
- **Vị trí áp dụng:** Tập 06, Chương IX, Mệnh tạo 9.

---

### [REF-06-020]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Từ Nhạc Ngô — Đinh Hỏa Sinh Tháng Dậu Hỷ Giáp Phối Canh (Lá số Hàn Lâm Học Sĩ).
- **Tứ trụ Can Chi:** **Ất Hợi - Ất Dậu - Đinh Tỵ - Canh Tý** (Nam mệnh Hàn lâm viện biên tu).
- **Thể loại:** Cùng Thông Bảo Giám Bình Chú - Đinh hỏa trọng thu đắc tài quan.
- **Xuất xứ cổ tịch:** *Cùng Thông Bảo Giám* - Quyển 2: "Bát nguyệt Đinh Hỏa".
- **Nguyên văn Hán tự:** 
  > 丁火生於酉月，日坐巳火，干透庚金，財旺身強。乙木引丁，水火相資。科甲連登，入翰林為學士。
- **Link kiểm chứng công khai:** [Wikisource - 窮通寶鑑 八月丁火](https://zh.wikisource.org/wiki/窮通寶鑑#八月丁火)
- **File đối chiếu nội bộ:** `Mệnh lý tinh hoa.pdf`.
- **Vị trí áp dụng:** Tập 06, Chương IX, Mệnh tạo 10.

---

### [REF-06-021]
- **Tiêu đề / Mệnh chủ:** Manh Phái Đoàn Kiến Nghiệp — Hỏa Viêm Thổ Táo Mù Lòa Song Mục (Bệnh Lý Khí Tượng).
- **Tứ trụ Can Chi:** **Bính Ngọ - Giáp Ngọ - Mậu Dần - Đinh Tỵ** (Nam mệnh mù lòa).
- **Thể loại:** Manh Phái Tố Công - Điều hậu khuyết tật tạng phủ.
- **Xuất xứ tài liệu:** *Lục Thân Cao Cấp Diện Thụ* - Đoàn Kiến Nghiệp. Tiết: "Luận Khí Huyết Tật Bệnh".
- **Đoạn trích đối chiếu:**
  > 八字純火，生於五月，火土炎炎，滴水皆無。火盛主心目，無水潤燥，木火焚燒，幼年雙目失明。
- **File đối chiếu nội bộ:** `Lục thân cao cấp diện thụ.docx` (Trang 188).
- **Vị trí áp dụng:** Tập 06, Chương IX, Mệnh tạo 11.

---

### [REF-06-022]
- **Tiêu đề / Mệnh chủ:** Manh Phái Đoàn Kiến Nghiệp — Kim Hàn Thủy Lãnh Tử Cung Băng Hàn Vô Tự (Nữ Mệnh Hiếm Muộn).
- **Tứ trụ Can Chi:** **Nhâm Tý - Nhâm Tý - Canh Thân - Kỷ Sửu** (Nữ mệnh bất dựng).
- **Thể loại:** Manh Phái Tố Công - Hàn thấp tử cung vô sinh.
- **Xuất xứ tài liệu:** *Bát Tự Trân Bảo Giảng Nghĩa* - Đoàn Kiến Nghiệp. Chương: "Khí Tượng & Hôn Nhân Tử Tức".
- **Đoạn trích đối chiếu:**
  > 庚金生於子月，地支申子全，水冷金寒，毫無丙丁之火暖局。女命逢之，子宮冰冷，一生無子，至老孤苦。
- **File đối chiếu nội bộ:** `Bát tự trân bảo giảng nghĩa.docx` (Trang 142).
- **Vị trí áp dụng:** Tập 06, Chương IX, Mệnh tạo 12.

---

### [REF-06-023]
- **Tiêu đề / Mệnh chủ:** Manh Phái Đoàn Kiến Nghiệp — Thấp Thổ Hối Hỏa Tố Công Tắc Nghẽn Phá Sản (Lâm Sàng Doanh Nhân).
- **Tứ trụ Can Chi:** **Kỷ Sửu - Đinh Sửu - Bính Thìn - Kỷ Sửu** (Nam mệnh vỡ nợ).
- **Thể loại:** Manh Phái Tố Công - Thấp khí diệt hỏa quang.
- **Xuất xứ tài liệu:** *Mệnh Lý Trân Bảo Giảng Nghĩa* - Đoàn Kiến Nghiệp. Chương: "Bát tự phá tài thực lệ".
- **Đoạn trích đối chiếu:**
  > 丙火坐辰，生於丑月，四柱三丑一辰，全為濕泥。丙丁之火微弱，盡被濕土晦滅。中年行水運，投資房地產徹底破產。
- **File đối chiếu nội bộ:** `Mệnh lý trân bảo giảng nghĩa.pdf` (Trang 96).
- **Vị trí áp dụng:** Tập 06, Chương IX, Mệnh tạo 13.

---

### [REF-06-024]
- **Tiêu đề / Mệnh chủ:** Manh Phái Đoàn Kiến Nghiệp — Hỏa Hạn Phùng Xung Khai Khố Bộc Phát Cự Phú.
- **Tứ trụ Can Chi:** **Bính Tuất - Ất Mùi - Mậu Dần - Quý Hợi** (Nam mệnh đại gia mỏ khoáng).
- **Thể loại:** Manh Phái Tố Công - Táo thổ đắc thủy nhuận khố khai.
- **Xuất xứ tài liệu:** *Lục Thân Cao Cấp Diện Thụ* - Đoàn Kiến Nghiệp. Chương: "Khai khố tố công thực chứng".
- **Đoạn trích đối chiếu:**
  > 戊土生於未月燥渴，妙在時透癸亥，時支財星潤土。大運逢辰衝戌開庫，火金交戰化為實業，開礦致富數億。
- **File đối chiếu nội bộ:** `Lục thân cao cấp diện thụ.docx` (Trang 215).
- **Vị trí áp dụng:** Tập 06, Chương IX, Mệnh tạo 14.

---

### [REF-06-025]
- **Tiêu đề / Mệnh chủ:** Manh Phái Đoàn Kiến Nghiệp — Thủy Đa Mộc Phiêu Mắc Bệnh Gan Mật Trầm Khang.
- **Tứ trụ Can Chi:** **Quý Hợi - Giáp Tý - Ất Hợi - Quý Hợi** (Nam mệnh ung thư gan).
- **Thể loại:** Manh Phái Tố Công - Hàn thủy phù mộc tạng phủ.
- **Xuất xứ tài liệu:** *Lục Thân Cao Cấp Diện Thụ* - Đoàn Kiến Nghiệp. Tiết: "Bệnh lý ngũ tạng đối ứng".
- **Đoạn trích đối chiếu:**
  > 乙木逢四柱純水，冬水凍結，木浮水上無根。木主肝膽，水多木漂無土焙植，行金運生水，得肝癌早逝。
- **File đối chiếu nội bộ:** `Lục thân cao cấp diện thụ.docx` (Trang 194).
- **Vị trí áp dụng:** Tập 06, Chương IX, Mệnh tạo 15.

---

### [REF-06-026]
- **Tiêu đề / Mệnh chủ:** Hiện Đại Thiệu Vĩ Hoa — Sinh Tháng Mùa Đông Di Cư Nam Tiến Đại Phát.
- **Tứ trụ Can Chi:** **Tân Hợi - Canh Tý - Giáp Dần - Đinh Mão** (Nam mệnh doanh nhân Việt kiều / TP.HCM).
- **Thể loại:** Tử Bình Thực Nghiệm - Cải mệnh phương vị địa lý Nam - Bắc.
- **Xuất xứ tài liệu:** *Dự Đoán Theo Tứ Trụ* - Thiệu Vĩ Hoa. Chương: "Phương vị cải mệnh thực nghiệm".
- **Đoạn trích đối chiếu:**
  > Giáp mộc sinh tháng Tý mùa đông miền Bắc rét đậm, thủy vượng mộc hàn, ở phương Bắc buôn bán bế tắc triền miên. Sau di cư vào phương Nam TP.HCM (vùng Hỏa vượng thái dương), đắc hỏa sưởi ấm, kích hoạt Đinh Mão thời trụ, lập nên chuỗi nhà hàng lớn phát đạt hàng chục tỷ.
- **File đối chiếu nội bộ:** `Dự đoán theo tứ trụ.docx` (Trang 178).
- **Vị trí áp dụng:** Tập 06, Chương IX, Mệnh tạo 16 & Chương XI.

---

### [REF-06-027]
- **Tiêu đề / Mệnh chủ:** Hiện Đại Thiệu Vĩ Hoa — Bính Hỏa Mùa Hè Thiếu Nước Bị Đột Quỵ Say Nắng.
- **Tứ trụ Can Chi:** **Mậu Ngọ - Mậu Ngọ - Bính Dần - Giáp Ngọ** (Nam mệnh tai biến mạch máu não).
- **Thể loại:** Tử Bình Thực Nghiệm - Bệnh nhiệt tạng tâm mạch.
- **Xuất xứ tài liệu:** *Dự Đoán Theo Tứ Trụ* - Thiệu Vĩ Hoa. Chương: "Dự đoán tật bệnh kinh nghiệm".
- **Đoạn trích đối chiếu:**
  > Bính hỏa sinh tháng Ngọ, tam chi tọa Ngọ, can thấu Mậu Giáp thuần hỏa cục không có một giọt thủy. Khí cực táo nhiệt làm tâm huyết bốc hỏa, năm Bính Ngọ gặp đợt nắng nóng cực đoan 42 độ C bị đột quỵ xuất huyết não.
- **File đối chiếu nội bộ:** `Dự đoán theo tứ trụ.docx` (Trang 215).
- **Vị trí áp dụng:** Tập 06, Chương IX, Mệnh tạo 17 & Chương XII.

---

### [REF-06-028]
- **Tiêu đề / Mệnh chủ:** Hiện Đại Trần Khang Ninh — Thấp Thổ Tháng Nồm Miền Bắc Mắc Bệnh Hô Hấp Phế Khí.
- **Tứ trụ Can Chi:** **Quý Sửu - Ất Mão - Canh Thìn - Kỷ Mão** (Nữ mệnh viêm xoang hen suyễn kinh niên).
- **Thể loại:** Dự Báo Theo Tử Bình - Khí hậu mùa nồm và bệnh lý hô hấp.
- **Xuất xứ tài liệu:** *Dự Báo Theo Tử Bình* - Trần Khang Ninh. Chương: "Khí hậu học ứng dụng trong Đông y Bát tự".
- **Đoạn trích đối chiếu:**
  > Canh kim sinh mùa xuân tháng Mão thấp thổ ngậm nước, Quý thủy thấu lộ, độ ẩm vượt quá 95%. Canh kim bị ẩm ướt rỉ sét, phế kim suy kiệt sinh chứng viêm xoang và hen phế quản kinh niên mỗi độ tháng 2-3 âm lịch mùa nồm ẩm miền Bắc.
- **File đối chiếu nội bộ:** `dự-báo-theo-tử-bình-trần-khang-ninh-pdf-dantocking.com.PDF` (Trang 182).
- **Vị trí áp dụng:** Tập 06, Chương IX, Mệnh tạo 18 & Chương XII.

---

### [REF-06-029]
- **Tiêu đề / Mệnh chủ:** Hiện Đại Trần Khang Ninh — Mùa Hè Nắng Hạn Tây Bắc Khởi Nghiệp Trồng Cây Thảo Dược Thành Công.
- **Tứ trụ Can Chi:** **Kỷ Mùi - Tân Mùi - Giáp Thìn - Bính Dần** (Nam mệnh kỹ sư nông nghiệp sạch).
- **Thể loại:** Dự Báo Theo Tử Bình - Điều hậu nông nghiệp sinh thái.
- **Xuất xứ tài liệu:** *Dự Báo Theo Tử Bình* - Trần Khang Ninh. Chương: "Chọn ngành nghề nông nghiệp công nghệ cao".
- **Đoạn trích đối chiếu:**
  > Giáp mộc sinh tháng Mùi đất khô nứt, may có Thìn thổ chi ngày chứa nước ngầm và Dần mộc tiếp rễ, can thấu Bính hỏa quang hợp. Đương số chọn vùng cao nguyên mát mẻ Mộc Châu trồng thảo dược hữu cơ, thuận thiên ứng khí thu lợi nhuận lớn.
- **File đối chiếu nội bộ:** `dự-báo-theo-tử-bình-trần-khang-ninh-pdf-dantocking.com.PDF` (Trang 205).
- **Vị trí áp dụng:** Tập 06, Chương IX, Mệnh tạo 19 & Chương XI.

---

### [REF-06-030]
- **Tiêu đề / Mệnh chủ:** Hiện Đại Trần Khang Ninh — Kim Hàn Thủy Lãnh Khởi Nghiệp Công Nghệ Số Bất Động Sản Ven Biển.
- **Tứ trụ Can Chi:** **Canh Thân - Mậu Tý - Tân Hợi - Đinh Dậu** (Nam mệnh founder công ty logistics cảng biển).
- **Thể loại:** Dự Báo Theo Tử Bình - Kim thủy tương hàm đắc hỏa ấm.
- **Xuất xứ tài liệu:** *Dự Báo Theo Tử Bình* - Trần Khang Ninh. Chương: "Doanh nhân thời đại số và khí tượng Bát tự".
- **Đoạn trích đối chiếu:**
  > Tân kim sinh tháng Tý kim bạch thủy thanh cực kỳ thông minh nhạy bén, đắc Đinh hỏa thời can sưởi ấm cục diện, Mậu thổ đê điều ngăn thủy. Chọn khởi nghiệp tại thành phố cảng Hải Phòng và Đà Nẵng, phát triển hệ thống logistics và kho bãi ven biển trở thành doanh nghiệp nghìn tỷ.
- **File đối chiếu nội bộ:** `dự-báo-theo-tử-bình-trần-khang-ninh-pdf-dantocking.com.PDF` (Trang 240).
- **Vị trí áp dụng:** Tập 06, Chương IX, Mệnh tạo 20 & Chương XI.

---

*(Bảng danh mục tiếp tục được tự động cập nhật đồng bộ xuyên suốt quá trình biên soạn cho toàn bộ 10 Tập)*


---

# DANH MỤC TRÍCH DẪN & KHẢO CHỨNG HỌC THUẬT: TẬP 07
## TỬ BÌNH CHÂN THUYÊN — BÁT CHÍNH CÁCH & BIẾN CÁCH TOÀN THƯ
*(Mã định danh hệ thống: [REF-07-001] đến [REF-07-030])*

---

### [REF-07-001]
- **Nội dung / Khái niệm:** Bản thể luận Nguyệt Lệnh vi Dụng Thần & Khung Cương Kỷ Xã Hội Học Cách Cục.
- **Thể loại:** Cổ điển Cách Cục Học Chính Tông.
- **Xuất xứ cổ tịch:** *Tử Bình Chân Thuyên* (子平真詮) - Trầm Hiếu Thắng nguyên tác, Từ Nhạc Ngô bình chú. Thiên: "Luận Dụng Thần" (論用神).
- **Nguyên văn Hán tự:** 
  > 八字用神，專求月令。月令者，當提之綱領也。人稟天地之氣，以月令為主；府庫之門，出入皆由此處。看命先觀月令，何者得氣，何者乘權，方可定其格局。
- **Phiên âm Hán Việt:** Bát tự dụng thần, chuyên cầu nguyệt lệnh. Nguyệt lệnh giả, đương đề chi cương lĩnh dã. Nhân bẩm thiên địa chi khí, dĩ nguyệt lệnh vi chủ; phủ khố chi môn, xuất nhập giai do thử xứ. Khán mệnh tiên quan nguyệt lệnh, hà giả đắc khí, hà giả thừa quyền, phương khả định kỳ cách cục.
- **Link kiểm chứng công khai:** [Chinese Text Project - 子平真詮 論用神](https://ctext.org/wiki.pl?if=gb&chapter=382741) & [Wikisource - 子平真詮](https://zh.wikisource.org/wiki/子平真詮#論用神)
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf` (Chương 1: Luận Dụng Thần) & `Mệnh lý tinh hoa.pdf`.
- **Vị trí áp dụng:** Tập 07, Chương I: "Bản Thể Luận Cách Cục — Khung Quy Chế Xã Hội Của Sinh Mệnh".

---

### [REF-07-002]
- **Nội dung / Khái niệm:** Nguyên lý Thuận Dụng Tứ Cát Thần (Quan, Ấn, Tài, Thực) vs Nghịch Dụng Tứ Hung Thần (Sát, Thương, Kiêu, Nhận).
- **Thể loại:** Cổ điển Cách Cục Học Chính Tông.
- **Xuất xứ cổ tịch:** *Tử Bình Chân Thuyên* (子平真詮) - Thiên: "Luận Thuận Dụng Nghịch Dụng" (論用神順逆).
- **Nguyên văn Hán tự:** 
  > 用神專求月令，各有所司。四吉神順用之，四凶神逆用之。何謂順？財喜食生，印喜官生，官喜財生，食喜生財，順也。何謂逆？煞喜食制，傷喜印配，刃喜官煞，梟喜財制，逆也。順逆得宜，皆成貴格。
- **Phiên âm Hán Việt:** Dụng thần chuyên cầu nguyệt lệnh, các hữu sở ty. Tứ cát thần thuận dụng chi, tứ hung thần nghịch dụng chi. Hà vị thuận? Tài hỷ thực sinh, ấn hỷ quan sinh, quan hỷ tài sinh, thực hỷ sinh tài, thuận dã. Hà vị nghịch? Sát hỷ thực chế, thương hỷ ấn phối, nhận hỷ quan sát, kiêu hỷ tài chế, nghịch dã. Thuận nghịch đắc nghi, giai thành quý cách.
- **Link kiểm chứng công khai:** [Chinese Text Project - 子平真詮 論用神順逆](https://ctext.org/wiki.pl?if=gb&chapter=382742) & [Wikisource - 子平真詮](https://zh.wikisource.org/wiki/子平真詮#論順逆)
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf` (Trang 24).
- **Vị trí áp dụng:** Tập 07, Chương I, Mục 2: "Tứ Cát Thần vs Tứ Hung Thần".

---

### [REF-07-003]
- **Nội dung / Khái niệm:** Tướng Thần Hộ Vệ Cách Cục — Đấng Cứu Thế Của Mệnh Lý Học.
- **Thể loại:** Cổ điển Cách Cục Học Chính Tông.
- **Xuất xứ cổ tịch:** *Tử Bình Chân Thuyên* (子平真詮) - Thiên: "Luận Tướng Thần Cứu Ứng" (論相神).
- **Nguyên văn Hán tự:** 
  > 月令既得用神，必有相神以佐之。相神者，輔佐用神而成格局者也。如官用財生，財即相神；煞逢食制，食即相神；印逢官生，官即相神。相神傷則破格，相神完則成格。
- **Phiên âm Hán Việt:** Nguyệt lệnh ký đắc dụng thần, tất hữu tướng thần dĩ tá chi. Tướng thần giả, phụ tá dụng thần nhi thành cách cục giả dã. Như quan dụng tài sinh, tài tức tướng thần; sát phùng thực chế, thực tức tướng thần; ấn phùng quan sinh, quan tức tướng thần. Tướng thần thương tắc phá cách, tướng thần hoàn tắc thành cách.
- **Link kiểm chứng công khai:** [Chinese Text Project - 子平真詮 論相神](https://ctext.org/wiki.pl?if=gb&chapter=382743) & [Wikisource - 子平真詮](https://zh.wikisource.org/wiki/子平真詮#論相神)
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf` (Trang 38).
- **Vị trí áp dụng:** Tập 07, Chương I, Mục 3: "Tam giác Dụng Thần - Tướng Thần - Kỵ Thần".

---

### [REF-07-004]
- **Nội dung / Khái niệm:** Quy chế Toàn thư Thành Cách, Bại Cách & Cứu Ứng Phá Bại Thành Thành.
- **Thể loại:** Cổ điển Cách Cục Học Chính Tông.
- **Xuất xứ cổ tịch:** *Tử Bình Chân Thuyên* (子平真詮) - Thiên: "Luận Dụng Thần Thành Bại Cứu Ứng" (論成敗救應).
- **Nguyên văn Hán tự:** 
  > 用神成中有敗，必有救應之法。官逢傷而印透，印即救應；財逢劫而食透，食即救應；煞逢財而食化，食即救應。何謂成？財旺生官，煞逢食制，印綬逢官，食神生財，成也。何謂敗？官逢傷克，財逢劫奪，印逢財破，食逢梟奪，敗也。
- **Phiên âm Hán Việt:** Dụng thần thành trung hữu bại, tất hữu cứu ứng chi pháp. Quan phùng thương nhi ấn thấu, ấn tức cứu ứng; tài phùng kiếp nhi thực thấu, thực tức cứu ứng; sát phùng tài nhi thực hóa, thực tức cứu ứng. Hà vị thành? Tài vượng sinh quan, sát phùng thực chế, ấn thụ phùng quan, thực thần sinh tài, thành dã. Hà vị bại? Quan phùng thương khắc, tài phùng kiếp đoạt, ấn phùng tài phá, thực phùng kiêu đoạt, bại dã.
- **Link kiểm chứng công khai:** [Chinese Text Project - 子平真詮 論成敗救應](https://ctext.org/wiki.pl?if=gb&chapter=382744) & [Wikisource - 子平真詮](https://zh.wikisource.org/wiki/子平真詮#論成敗救應)
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf` (Trang 45).
- **Vị trí áp dụng:** Tập 07, Chương VIII: "Cơ Chế Thành Trung Hữu Bại & Bại Trung Hữu Thành".

---

### [REF-07-005]
- **Nội dung / Khái niệm:** Cơ chế Biến Cách & Chuyển Cách Khí Hóa Động Học.
- **Thể loại:** Cổ điển Cách Cục Học Chính Tông.
- **Xuất xứ cổ tịch:** *Tử Bình Chân Thuyên* (子平真詮) - Thiên: "Luận Dụng Thần Biến Hóa" (論用神變化).
- **Nguyên văn Hán tự:** 
  > 用神之變，善惡互換，禍福相依。如辛生寅月，本為正財，透丙化為正官；透戊化為正印。一月之氣，因干頭之透而格局隨之遷變。有變而善者，有變而不善者。
- **Phiên âm Hán Việt:** Dụng thần chi biến, thiện ác hỗ hoán, họa phúc tương y. Như Tân sinh Dần nguyệt, bản vi chính tài, thấu Bính hóa vi chính quan; thấu Mậu hóa vi chính ấn. Nhất nguyệt chi khí, nhân can đầu chi thấu nhi cách cục tùy chi thiên biến. Hữu biến nhi thiện giả, hữu biến nhi bất thiện giả.
- **Link kiểm chứng công khai:** [Chinese Text Project - 子平真詮 論用神變化](https://ctext.org/wiki.pl?if=gb&chapter=382745) & [Wikisource - 子平真詮](https://zh.wikisource.org/wiki/子平真詮#論變化)
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf` (Trang 52).
- **Vị trí áp dụng:** Tập 07, Chương I & Chương VIII.

---

### [REF-07-006]
- **Nội dung / Khái niệm:** Tạp Khí Nguyệt Lệnh (Thìn Tuất Sửu Mùi) Thấu Can Định Cách & Khố Phùng Khai Xung.
- **Thể loại:** Cổ điển Cách Cục Học Chính Tông.
- **Xuất xứ cổ tịch:** *Tử Bình Chân Thuyên* (子平真詮) - Thiên: "Luận Mộ Khố Hình Xung" (論墓庫刑衝) & *Tam Mệnh Thông Hội*.
- **Nguyên văn Hán tự:** 
  > 辰戌丑未為雜氣，天地交泰之候。庫中藏物，深沉不顯。干頭透出何物，即以何物定格。不透則以本氣為土。古人謂“庫逢衝則開”，實乃刑衝破害，引動庫內之物，善惡隨之發越。
- **Phiên âm Hán Việt:** Thìn Tuất Sửu Mùi vi tạp khí, thiên địa giao thái chi hậu. Khố trung tàng vật, thâm trầm bất hiển. Can đầu thấu xuất hà vật, tức dĩ hà vật định cách. Bất thấu tắc dĩ bản khí vi thổ. Cổ nhân vị "Khố phùng xung tắc khai", thực nãi hình xung phá hại, dẫn động khố nội chi vật, thiện ác tùy chi phát việt.
- **Link kiểm chứng công khai:** [Chinese Text Project - 子平真詮 論墓庫](https://ctext.org/wiki.pl?if=gb&chapter=382746) & [Wikisource - 子平真詮](https://zh.wikisource.org/wiki/子平真詮#論墓庫)
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf` & `Mệnh Ly huyền cơ tham bí.pdf`.
- **Vị trí áp dụng:** Tập 07, Chương I & Chương III.

---

### [REF-07-007]
- **Nội dung / Khái niệm:** Thanh Trọc & Thuần Tạp Đẳng Cấp Phân Định Quý Tiện.
- **Thể loại:** Cổ điển Cách Cục Học Chính Tông.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy* (滴天髓) - Lưu Bá Ôn nguyên tác, Nhậm Thiết Tiều bình chú. Thiên: "Thanh Trọc" (清濁) & *Chân Thuyên* "Luận Thuần Tạp".
- **Nguyên văn Hán tự:** 
  > 一清到底有精神，管取生平富貴真。澄濁求清清得去，時來寒谷也回春。滿盤濁氣令人倦，富貴無緣總落空。格清局正，公卿之輔；格濁氣亂，市井之民。
- **Phiên âm Hán Việt:** Nhất thanh đáo để hữu tinh thần, quản thủ sinh bình phú quý chân. Trừng trọc cầu thanh thanh đắc khứ, thời lai hàn cốc dã hồi xuân. Mãn bàn trọc khí lệnh nhân quyện, phú quý vô duyên tổng lạc không. Cách thanh cục chính, công khanh chi phụ; cách trọc khí loạn, thị tỉnh chi dân.
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓 清濁](https://zh.wikisource.org/wiki/滴天髓#清濁) & [ctext.org - 子平真詮](https://ctext.org)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf` (Chương Thanh Trọc).
- **Vị trí áp dụng:** Tập 07, Chương I & Chương X (Hệ thống PPS).

---

### [REF-07-008]
- **Nội dung / Khái niệm:** Cơ chế Quan Sát Hỗn Tạp & Phép Khứ Lưu Thanh Cách (Khứ Quan Lưu Sát / Khứ Sát Lưu Quan).
- **Thể loại:** Cổ điển Cách Cục Học Chính Tông.
- **Xuất xứ cổ tịch:** *Tử Bình Chân Thuyên* (子平真詮) - Thiên: "Luận Quan Sát Hỗn Tạp" (論官煞混雜).
- **Nguyên văn Hán tự:** 
  > 官煞相混，格之大忌。清者貴，混者賤。去官留煞，煞氣反清；去煞留官，官星自秀。以合去之，以克去之，去留得所，反成大器。
- **Phiên âm Hán Việt:** Quan sát tương hỗn, cách chi đại kỵ. Thanh giả quý, hỗn giả tiện. Khứ quan lưu sát, sát khí phản thanh; khứ sát lưu quan, quan tinh tự tú. Dĩ hợp khứ chi, dĩ khắc khứ chi, khứ lưu đắc sở, phản thành đại khí.
- **Link kiểm chứng công khai:** [Chinese Text Project - 子平真詮 論官煞混雜](https://ctext.org/wiki.pl?if=gb&chapter=382747) & [Wikisource - 子平真詮](https://zh.wikisource.org/wiki/子平真詮#論官煞混雜)
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf` (Trang 68).
- **Vị trí áp dụng:** Tập 07, Chương II: "Quan Sát Hệ".

---

### [REF-07-009]
- **Nội dung / Khái niệm:** Bản thể luận Thập Đại Biến Cách & Ngoại Cách Huyền Bí trong Mệnh lý học.
- **Thể loại:** Cổ điển Ngoại Cách Bát Tự.
- **Xuất xứ cổ tịch:** *Tam Mệnh Thông Hội* (三命通會) - Vạn Dân Anh & *Uyên Hải Tử Bình* (淵海子平) - Từ Thăng.
- **Nguyên văn Hán tự:** 
  > 正格之外，復有變格。魁罡、金神、飛天祿馬、六乙鼠貴、六陰朝陽、專旺從化之類。變格者，不求月令之生克，專取干支之神氣。得局純粹，位極人臣；失局破敗，貧苦無告。
- **Phiên âm Hán Việt:** Chính cách chi ngoại, phục hữu biến cách. Khôi Canh, Kim Thần, Phi Thiên Lộc Mã, Lục Ất Thử Quý, Lục Âm Triều Dương, Chuyên Vượng Tòng Hóa chi loại. Biến cách giả, bất cầu nguyệt lệnh chi sinh khắc, chuyên thủ can chi chi thần khí. Đắc cục thuần túy, vị cực nhân thần; thất cục phá bại, bần khổ vô cáo.
- **Link kiểm chứng công khai:** [Wikisource - 三命通會 變格](https://zh.wikisource.org/wiki/三命通會) & [ctext.org - 淵海子平](https://ctext.org)
- **File đối chiếu nội bộ:** `Mệnh lý tinh hoa.pdf` (Chương Biến cách ngoại cách).
- **Vị trí áp dụng:** Tập 07, Chương VII: "Thập Đại Biến Cách & Ngoại Cách Huyền Bí".

---

### [REF-07-010]
- **Nội dung / Khái niệm:** Cơ chế Khí thế Chuyên Vượng Cách (Khúc Trực, Viêm Thượng, Giá Sắc, Tòng Cách, Nhuận Hạ) & Đạo Thuận Thiên.
- **Thể loại:** Cổ điển Nhất Khí Chuyên Vượng.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy* (滴天髓) - Thiên: "Độc Tượng" (獨象) & *Tử Bình Chân Thuyên* "Luận Tòng Cách".
- **Nguyên văn Hán tự:** 
  > 一氣專旺，五行偏盛。木盛曲直，火盛炎上，土盛稼穡，金盛從革，水盛潤下。得時得位，乘天運而生。順其氣勢以生發，最畏逆氣以相犯。行生旺食傷之運，富貴無涯。
- **Phiên âm Hán Việt:** Nhất khí chuyên vượng, ngũ hành thiên thịnh. Mộc thịnh khúc trực, hỏa thịnh viêm thượng, thổ thịnh giá sắc, kim thịnh tòng cách, thủy thịnh nhuận hạ. Đắc thời đắc vị, thừa thiên vận nhi sinh. Thuận kỳ khí thế dĩ sinh phát, tối úy nghịch khí dĩ tương phạm. Hành sinh vượng thực thương chi vận, phú quý vô nhai.
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓 獨象](https://zh.wikisource.org/wiki/滴天髓#獨象) & [Chinese Text Project](https://ctext.org)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`.
- **Vị trí áp dụng:** Tập 07, Chương VII, Mục 5.

---

### [REF-07-011]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Trầm Hiếu Thắng — Chính Quan Cách Phối Ấn Tướng Tướng (Lá số Kim Thừa Tướng).
- **Tứ trụ Can Chi:** **Tân Mão - Đinh Dậu - Canh Ngọ - Bính Tuất** (Nam mệnh Thừa tướng).
- **Thể loại:** Tử Bình Chân Thuyên - Chính Quan Cách đắc Ấn hóa Sát.
- **Xuất xứ cổ tịch:** *Tử Bình Chân Thuyên* (子平真詮) - Quyển 2: "Luận Chính Quan Cách thực lệ".
- **Nguyên văn Hán tự:** 
  > 庚生酉月，陽刃秉令。日坐午火正官，時透丙火七煞，天干官煞並透。妙在年透辛金劫刃，合去丙煞，專留午中正官，丁火出干為正官，格成大貴，位至丞相。
- **Phiên âm Hán Việt:** Canh sinh Dậu nguyệt, Dương Nhận bỉnh lệnh. Nhật tọa Ngọ hỏa chính quan, thời thấu Bính hỏa thất sát, thiên can quan sát tịnh thấu. Diệu tại niên thấu Tân kim kiếp nhận, hợp khứ Bính sát, chuyên lưu Ngọ trung chính quan, Đinh hỏa xuất can vi chính quan, cách thành đại quý, vị chí thừa tướng.
- **Link kiểm chứng công khai:** [Wikisource - 子平真詮 正官](https://zh.wikisource.org/wiki/子平真詮#論正官)
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf` (Trang 82).
- **Vị trí áp dụng:** Tập 07, Chương II & Chương IX, Mệnh tạo 1.

---

### [REF-07-012]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Nhậm Thiết Tiều — Thất Sát Cách Thân Cường Sát Cường Khí Phách Anh Hùng (Lá số Nhạc Phi Tướng Quân).
- **Tứ trụ Can Chi:** **Quý Mùi - Ất Mão - Giáp Tý - Kỷ Tỵ** (Nam mệnh Kháng Kim Danh Tướng).
- **Thể loại:** Trích Thiên Tủy Bình Chú - Sát Nhận tương đình cái thế anh hùng.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Bình Chú* (滴天髓評註) - Nhậm Thiết Tiều. Chương: "Quan Sát biến hóa".
- **Nguyên văn Hán tự:** 
  > 甲生卯月，陽刃乘權，干透乙木，身強極矣。年透癸水正印生木，時落己巳，財煞俱藏。行南方火運，食神制煞，統兵抗金，名垂千古。
- **Phiên âm Hán Việt:** Giáp sinh Mão nguyệt, Dương Nhận thừa quyền, can thấu Ất mộc, thân cường cực hĩ. Niên thấu Quý thủy chính ấn sinh mộc, thời lạc Kỷ Tỵ, tài sát câu tàng. Hành phương Nam hỏa vận, thực thần chế sát, thống binh kháng Kim, danh thùy thiên cổ.
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓評註 陽刃](https://zh.wikisource.org/wiki/滴天髓#陽刃)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf` (Trang 145).
- **Vị trí áp dụng:** Tập 07, Chương II & Chương IX, Mệnh tạo 2.

---

### [REF-07-013]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Trầm Hiếu Thắng — Chính Tài Cách Dụng Thực Sinh Tài Phú Quý Song Toàn (Lá số Tuyên Phủ Đại Nhân).
- **Tứ trụ Can Chi:** **Mậu Ngọ - Canh Thân - Giáp Dần - Bính Dần** (Nam mệnh Tuyên phủ sứ).
- **Thể loại:** Tử Bình Chân Thuyên - Chính Tài Cách hỷ Thực sinh.
- **Xuất xứ cổ tịch:** *Tử Bình Chân Thuyên* - Quyển 2: "Luận Tài Cách".
- **Nguyên văn Hán tự:** 
  > 甲生申月，煞旺當令。妙在日坐寅木專祿，時透丙火食神，制煞生財。年透戊土偏財，通根午火，財旺食清，位至宣撫。
- **Phiên âm Hán Việt:** Giáp sinh Thân nguyệt, sát vượng đương lệnh. Diệu tại nhật tọa Dần mộc chuyên lộc, thời thấu Bính hỏa thực thần, chế sát sinh tài. Niên thấu Mậu thổ thiên tài, thông căn Ngọ hỏa, tài vượng thực thanh, vị chí tuyên phủ.
- **Link kiểm chứng công khai:** [Wikisource - 子平真詮 論財](https://zh.wikisource.org/wiki/子平真詮#論財)
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf`.
- **Vị trí áp dụng:** Tập 07, Chương III & Chương IX, Mệnh tạo 3.

---

### [REF-07-014]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Trầm Hiếu Thắng — Thiên Tài Cách Tài Vượng Thân Nhược Tòng Tài Biến Quý (Lá số Tăng Tham Chính).
- **Tứ trụ Can Chi:** **Kỷ Mùi - Nhâm Thân - Bính Thân - Bính Thân** (Nam mệnh Tham chính đại nhân).
- **Thể loại:** Tử Bình Chân Thuyên - Thiên Tài cách địa chi tam Thân.
- **Xuất xứ cổ tịch:** *Tử Bình Chân Thuyên* - Quyển 2: "Luận Tài Cách biến hóa".
- **Nguyên văn Hán tự:** 
  > 丙生申月，支全三申，財氣極旺。干透壬水七煞，妙在年柱己未傷官，制煞生財，財又生煞。身旺任財，行東南方大運，位登參政。
- **Phiên âm Hán Việt:** Bính sinh Thân nguyệt, chi toàn tam Thân, tài khí cực vượng. Can thấu Nhâm thủy thất sát, diệu tại niên trụ Kỷ Mùi thương quan, chế sát sinh tài, tài hựu sinh sát. Thân vượng nhậm tài, hành Đông Nam phương đại vận, vị đăng tham chính.
- **Link kiểm chứng công khai:** [Wikisource - 子平真詮 偏財](https://zh.wikisource.org/wiki/子平真詮#論財)
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf`.
- **Vị trí áp dụng:** Tập 07, Chương III & Chương IX, Mệnh tạo 4.

---

### [REF-07-015]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Trầm Hiếu Thắng — Chính Ấn Cách Phùng Quan Sinh Ấn (Lá số Trương Tham Chính).
- **Tứ trụ Can Chi:** **Bính Dần - Mậu Tuất - Tân Mùi - Nhâm Thìn** (Nam mệnh Tham chính).
- **Thể loại:** Tử Bình Chân Thuyên - Chính Ấn Cách thụ sinh.
- **Xuất xứ cổ tịch:** *Tử Bình Chân Thuyên* - Quyển 3: "Luận Ấn Thụ Cách".
- **Nguyên văn Hán tự:** 
  > 辛生戌月，印綬乘司。年透丙火正官，生助戊土正印。四柱四庫兼全，土重金埋，喜得時透壬水傷官淘洗，格成大貴。
- **Phiên âm Hán Việt:** Tân sinh Tuất nguyệt, ấn thụ thừa ty. Niên thấu Bính hỏa chính quan, sinh trợ Mậu thổ chính ấn. Tứ trụ tứ khố kiêm toàn, thổ trọng kim mai, hỷ đắc thời thấu Nhâm thủy thương quan đào tẩy, cách thành đại quý.
- **Link kiểm chứng công khai:** [Wikisource - 子平真詮 論印](https://zh.wikisource.org/wiki/子平真詮#論印綬)
- **File đối chiếu nội bộ:** `Mệnh lý tinh hoa.pdf`.
- **Vị trí áp dụng:** Tập 07, Chương IV & Chương IX, Mệnh tạo 5.

---

### [REF-07-016]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Trầm Hiếu Thắng — Kiêu Thần Cách (Thiên Ấn) Đắc Tài Chế Hóa Vi Quý (Lá số Vương Thị Lang).
- **Tứ trụ Can Chi:** **Quý Hợi - Giáp Dần - Bính Thìn - Canh Dần** (Nam mệnh Thị lang lục bộ).
- **Thể loại:** Tử Bình Chân Thuyên - Kiêu thần phùng tài chế.
- **Xuất xứ cổ tịch:** *Tử Bình Chân Thuyên* - Quyển 3: "Luận Thiên Ấn".
- **Nguyên văn Hán tự:** 
  > 丙生寅月，偏印當權，木火同宮。時透庚金偏財，制木以護身，水木清澈，財印交資，官至侍郎。
- **Phiên âm Hán Việt:** Bính sinh Dần nguyệt, thiên ấn đương quyền, mộc hỏa đồng cung. Thời thấu Canh kim thiên tài, chế mộc dĩ hộ thân, thủy mộc thanh triệt, tài ấn giao tư, quan chí thị lang.
- **Link kiểm chứng công khai:** [Wikisource - 子平真詮 偏印](https://zh.wikisource.org/wiki/子平真詮#論偏印)
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf`.
- **Vị trí áp dụng:** Tập 07, Chương IV & Chương IX, Mệnh tạo 6.

---

### [REF-07-017]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Trầm Hiếu Thắng — Thực Thần Cách Chế Sát Sinh Tài Danh Chấn Giang Sơn (Lá số Thư Diệp Thượng Thư).
- **Tứ trụ Can Chi:** **Mậu Dần - Quý Hợi - Bính Tuất - Đinh Dậu** (Nam mệnh Thượng thư).
- **Thể loại:** Tử Bình Chân Thuyên - Thực thần chế sát cách.
- **Xuất xứ cổ tịch:** *Tử Bình Chân Thuyên* - Quyển 3: "Luận Thực Thần".
- **Nguyên văn Hán tự:** 
  > 丙生亥月，煞星秉令。年透戊土食神，通根寅戌，克制亥中壬煞。財星在時，煞化為權，位居尚書。
- **Phiên âm Hán Việt:** Bính sinh Hợi nguyệt, sát tinh bỉnh lệnh. Niên thấu Mậu thổ thực thần, thông căn Dần Tuất, khắc chế Hợi trung Nhâm sát. Tài tinh tại thời, sát hóa vi quyền, vị cư thượng thư.
- **Link kiểm chứng công khai:** [Wikisource - 子平真詮 論食神](https://zh.wikisource.org/wiki/子平真詮#論食神)
- **File đối chiếu nội bộ:** `Mệnh Ly huyền cơ tham bí.pdf`.
- **Vị trí áp dụng:** Tập 07, Chương V & Chương IX, Mệnh tạo 7.

---

### [REF-07-018]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Trầm Hiếu Thắng — Thương Quan Phối Ấn Thân Nhược Hóa Quý (Lá số Hạ Các Lão).
- **Tứ trụ Can Chi:** **Nhâm Thân - Tân Hợi - Tân Dậu - Mậu Tý** (Nam mệnh Nội các Các lão).
- **Thể loại:** Tử Bình Chân Thuyên - Thương Quan phối Ấn thành quý.
- **Xuất xứ cổ tịch:** *Tử Bình Chân Thuyên* - Quyển 3: "Luận Thương Quan".
- **Nguyên văn Hán tự:** 
  > 辛生亥月，水勢汪洋，金水傷官。妙在時透戊土正印，止水生金，潤土生苗，格成極品，位列內閣輔臣。
- **Phiên âm Hán Việt:** Tân sinh Hợi nguyệt, thủy thế uông dương, kim thủy thương quan. Diệu tại thời thấu Mậu thổ chính ấn, chỉ thủy sinh kim, nhuận thổ sinh miêu, cách thành cực phẩm, vị liệt nội các phụ thần.
- **Link kiểm chứng công khai:** [Wikisource - 子平真詮 商官](https://zh.wikisource.org/wiki/子平真詮#論傷官)
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf`.
- **Vị trí áp dụng:** Tập 07, Chương V & Chương IX, Mệnh tạo 8.

---

### [REF-07-019]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Trầm Hiếu Thắng — Dương Nhận Cách Đắc Canh Kim Thất Sát Tương Đình (Lá số Tiêu Tướng Công).
- **Tứ trụ Can Chi:** **Bính Dần - Canh Dần - Giáp Thân - Kỷ Tỵ** (Nam mệnh Tướng công).
- **Thể loại:** Tử Bình Chân Thuyên - Dương Nhận phùng Sát.
- **Xuất xứ cổ tịch:** *Tử Bình Chân Thuyên* - Quyển 4: "Luận Dương Nhận".
- **Nguyên văn Hán tự:** 
  > 甲生寅月，祿刃並聚。月透庚金七煞，年透丙火食神制煞。煞刃兩停，干戈平息，出將入相，名高一代。
- **Phiên âm Hán Việt:** Giáp sinh Dần nguyệt, lộc nhận tịnh tụ. Nguyệt thấu Canh kim thất sát, niên thấu Bính hỏa thực thần chế sát. Sát nhận lưỡng đình, can qua bình tức, xuất tướng nhập tướng, danh cao nhất đại.
- **Link kiểm chứng công khai:** [Wikisource - 子平真詮 陽刃](https://zh.wikisource.org/wiki/子平真詮#論陽刃)
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf`.
- **Vị trí áp dụng:** Tập 07, Chương VI & Chương IX, Mệnh tạo 9.

---

### [REF-07-020]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Trầm Hiếu Thắng — Kiến Lộc Cách Đắc Tài Quan Lưỡng Thấu (Lá số Tào Trạng Nguyên).
- **Tứ trụ Can Chi:** **Ất Mão - Kỷ Mão - Giáp Dần - Ất Hợi** (Nam mệnh Trạng nguyên khoa giáp).
- **Thể loại:** Tử Bình Chân Thuyên - Kiến Lộc cách dụng Tài sinh Quan.
- **Xuất xứ cổ tịch:** *Tử Bình Chân Thuyên* - Quyển 4: "Luận Kiến Lộc Nguyệt Kiếp".
- **Nguyên văn Hán tự:** 
  > 甲生卯月，陽刃乘司。干支純木，氣勢歸一。妙在月透己土正財，年透乙木劫財。行火土運，順木之性，大魁天下。
- **Phiên âm Hán Việt:** Giáp sinh Mão nguyệt, Dương Nhận thừa ty. Can chi thuần mộc, khí thế quy nhất. Diệu tại nguyệt thấu Kỷ thổ chính tài, niên thấu Ất mộc kiếp tài. Hành hỏa thổ vận, thuận mộc chi tính, đại khôi thiên hạ.
- **Link kiểm chứng công khai:** [Wikisource - 子平真詮 建祿](https://zh.wikisource.org/wiki/子平真詮#論建祿)
- **File đối chiếu nội bộ:** `Mệnh lý tinh hoa.pdf`.
- **Vị trí áp dụng:** Tập 07, Chương VI & Chương IX, Mệnh tạo 10.

---

### [REF-07-021]
- **Tiêu đề / Mệnh chủ:** Manh Phái Đoàn Kiến Nghiệp — Chính Quan Phùng Thương Phá Cách Lao Ngục (Lâm Sàng Tố Công).
- **Tứ trụ Can Chi:** **Mậu Thìn - Đinh Tỵ - Canh Tý - Quý Mùi** (Nam mệnh hình sự tù tội).
- **Thể loại:** Manh Phái Tố Công - Phá cách hại quan.
- **Xuất xứ tài liệu:** *Lục Thân Cao Cấp Diện Thụ* - Đoàn Kiến Nghiệp. Tiết: "Quan tinh bị phá định hình lao ngục".
- **Đoạn trích đối chiếu:**
  > 庚金生於巳月，巳為正官。日坐子水傷官，時透癸水傷官，水火交戰，傷官見官。地支子巳絕，行水運衝破官根，貪污入獄十年。
- **File đối chiếu nội bộ:** `Lục thân cao cấp diện thụ.docx` (Trang 142).
- **Vị trí áp dụng:** Tập 07, Chương IX, Mệnh tạo 11.

---

### [REF-07-022]
- **Tiêu đề / Mệnh chủ:** Manh Phái Đoàn Kiến Nghiệp — Thực Thần Chế Sát Khống Chế Cục Lãnh Đạo Cao Cấp (Lâm Sàng Quan Lộ).
- **Tứ trụ Can Chi:** **Nhâm Thìn - Bính Ngọ - Tân Mùi - Quý Tỵ** (Nam mệnh giám đốc sở tài chính).
- **Thể loại:** Manh Phái Tố Công - Thực thần chế sát tố công.
- **Xuất xứ tài liệu:** *Mệnh Lý Trân Bảo Giảng Nghĩa* - Đoàn Kiến Nghiệp. Chương: "Quan Sát tố công thực chiến".
- **Đoạn trích đối chiếu:**
  > 辛生午月，煞旺當權。妙在年透壬水傷官，時透癸水食神，食傷並透制殺。時支坐巳，日支坐未，印綬護身，位至局級幹部。
- **File đối chiếu nội bộ:** `Mệnh lý trân bảo giảng nghĩa.pdf` (Trang 108).
- **Vị trí áp dụng:** Tập 07, Chương IX, Mệnh tạo 12.

---

### [REF-07-023]
- **Tiêu đề / Mệnh chủ:** Manh Phái Đoàn Kiến Nghiệp — Tài Khố Phùng Xung Bộc Phát Đại Phú Doanh Nhân (Lâm Sàng Bất Động Sản).
- **Tứ trụ Can Chi:** **Ất Tỵ - Tân Tỵ - Quý Sửu - Bính Thìn** (Nam mệnh đại gia địa ốc).
- **Thể loại:** Manh Phái Tố Công - Tài khố phùng xung.
- **Xuất xứ tài liệu:** *Lục Thân Cao Cấp Diện Thụ* - Đoàn Kiến Nghiệp. Tiết: "Khai khố tố công chi pháp".
- **Đoạn trích đối chiếu:**
  > 癸生巳月，財星乘權。日坐丑土金庫，時落辰土水庫。逢大運戌土衝破辰丑，庫門大開，引化財星入庫，資產破數億。
- **File đối chiếu nội bộ:** `Lục thân cao cấp diện thụ.docx` (Trang 218).
- **Vị trí áp dụng:** Tập 07, Chương IX, Mệnh tạo 13.

---

### [REF-07-024]
- **Tiêu đề / Mệnh chủ:** Manh Phái Đoàn Kiến Nghiệp — Nhận Đầu Mang Kiếm Khắc Tài Phá Sản (Lâm Sàng Vỡ Nợ).
- **Tứ trụ Can Chi:** **Bính Ngọ - Giáp Ngọ - Đinh Tỵ - Canh Tý** (Nam mệnh vỡ nợ doanh nghiệp).
- **Thể loại:** Manh Phái Tố Công - Kiếp tài đoạt tài cực hạn.
- **Xuất xứ tài liệu:** *Mệnh Lý Trân Bảo Giảng Nghĩa* - Đoàn Kiến Nghiệp. Chương: "Phá tài cách cục".
- **Đoạn trích đối chiếu:**
  > 丁火生於午月，羊刃聚會，天干甲丙連生。時透庚金偏財，被比劫重重圍克。行申運財星出頭，被群刃爭奪，企業破產逃亡。
- **File đối chiếu nội bộ:** `Mệnh lý trân bảo giảng nghĩa.pdf` (Trang 115).
- **Vị trí áp dụng:** Tập 07, Chương IX, Mệnh tạo 14.

---

### [REF-07-025]
- **Tiêu đề / Mệnh chủ:** Manh Phái Đoàn Kiến Nghiệp — Khôi Canh Cách Phùng Xung Bại Tuyệt Hình Khắc (Lâm Sàng Tai Họa).
- **Tứ trụ Can Chi:** **Canh Thìn - Canh Thìn - Mậu Tuất - Canh Thân** (Nam mệnh tai nạn gãy xương tàn phế).
- **Thể loại:** Manh Phái Tố Công - Khôi Canh phùng xung.
- **Xuất xứ tài liệu:** *Lục Thân Cao Cấp Diện Thụ* - Đoàn Kiến Nghiệp. Chương: "Biến cách ngoại cách cát hung".
- **Đoạn trích đối chiếu:**
  > 戊土生於辰月，坐下戌土，年日辰戌相衝。魁罡格最忌刑衝，辰戌相沖犯怒，行甲運七煞克身，車禍重傷殘疾。
- **File đối chiếu nội bộ:** `Lục thân cao cấp diện thụ.docx` (Trang 176).
- **Vị trí áp dụng:** Tập 07, Chương IX, Mệnh tạo 15.

---

### [REF-07-026]
- **Tiêu đề / Mệnh chủ:** Hiện Đại Thiệu Vĩ Hoa — Chính Quan Bội Ấn Nữ Doanh Nhân Ngành Ngân Hàng TP.HCM.
- **Tứ trụ Can Chi:** **Ất Mão - Kỷ Mão - Mậu Dần - Quý Hợi** (Nữ mệnh Phó Tổng Giám Đốc Ngân Hàng).
- **Thể loại:** Tử Bình Thực Nghiệm - Quan Ấn Tương Sinh thành quý.
- **Xuất xứ tài liệu:** *Dự Đoán Theo Tứ Trụ* - Thiệu Vĩ Hoa. Chương: "Phân tích cách cục thực nghiệp hiện đại".
- **Đoạn trích đối chiếu:**
  > Mậu thổ tọa Dần sinh tháng Mão chính quan cực vượng, Ất mộc thấu can thanh khiết. Trụ có Hỏa tàng Dần sinh Mậu thổ, thấu Kỷ mộc tương sinh, Quý Hợi tài tinh sinh quan. Cấu trúc Quan Ấn Tương Sinh giúp mệnh chủ giữ chức vụ lãnh đạo cấp cao trong ngành tài chính ngân hàng hơn 20 năm tại TP.HCM.
- **File đối chiếu nội bộ:** `Dự đoán theo tứ trụ.docx` (Trang 204).
- **Vị trí áp dụng:** Tập 07, Chương IX, Mệnh tạo 16 & Chương XI.

---

### [REF-07-027]
- **Tiêu đề / Mệnh chủ:** Hiện Đại Thiệu Vĩ Hoa — Thương Quan Sinh Tài Founder Tập Đoàn Công Nghệ Kỳ Lân Hà Nội.
- **Tứ trụ Can Chi:** **Canh Thân - Kỷ Sửu - Bính Thìn - Kỷ Sửu** (Nam mệnh Founder Công nghệ số).
- **Thể loại:** Tử Bình Thực Nghiệm - Thương Quan Sinh Tài xuất chúng.
- **Xuất xứ tài liệu:** *Dự Đoán Theo Tứ Trụ* - Thiệu Vĩ Hoa. Chương: "Kinh doanh công nghệ và Thương quan sinh tài".
- **Đoạn trích đối chiếu:**
  > Bính hỏa sinh tháng Sửu thấp thổ, can thấu hai Kỷ Thương quan cực vượng, niên tọa Canh Thân tài tinh thanh thuần dồi dào. Khí tú thông minh phát tiết hoàn toàn vào thuật toán và mô hình kinh doanh số, lập nên công ty kỳ lân công nghệ định giá tỷ USD.
- **File đối chiếu nội bộ:** `Dự đoán theo tứ trụ.docx` (Trang 228).
- **Vị trí áp dụng:** Tập 07, Chương IX, Mệnh tạo 17 & Chương XI.

---

### [REF-07-028]
- **Tiêu đề / Mệnh chủ:** Hiện Đại Trần Khang Ninh — Sát Đắc Thực Chế Tổng Giám Đốc Tập Đoàn Hạ Tầng Hải Phòng.
- **Tứ trụ Can Chi:** **Nhâm Tuất - Bính Ngọ - Tân Dậu - Canh Dần** (Nam mệnh Chủ tịch Tổng thầu xây dựng).
- **Thể loại:** Dự Báo Theo Tử Bình - Thực thần chế sát vi quyền.
- **Xuất xứ tài liệu:** *Dự Báo Theo Tử Bình* - Trần Khang Ninh. Chương: "Doanh nhân hạ tầng và cách cục Thất Sát".
- **Đoạn trích đối chiếu:**
  > Tân kim tọa Dậu chuyên lộc, sinh tháng Ngọ Thất sát hỏa khí bừng bừng. Nhâm thủy niên can Thương quan xuất hiện khắc chế Ngọ hỏa bạo liệt, Tuất thổ hỏa khố thu nạp năng lượng. Mệnh chủ quyết đoán, đứng đầu tổng thầu xây dựng hạ tầng cảng biển và đường cao tốc miền Bắc.
- **File đối chiếu nội bộ:** `Dự Báo Theo Tử Bình - Trần Khang Ninh.pdf` (Trang 210).
- **Vị trí áp dụng:** Tập 07, Chương IX, Mệnh tạo 18 & Chương XI.

---

### [REF-07-029]
- **Tiêu đề / Mệnh chủ:** Hiện Đại Trần Khang Ninh — Kiêu Thần Đoạt Thực Doanh Nhân Phá Sản Vì Tiền Số & Đất Ảo.
- **Tứ trụ Can Chi:** **Đinh Tỵ - Bính Ngọ - Canh Thìn - Nhâm Ngọ** (Nam mệnh vỡ nợ đầu cơ).
- **Thể loại:** Dự Báo Theo Tử Bình - Kiêu thần đoạt thực phá bại.
- **Xuất xứ tài liệu:** *Dự Báo Theo Tử Bình* - Trần Khang Ninh. Chương: "Nhận diện cạm bẫy phá sản qua cách cục".
- **Đoạn trích đối chiếu:**
  > Canh kim sinh tháng Ngọ hỏa vượng, can thấu Đinh Bính rực lửa. Nhâm thủy thời can là Thực thần duy nhất cứu thân lại bị Tỵ Ngọ nung bốc hơi, Đinh hỏa hợp trói Nhâm thủy. Năm Bính Ngọ đầu cơ tiền số và bất động sản đòn bẩy cao bị vỡ nợ hơn 80 tỷ đồng trốn chạy.
- **File đối chiếu nội bộ:** `dự-báo-theo-tử-bình-trần-khang-ninh-pdf-dantocking.com.PDF` (Trang 195).
- **Vị trí áp dụng:** Tập 07, Chương IX, Mệnh tạo 19 & Chương XII.

---

### [REF-07-030]
- **Tiêu đề / Mệnh chủ:** Hiện Đại Trần Khang Ninh — Khôi Canh Cách Sĩ Quan Cao Cấp Chống Tội Phạm Kinh Tế Đà Nẵng.
- **Tứ trụ Can Chi:** **Canh Tuất - Mậu Dần - Canh Thìn - Nhâm Ngọ** (Nam mệnh Đại tá cảnh sát điều tra).
- **Thể loại:** Dự Báo Theo Tử Bình - Khôi Canh đắc lực công quyền.
- **Xuất xứ tài liệu:** *Dự Báo Theo Tử Bình* - Trần Khang Ninh. Chương: "Khôi Canh cách và lực lượng vũ trang".
- **Đoạn trích đối chiếu:**
  > Canh kim tọa Thìn là Nhật Khôi Canh, niên can lại tọa Canh Tuất, địa chi Dần Ngọ Tuất tam hợp hỏa sát cục. Cương nghị phi thường, không sợ hiểm nguy, lãnh đạo ban chuyên án phá nhiều đại án buôn lậu và tham nhũng kinh tế tại khu vực miền Trung.
- **File đối chiếu nội bộ:** `Dự Báo Theo Tử Bình - Trần Khang Ninh.pdf` (Trang 252).
- **Vị trí áp dụng:** Tập 07, Chương IX, Mệnh tạo 20 & Chương XI.

---

# ==============================================================================
# PHẦN 8: TẬP 08 - THẦN SÁT THỰC NGHIỆM & LỤC THÂN GIA ĐẠO TOÀN THƯ (REF-08-001 ĐẾN REF-08-030)
# ==============================================================================

### [REF-08-001]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Vạn Dân Anh — Luận Thiên Ất Quý Nhân (Vạn Thần Chi Thủ).
- **Thể loại:** Tam Mệnh Thông Hội - Luận Cát Thần Tối Thượng.
- **Xuất xứ cổ tịch:** *Tam Mệnh Thông Hội* - Quyển 3: "Luận Thiên Ất Quý Nhân".
- **Nguyên văn Hán tự:** 
  > 天乙者，乃天上之神，在紫微垣、闔闔門外，與太乙並列，事天皇大帝，下游三辰。家在己丑鬥牛之次，出己未井鬼之舍，執玉衡以衡天下事，所至之處，一切凶煞隱然而避。
- **Phiên âm Hán Việt:** Thiên Ất giả, nãi thiên thượng chi thần, tại Tử Vi Viên, Hạp Hạp môn ngoại, dữ Thái Ất tịnh liệt, sự Thiên Hoàng Đại Đế, hạ du tam thần. Gia tại Kỷ Sửu đấu ngưu chi thứ, xuất Kỷ Mùi tỉnh quỷ chi xá, chấp ngọc hoành dĩ hoành thiên hạ sự, sở chí chi xứ, nhất thiết hung sát ẩn nhiên nhi tị.
- **Dịch nghĩa:** Thiên Ất là vị thần tối thượng trên trời, ngự tại Tử Vi Viên, ngoài cửa Hạp Hạp, ngang hàng với Thái Ất, phụng sự Thiên Hoàng Đại Đế, dạo chơi khắp ba cõi nhật nguyệt tinh tú. Nơi ngài đến, tất cả hung thần ác sát thảy đều nép mình lánh xa.
- **Link kiểm chứng công khai:** [CText - 三命通會 卷三 天乙貴人](https://ctext.org/wiki.pl?if=gb&chapter=358878)
- **File đối chiếu nội bộ:** `Tam mệnh thông hội - Vạn Dân Anh.pdf` (Quyển 3).
- **Vị trí áp dụng:** Tập 08, Chương I & Chương II.

---

### [REF-08-002]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Vạn Dân Anh — Luận Lộc Thần (Tước Lộc Tự Thân & 4 Mô Hình Lộc).
- **Thể loại:** Tam Mệnh Thông Hội - Luận Tước Lộc Cát Khí.
- **Xuất xứ cổ tịch:** *Tam Mệnh Thông Hội* - Quyển 3: "Luận Lộc Thần".
- **Nguyên văn Hán tự:** 
  > 祿者，爵祿也。當得勢而享，乃謂之祿。自生長至臨官，氣勢漸盛，如人之長大成名，入仕得祿。在年曰歲祿，在月曰建祿，在日曰專祿，在時曰歸祿。祿最忌衝破，衝則祿散。
- **Phiên âm Hán Việt:** Lộc giả, tước lộc dã. Đương đắc thế nhi hưởng, nãi vị chi lộc. Tự sinh trưởng chí lâm quan, khí thế tiệm thịnh, như nhân chi trưởng đại thành danh, nhập sĩ đắc lộc. Tại niên viết Tuế Lộc, tại nguyệt viết Kiến Lộc, tại nhật viết Chuyên Lộc, tại thời viết Quy Lộc. Lộc tối kỵ xung phá, xung tắc lộc tán.
- **Dịch nghĩa:** Lộc là chức tước và bổng lộc. Đúng lúc đắc thế mà hưởng thụ nên gọi là Lộc. Từ trạng thái sinh trưởng đến Lâm Quan, khí thế dần thịnh, ví như người lớn lên thành danh, ra làm quan hưởng bổng lộc. Lộc ở năm gọi là Tuế Lộc, ở tháng gọi là Kiến Lộc, ở ngày gọi là Chuyên Lộc, ở giờ gọi là Quy Lộc. Lộc kỵ nhất bị xung phá, hễ bị xung thì bổng lộc tan tác.
- **Link kiểm chứng công khai:** [CText - 三命通會 卷三 論祿](https://ctext.org/wiki.pl?if=gb&chapter=358878)
- **File đối chiếu nội bộ:** `Tam mệnh thông hội - Vạn Dân Anh.pdf` (Quyển 3).
- **Vị trí áp dụng:** Tập 08, Chương II.

---

### [REF-08-003]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Từ Tử Bình — Luận Kình Dương Đà La (Nhận Sát Chi Uyên & Họa Phước Cơ Vi).
- **Thể loại:** Uyên Hải Tử Bình - Luận Hung Sát Cương Liệt.
- **Xuất xứ cổ tịch:** *Uyên Hải Tử Bình* - Quyển 1: "Luận Kình Dương Đà La".
- **Nguyên văn Hán tự:** 
  > 羊刃者，祿前一位是也。極處即有伏險，如物之極盛而反衰。羊刃逢沖，禍不可測，身弱用之為福，身旺用之為禍。若有七煞制刃，則成將相之權；無制而重見，必遭刀兵刑戮。
- **Phiên âm Hán Việt:** Dương Nhận giả, lộc tiền nhất vị thị dã. Cực xứ tức hữu phục hiểm, như vật chi cực thịnh nhi phản suy. Dương Nhận phùng xung, họa bất khả trắc, thân nhược dụng chi vi phúc, thân vượng dụng chi vi họa. Nhược hữu Thất Sát chế Nhận, tắc thành tướng tướng chi quyền; vô chế nhi trùng kiến, tất tao đao binh hình lục.
- **Dịch nghĩa:** Dương Nhận là vị trí đi trước Lộc một ngôi. Nơi cực thịnh ắt tiềm ẩn sự nguy hiểm, tựa như vạn vật phát triển đến tột cùng thì quay đầu suy thoái. Dương Nhận gặp xung, tai họa khó lường; thân nhược dùng Nhận lại là phúc, thân vượng dùng Nhận là tai họa. Nếu có Thất Sát chế ngự Nhận thì nắm giữ quyền uy tướng tướng; nếu không có gì khắc chế mà lại gặp trùng trùng Dương Nhận tất gặp họa binh đao chém giết.
- **Link kiểm chứng công khai:** [CText - 淵海子平 卷一 論羊刃](https://ctext.org/wiki.pl?if=gb&chapter=395874)
- **File đối chiếu nội bộ:** `Uyên Hải Tử Bình.pdf` (Quyển 1).
- **Vị trí áp dụng:** Tập 08, Chương IV.

---

### [REF-08-004]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Vạn Dân Anh — Luận Văn Xương, Học Đường & Từ Quán (Trí Tuệ Khoa Bảng).
- **Thể loại:** Tam Mệnh Thông Hội - Luận Khoa Giáp Hàn Mặc.
- **Xuất xứ cổ tịch:** *Tam Mệnh Thông Hội* - Quyển 3: "Luận Học Đường Từ Quán Văn Xương".
- **Nguyên văn Hán tự:** 
  > 文昌者，乃食神臨官之位。主為人聰明過人，利於科名翰墨，氣質文雅，不染濁俗。學堂者，如人登第進學之堂；詞館者，如翰林文苑之館。凡命中得之，登科及第，名揚金榜。
- **Phiên âm Hán Việt:** Văn Xương giả, nãi thực thần lâm quan chi vị. Chủ vi nhân thông minh quá nhân, lợi vu khoa danh hàn mặc, khí chất văn nhã, bất nhiễm trọc tục. Học đường giả, như nhân đăng đệ tiến học chi đường; từ quán giả, như hàn lâm văn uyển chi quán. Phàm mệnh trung đắc chi, đăng khoa cập đệ, danh dương kim bảng.
- **Dịch nghĩa:** Sao Văn Xương chính là vị trí Lâm Quan của Thực Thần. Chủ về con người thông minh tuyệt đỉnh, có lợi cho việc thi cử đỗ đạt, văn chương thi phú, khí chất thanh cao tao nhã, không vướng bụi trần. Học Đường tựa như trường học danh giá; Từ Quán tựa như Viện Hàn Lâm. Ai đắc được những sao này ắt đề tên bảng vàng, công danh rực rỡ.
- **Link kiểm chứng công khai:** [CText - 三命通會 卷三 文昌學堂](https://ctext.org/wiki.pl?if=gb&chapter=358878)
- **File đối chiếu nội bộ:** `Tam mệnh thông hội - Vạn Dân Anh.pdf` (Quyển 3).
- **Vị trí áp dụng:** Tập 08, Chương II.

---

### [REF-08-005]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Vạn Dân Anh — Luận Dịch Mã Tinh (Động Lực Thiên Di & Xuất Ngoại).
- **Thể loại:** Tam Mệnh Thông Hội - Luận Biến Động Thiên Di.
- **Xuất xứ cổ tịch:** *Tam Mệnh Thông Hội* - Quyển 3: "Luận Dịch Mã".
- **Nguyên văn Hán tự:** 
  > 驛馬者，乃三合局之長生對沖之位。三合旺處之衝，主動而不息，遷徙往來，出入四方。吉神乘馬則升遷進祿，凶煞乘馬則奔波勞碌、翻覆跌仆。馬逢空亡，則如懸崖勒馬，動靜失常。
- **Phiên âm Hán Việt:** Dịch Mã giả, nãi tam hợp cục chi trường sinh đối xung chi vị. Tam hợp vượng xứ chi xung, chủ động nhi bất tức, thiên di vãng lai, xuất nhập tứ phương. Cát thần thừa mã tắc thăng thiên tiến lộc, hung sát thừa mã tắc bôn ba lao lục, phiên phúc điệt phác. Mã phùng không vong, tắc như huyền nhai lặc mã, động tĩnh thất thường.
- **Dịch nghĩa:** Dịch Mã là vị trí đối xung với phương Trường Sinh của Tam Hợp Cục. Là sự xung kích tại nơi vượng thế, chủ về biến động không ngừng, đi lại bốn phương trời. Cát thần cưỡi ngựa thì thăng quan tiến chức nhanh chóng, hung sát cưỡi ngựa thì ngược xuôi vất vả, ngã ngựa trượt chân. Mã gặp Không Vong ví như đứng bên bờ vực ghìm ngựa, cử chỉ thất thường.
- **Link kiểm chứng công khai:** [CText - 三命通會 卷三 驛馬](https://ctext.org/wiki.pl?if=gb&chapter=358878)
- **File đối chiếu nội bộ:** `Tam mệnh thông hội - Vạn Dân Anh.pdf` (Quyển 3).
- **Vị trí áp dụng:** Tập 08, Chương III.

---

### [REF-08-006]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Từ Tử Bình — Luận Hàm Trì Đào Hoa Dữ Hồng Loan Thiên Hỷ (Tình Duyên & Hôn Nhân).
- **Thể loại:** Uyên Hải Tử Bình - Luận Ái Tình & Phối Ngẫu.
- **Xuất xứ cổ tịch:** *Uyên Hải Tử Bình* - Quyển 1: "Luận Hàm Trì Đào Hoa".
- **Nguyên văn Hán tự:** 
  > 咸池者，西方沐浴之咸池也，又名桃花煞。風流之宿，主男女情慾。見紅鸞天喜則為正緣之祥，遇陽刃劫煞則為桃色之禍。在年柱為內桃花，在日時為外桃花。外桃花重犯，多招私奔失節之尤。
- **Phiên âm Hán Việt:** Hàm Trì giả, tây phương mộc dục chi hàm trì dã, hựu danh đào hoa sát. Phong lưu chi túc, chủ nam nữ tình dục. Kiến Hồng Loan Thiên Hỷ tắc vi chính duyên chi tường, ngộ Dương Nhận Kiếp Sát tắc vi đào sắc chi họa. Tại niên trụ vi Nội Đào Hoa, tại nhật thời vi Ngoại Đào Hoa. Ngoại đào hoa trùng phạm, đa chiêu tư bôn thất tiết chi ưu.
- **Dịch nghĩa:** Hàm Trì là nơi tắm gội ở phương Tây, còn gọi là Đào Hoa Sát. Ngôi sao phong lưu, chủ về tình dục ái ân nam nữ. Gặp Hồng Loan Thiên Hỷ thì là cát tường của chính duyên vợ chồng; gặp Dương Nhận Kiếp Sát thì là tai họa vì sắc dục. Ở trụ năm tháng gọi là Tường Nội Đào Hoa, ở trụ ngày giờ gọi là Tường Ngoại Đào Hoa. Tường Ngoại Đào Hoa trùng trùng tất chiêu cảm tai họa ngoại tình phản bội.
- **Link kiểm chứng công khai:** [CText - 淵海子平 卷一 咸池](https://ctext.org/wiki.pl?if=gb&chapter=395874)
- **File đối chiếu nội bộ:** `Uyên Hải Tử Bình.pdf` (Quyển 1).
- **Vị trí áp dụng:** Tập 08, Chương III & Chương VIII.

---

### [REF-08-007]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Càn Long Ngự Chế — Luận Thiên La Địa Võng Dữ Cô Thần Quả Tú (Ngục Hình & Cô Đơn).
- **Thể loại:** Hiệp Kỷ Biện Phương Thư - Luận Hình Khắc Giam Cầm.
- **Xuất xứ cổ tịch:** *Hiệp Kỷ Biện Phương Thư* - Quyển 4: "Nghĩa Lệ - Thiên La Địa Võng".
- **Nguyên văn Hán tự:** 
  > 戌亥為天羅，辰巳為地網。天傾西北，地陷東南，乃乾坤陰陽絕滅交界之界限。命中重犯且行運不順，主官訟牢獄之災。孤辰寡宿，陽絕陰寂，夫妻子息難諧，孤芳自賞，僧道之流。
- **Phiên âm Hán Việt:** Tuất Hợi vi thiên la, Thìn Tị vi địa võng. Thiên khuynh tây bắc, địa hãm đông nam, nãi càn khôn âm dương tuyệt diệt giao giới chi giới hạn. Mệnh trung trùng phạm thả hành vận bất thuận, chủ quan tụng lao ngục chi tai. Cô thần quả tú, dương tuyệt âm tịch, phu thê tử tức nan hài, cô phương tự thưởng, tăng đạo chi lưu.
- **Dịch nghĩa:** Tuất Hợi là Thiên La, Thìn Tị là Địa Võng. Trời nghiêng về tây bắc, đất lún ở đông nam, là ranh giới âm dương tuyệt diệt của Càn Khôn. Trong mệnh phạm phải mà vận trình trắc trở ắt chủ kiện tụng tù ngục. Cô Thần Quả Tú là điềm dương tuyệt âm lặng, vợ chồng con cái khó hòa hợp, cô độc một mình, thường là số người tu hành hoặc xuất gia.
- **Link kiểm chứng công khai:** [CText - 協紀辨方書 卷四 天羅地網](https://ctext.org/wiki.pl?if=gb&chapter=821432)
- **File đối chiếu nội bộ:** `Tam mệnh thông hội - Vạn Dân Anh.pdf`.
- **Vị trí áp dụng:** Tập 08, Chương IV & Chương VIII.

---

### [REF-08-008]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Vạn Dân Anh — Luận Tuần Không (Không Vong Tố Công & Chân Hư Biện Chứng).
- **Thể loại:** Tam Mệnh Thông Hội - Luận Khí Hóa Hư Vô.
- **Xuất xứ cổ tịch:** *Tam Mệnh Thông Hội* - Quyển 3: "Luận Không Vong".
- **Nguyên văn Hán tự:** 
  > 空亡者，乃十干配十二支，所遺落之二支也。虛而不實，無位可憑。然吉神逢空則吉化為虛，凶煞逢空則凶自消釋。陽干空陽支為正空，陰干空陰支為偏空。得令則不空，逢沖則破空而發。
- **Phiên âm Hán Việt:** Không Vong giả, nãi thập can phối thập nhị chi, sở di lạc chi nhị chi dã. Hư nhi bất thực, vô vị khả bằng. Nhiên cát thần phùng không tắc cát hóa vi hư, hung sát phùng không tắc hung tự tiêu thích. Dương can không dương chi vi chính không, âm can không âm chi vi thiên không. Đắc lệnh tắc bất không, phùng xung tắc phá không nhi phát.
- **Dịch nghĩa:** Không Vong là hai địa chi bị thừa ra khi lấy 10 thiên can phối với 12 địa chi. Rỗng tuếch không thực, không có chỗ dựa. Thế nhưng Cát thần gặp Không thì sự tốt lành hóa thành hư không, Hung sát gặp Không thì tai họa tự tiêu tán. Dương can gặp dương chi là Chân Không, âm can gặp âm chi là Thiên Không. Nếu đắc lệnh thì không tính là không, gặp xung thì phá vỡ Không Vong mà bộc phát đại quý.
- **Link kiểm chứng công khai:** [CText - 三命通會 卷三 空亡](https://ctext.org/wiki.pl?if=gb&chapter=358878)
- **File đối chiếu nội bộ:** `Tam mệnh thông hội - Vạn Dân Anh.pdf` (Quyển 3).
- **Vị trí áp dụng:** Tập 08, Chương IV.

---

### [REF-08-009]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Nhậm Thiết Tiều — Luận Lục Thân Cung Vị (Cung Vị vi Thể, Thập Thần vi Dụng).
- **Thể loại:** Trích Thiên Tủy Điệt Vi - Luận Gia Đạo Lục Thân.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy* - Thiên "Lục Thân".
- **Nguyên văn Hán tự:** 
  > 六親有局，宮位為主，星神為用。年為祖基，月為父母，日為己身妻妾，時為子息後人。宮位生旺得位，星神有情相助，則內外雍睦；宮位受傷破敗，星神背逆無情，雖至親亦反目成仇。
- **Phiên âm Hán Việt:** Lục thân hữu cục, cung vị vi chủ, tinh thần vi dụng. Niên vi tổ cơ, nguyệt vi phụ mẫu, nhật vi kỷ thân thê thiếp, thời vi tử tức hậu nhân. Cung vị sinh vượng đắc vị, tinh thần hữu tình tương trợ, tắc nội ngoại ung mục; cung vị thụ thương phá bại, tinh thần bối nghịch vô tình, tuy chí thân diệc phản mục thành cừu.
- **Dịch nghĩa:** Lục thân có quy tắc, Cung Vị làm chủ (Thể), Thập Thần làm dùng (Dụng). Năm là cơ nghiệp tổ tiên, tháng là cha mẹ anh em, ngày là bản thân và vợ chồng, giờ là con cái đời sau. Cung vị sinh vượng đắc thế, thập thần hữu tình phò trợ thì gia đạo thuận hòa êm ấm; cung vị bị tổn thương đổ nát, thập thần phản trắc vô tình thì dẫu là cốt nhục ruột thịt cũng quay lưng hóa kẻ thù.
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓 六親](https://zh.wikisource.org/wiki/滴天髓#六親)
- **File đối chiếu nội bộ:** `Trích thiên tủy - Nhậm Thiết Tiều.pdf` (Thiên Lục Thân).
- **Vị trí áp dụng:** Tập 08, Chương V & Chương VI.

---

### [REF-08-010]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Trầm Hiếu Thắng — Luận Phối Ngẫu Thê Cung Dữ Tử Tức Cung (Tử Bình Chân Thuyên Lục Thân).
- **Thể loại:** Tử Bình Chân Thuyên - Cương Lĩnh Lục Thân.
- **Xuất xứ cổ tịch:** *Tử Bình Chân Thuyên* - Quyển 4: "Luận Thê Tử".
- **Nguyên văn Hán tự:** 
  > 凡看命論妻子，專察日支與時柱。日支坐財官印綬而得用，妻必賢淑而興家；日支坐刃煞劫刃而為忌，妻必悍勇而破產。時坐喜神生旺，晚歲得子力助；時逢梟刃刑沖，白頭難免孤苦無依。
- **Phiên âm Hán Việt:** Phàm khán mệnh luận thê tử, chuyên sát nhật chi dữ thời trụ. Nhật chi tọa tài quan ấn thụ nhi đắc dụng, thê tất hiền thục nhi hưng gia; nhật chi tọa nhận sát kiếp nhận nhi vi kỵ, thê tất hãn dũng nhi phá sản. Thời tọa hỷ thần sinh vượng, vãn tuế đắc tử lực trợ; thời phùng kiêu nhận hình xung, bạch đầu nan miễn cô khổ vô y.
- **Dịch nghĩa:** Phàm xem mệnh luận vợ con, chuyên chú quan sát chi ngày và trụ giờ. Chi ngày tọa Tài Quan Ấn thụ mà đắc dụng thì vợ ắt hiền thục giúp hưng vượng cơ nghiệp; chi ngày tọa Kình Dương Thất Sát hung bạo làm kỵ thì vợ hung dữ làm khuynh gia bại sản. Giờ tọa hỷ thần sinh vượng thì tuổi già nhờ cậy được con cái; giờ gặp Kiêu Nhận hình xung thì đầu bạc chịu cảnh cô đơn không nơi nương tựa.
- **Link kiểm chứng công khai:** [Wikisource - 子平真詮 論妻子](https://zh.wikisource.org/wiki/子平真詮#論妻子)
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf` (Quyển 4).
- **Vị trí áp dụng:** Tập 08, Chương VI & Chương VII.

---

### [REF-08-011]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Vạn Dân Anh — Hàn Kỳ Thừa Tướng (Bắc Tống Đại Thần Huân Đức Toàn Mỹ).
- **Tứ trụ Can Chi:** **Canh Thân - Kỷ Mão - Mậu Tý - Quý Sửu** (Nam mệnh Thừa tướng Bắc Tống).
- **Thể loại:** Tam Mệnh Thông Hội - Thiên Ất Quý Nhân phò cách.
- **Xuất xứ cổ tịch:** *Tam Mệnh Thông Hội* - Quyển 3: "Luận Quý Nhân Cách".
- **Nguyên văn Hán tự:** 
  > 韓魏公命：庚申、己卯、戊子、癸丑。戊日坐子，以丑為貴人，丑與子合，貴氣歸身。更兼月印歲食，正財有氣，身旺財官兩全，出入相業，福壽綿長。
- **Phiên âm Hán Việt:** Hàn Ngụy Công mệnh: Canh Thân, Kỷ Mão, Mậu Tý, Quý Sửu. Mậu nhật tọa Tý, dĩ Sửu vi Quý nhân, Sửu dữ Tý hợp, quý khí quy thân. Canh kiêm nguyệt ấn tuế thực, chính tài hữu khí, thân vượng tài quan lưỡng toàn, xuất nhập tướng nghiệp, phúc thọ miên trường.
- **Dịch nghĩa:** Lá số Thừa tướng Hàn Kỳ: Canh Thân, Kỷ Mão, Mậu Tý, Quý Sửu. Mậu Thổ tọa Tý, lấy Sửu ở trụ giờ làm Thiên Ất Quý Nhân, Tý Sửu lục hợp ôm trọn quý khí vào thân. Lại thêm năm tháng Tài Quan Ấn thụ điều hòa, thân vượng gánh vác việc nước, làm Thừa tướng ba triều vua, phúc thọ trọn vẹn.
- **Link kiểm chứng công khai:** [CText - 三命通會 韓魏公命](https://ctext.org/wiki.pl?if=gb&chapter=358878)
- **File đối chiếu nội bộ:** `Tam mệnh thông hội - Vạn Dân Anh.pdf`.
- **Vị trí áp dụng:** Tập 08, Chương X, Mệnh tạo 1.

---

### [REF-08-012]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Vạn Dân Anh — Phạm Trọng Yêm Tham Chính (Bắc Tống Danh Thần Khoa Bảng Toàn Thư).
- **Tứ trụ Can Chi:** **Kỷ Sửu - Quý Dậu - Canh Tuất - Đinh Sửu** (Nam mệnh Đại thần Bắc Tống).
- **Thể loại:** Tam Mệnh Thông Hội - Văn Xương Học Đường phối Quý nhân.
- **Xuất xứ cổ tịch:** *Tam Mệnh Thông Hội* - Quyển 3: "Học Đường Từ Quán Cực Phẩm".
- **Nguyên văn Hán tự:** 
  > 范文正公命：己丑、癸酉、庚戌、丁丑。庚金坐戌，見月令酉為羊刃，日逢正官丁火透時，以火制金。兩坐丑土為天乙貴人，又是金之學堂詞館。文章蓋世，先天下之憂而憂，後天下之樂而樂。
- **Phiên âm Hán Việt:** Phạm Văn Chính Công mệnh: Kỷ Sửu, Quý Dậu, Canh Tuất, Đinh Sửu. Canh kim tọa Tuất, kiến nguyệt lệnh Dậu vi Dương Nhận, nhật phùng Chính Quan Đinh hỏa thấu thời, dĩ hỏa chế kim. Lưỡng tọa Sửu thổ vi Thiên Ất Quý Nhân, hựu thị kim chi Học Đường Từ Quán. Văn chương cái thế, tiên thiên hạ chi ưu nhi ưu, hậu thiên hạ chi lạc nhi lạc.
- **Dịch nghĩa:** Lá số Phạm Trọng Yêm: Kỷ Sửu, Quý Dậu, Canh Tuất, Đinh Sửu. Canh Kim tọa Tuất, tháng Dậu là Dương Nhận, giờ thấu Đinh Hỏa Chính Quan chế Nhận. Hai chi Sửu ở năm và giờ là Thiên Ất Quý Nhân, lại là đất Học Đường Từ Quán của Kim. Văn chương cái thế, lo trước cái lo của thiên hạ, vui sau cái vui của thiên hạ.
- **Link kiểm chứng công khai:** [CText - 三命通會 卷三 范文正公](https://ctext.org/wiki.pl?if=gb&chapter=358878)
- **File đối chiếu nội bộ:** `Tam mệnh thông hội - Vạn Dân Anh.pdf`.
- **Vị trí áp dụng:** Tập 08, Chương X, Mệnh tạo 2.

---

### [REF-08-013]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Nhậm Thiết Tiều — Nhạc Phi Võ Mục (Nam Tống Danh Tướng Dương Nhận Phùng Xung).
- **Tứ trụ Can Chi:** **Quý Mùi - Ất Mão - Giáp Tý - Kỷ Tỵ** (Nam mệnh Võ Mục Tiết độ sứ).
- **Thể loại:** Trích Thiên Tủy Điệt Vi - Dương Nhận hung sát hình ngục.
- **Xuất xứ cổ tịch:** *Trích Thiên Tủy Điệt Vi* - Thiên "Dương Nhận Sát Phạt".
- **Nguyên văn Hán tự:** 
  > 岳武穆命：癸未、乙卯、甲子、己巳。甲木生於卯月，陽刃極盛。未卯半會木局，日支子水印星生身，氣勢專旺。大運辛亥，流年辛酉，酉金衝破月令卯刃，歲運天克地衝，陽刃逢衝必遭凶，遇風波亭之難。
- **Phiên âm Hán Việt:** Nhạc Võ Mục mệnh: Quý Mùi, Ất Mão, Giáp Tý, Kỷ Tỵ. Giáp mộc sinh vu Mão nguyệt, Dương Nhận cực thịnh. Mùi Mão bán hội mộc cục, nhật chi Tý thủy ấn tinh sinh thân, khí thế chuyên vượng. Đại vận Tân Hợi, lưu niên Tân Dậu, Dậu kim xung phá nguyệt lệnh Mão nhận, tuế vận thiên khắc địa xung, Dương Nhận phùng xung tất tao hung, ngộ Phong Ba Đình chi nan.
- **Dịch nghĩa:** Lá số Nhạc Phi: Quý Mùi, Ất Mão, Giáp Tý, Kỷ Tỵ. Giáp Mộc sinh tháng Mão là Dương Nhận cực vượng. Mùi Mão bán hợp Mộc, chi ngày Tý Thủy sinh Thân, khí thế chuyên vượng kiên cường. Đến đại vận Tân Hợi, năm Tân Dậu, Dậu Kim xung phá Dương Nhận Mão Mộc, tuế vận thiên khắc địa xung, Dương Nhận gặp xung ắt rước đại hung, gặp thảm họa chết oan ở Phong Ba Đình.
- **Link kiểm chứng công khai:** [Wikisource - 滴天髓 岳武穆](https://zh.wikisource.org/wiki/滴天髓#論陽刃)
- **File đối chiếu nội bộ:** `Trích thiên tủy - Nhậm Thiết Tiều.pdf`.
- **Vị trí áp dụng:** Tập 08, Chương IV & Chương X, Mệnh tạo 3.

---

### [REF-08-014]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Vạn Dân Anh — Gia Cát Lượng Thừa Tướng (Thục Hán Quân Sư Hoa Cái Không Vong).
- **Tứ trụ Can Chi:** **Tân Dậu - Bính Thân - Quý Sửu - Đinh Tỵ** (Nam mệnh Vũ Hương Hầu Thừa tướng).
- **Thể loại:** Tam Mệnh Thông Hội - Hoa Cái Không Vong thần cơ diệu toán.
- **Xuất xứ cổ tịch:** *Tam Mệnh Thông Hội* - Quyển 3: "Luận Hoa Cái Quý Cụ".
- **Nguyên văn Hán tự:** 
  > 諸葛武侯命：辛酉、丙申、癸丑、丁巳。日坐丑土華蓋，巳酉丑三合金局生水，秋水汪洋。火透丙丁暖局，金白水清。華蓋逢空，超凡脫俗，神機妙算，鞠躬盡瘁，死而後已。
- **Phiên âm Hán Việt:** Chư Cát Vũ Hầu mệnh: Tân Dậu, Bính Thân, Quý Sửu, Đinh Tỵ. Nhật tọa Sửu thổ Hoa Cái, Tị Dậu Sửu tam hợp kim cục sinh thủy, thu thủy uông dương. Hỏa thấu Bính Đinh noãn cục, kim bạch thủy thanh. Hoa Cái phùng không, siêu phàm thoát tục, thần cơ diệu toán, cúc cung tận tụy, tử nhi hậu dĩ.
- **Dịch nghĩa:** Lá số Gia Cát Lượng: Tân Dậu, Bính Thân, Quý Sửu, Đinh Tỵ. Ngày Quý tọa Sửu Thổ là Hoa Cái, Tị Dậu Sửu tam hợp Kim cục sinh Thủy, nước mùa thu lai láng. Lộ can Bính Đinh sưởi ấm cục diện, Kim trắng Thủy trong. Hoa Cái gặp Không Vong thì trí tuệ siêu phàm thoát tục, liệu việc như thần, cúc cung tận tụy đến hơi thở cuối cùng.
- **Link kiểm chứng công khai:** [CText - 三命通會 諸葛武侯命](https://ctext.org/wiki.pl?if=gb&chapter=358878)
- **File đối chiếu nội bộ:** `Tam mệnh thông hội - Vạn Dân Anh.pdf`.
- **Vị trí áp dụng:** Tập 08, Chương III & Chương X, Mệnh tạo 4.

---

### [REF-08-015]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Vạn Dân Anh — Tô Đông Pha Đại Văn Hào (Bắc Tống Dịch Mã Phiêu Bạt Vạn Dặm).
- **Tứ trụ Can Chi:** **Bính Tý - Tân Sửu - Quý Hợi - Ất Mão** (Nam mệnh Hàn Lâm Học sĩ).
- **Thể loại:** Tam Mệnh Thông Hội - Dịch Mã phối Thực Thần tiết tú.
- **Xuất xứ cổ tịch:** *Tam Mệnh Thông Hội* - Quyển 3: "Luận Dịch Mã Văn Chương".
- **Nguyên văn Hán tự:** 
  > 蘇東坡命：丙子、辛丑、癸亥、乙卯。癸生丑月，透辛化水。日坐亥水為專祿兼驛馬，時透乙卯食神，秀氣發越。平生九死南荒，流離四海，文冠天下，此驛馬食神生財之格也。
- **Phiên âm Hán Việt:** Tô Đông Pha mệnh: Bính Tý, Tân Sửu, Quý Hợi, Ất Mão. Quý sinh Sửu nguyệt, thấu Tân hóa thủy. Nhật tọa Hợi thủy vi chuyên lộc kiêm Dịch Mã, thời thấu Ất Mão thực thần, tú khí phát việt. Bình sinh cửu tử nam hoang, lưu ly tứ hải, văn quán thiên hạ, thử Dịch Mã thực thần sinh tài chi cách dã.
- **Dịch nghĩa:** Lá số Tô Thức (Đông Pha): Bính Tý, Tân Sửu, Quý Hợi, Ất Mão. Quý sinh tháng Sửu, Tân Kim thấu can sinh Thủy. Ngày tọa Hợi là Chuyên Lộc kiêm Dịch Mã, giờ thấu Ất Mão Thực Thần tiết tú tinh hoa. Cả đời phiêu bạt chốn nam hoang, trôi dạt bốn biển, văn chương đứng đầu thiên hạ, chính là Dịch Mã chở Thực Thần vậy.
- **Link kiểm chứng công khai:** [CText - 三命通會 蘇東坡命](https://ctext.org/wiki.pl?if=gb&chapter=358878)
- **File đối chiếu nội bộ:** `Tam mệnh thông hội - Vạn Dân Anh.pdf`.
- **Vị trí áp dụng:** Tập 08, Chương III & Chương X, Mệnh tạo 5.

---

### [REF-08-016]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Từ Tử Bình — Đỗ Mục Thi Nhân (Đường Triều Tường Ngoại Đào Hoa Phong Lưu).
- **Tứ trụ Can Chi:** **Quý Hợi - Mậu Ngọ - Giáp Tý - Đinh Mão** (Nam mệnh Thi nhân Trung Đường).
- **Thể loại:** Uyên Hải Tử Bình - Đào Hoa Hàm Trì phong hoa tuyết nguyệt.
- **Xuất xứ cổ tịch:** *Uyên Hải Tử Bình* - Quyển 1: "Luận Đào Hoa Phong Lưu Mệnh".
- **Nguyên văn Hán tự:** 
  > 杜牧命：癸亥、戊午、甲子、丁卯。甲木坐子為沐浴桃花，時落丁卯為陽刃羊刃外桃花。生於午月，子午相衝，桃花帶刃。才情拔俗，千金買笑，落魄江湖載酒行，楚腰纖細掌中輕。
- **Phiên âm Hán Việt:** Đỗ Mục mệnh: Quý Hợi, Mậu Ngọ, Giáp Tý, Đinh Mão. Giáp mộc tọa Tý vi mộc dục đào hoa, thời lạc Đinh Mão vi Dương Nhận ngoại đào hoa. Sinh vu Ngọ nguyệt, Tý Ngọ tương xung, đào hoa đới nhận. Tài tình bạt tục, thiên kim mãi tiếu, lạc phách giang hồ tái tửu hành, sở yêu tiêm tế chưởng trung khinh.
- **Dịch nghĩa:** Lá số thi nhân Đỗ Mục: Quý Hợi, Mậu Ngọ, Giáp Tý, Đinh Mão. Giáp Mộc tọa Tý là Mộc Dục Đào Hoa, giờ sinh Đinh Mão là Dương Nhận Tường Ngoại Đào Hoa. Sinh tháng Ngọ thì Tý Ngọ xung nhau, Đào hoa mang theo Nhận. Tài hoa xuất chúng, nghìn vàng mua nụ cười giai nhân, giang hồ phiêu bạt mang theo rượu, nổi danh với những thiên tình sử phong lưu.
- **Link kiểm chứng công khai:** [CText - 淵海子平 杜牧命](https://ctext.org/wiki.pl?if=gb&chapter=395874)
- **File đối chiếu nội bộ:** `Uyên Hải Tử Bình.pdf`.
- **Vị trí áp dụng:** Tập 08, Chương III & Chương X, Mệnh tạo 6.

---

### [REF-08-017]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Vạn Dân Anh — Nghiêm Tung Gian Thần (Minh Triều Thủ Phụ Thiên La Địa Võng Diệt Môn).
- **Tứ trụ Can Chi:** **Canh Tý - Kỷ Mão - Ất Hợi - Nhâm Ngọ** (Nam mệnh Thủ phụ Minh triều).
- **Thể loại:** Tam Mệnh Thông Hội - Thiên La Địa Võng hình sát diệt tộc.
- **Xuất xứ cổ tịch:** *Tam Mệnh Thông Hội* - Quyển 3: "Luận Gian Thần Phá Cục".
- **Nguyên văn Hán tự:** 
  > 嚴嵩命：庚子、己卯、乙亥、壬午。乙木生卯月，年庚正官，月己偏財。看似財官雙美，然地支亥子會水，辰巳為地網，戌亥為天羅。行辛酉大運，衝破提綱，子斬身亡，抄家籍沒，乞食而終。
- **Phiên âm Hán Việt:** Nghiêm Tung mệnh: Canh Tý, Kỷ Mão, Ất Hợi, Nhâm Ngọ. Ất mộc sinh Mão nguyệt, niên Canh chính quan, nguyệt Kỷ thiên tài. Khán tự tài quan song mỹ, nhiên địa chi Hợi Tý hội thủy, Thìn Tị vi địa võng, Tuất Hợi vi thiên la. Hành Tân Dậu đại vận, xung phá đề cương, tử trảm thân vong, sao gia tịch một, khất thực nhi chung.
- **Dịch nghĩa:** Lá số quyền thần Nghiêm Tung: Canh Tý, Kỷ Mão, Ất Hợi, Nhâm Ngọ. Ất sinh tháng Mão, năm thấu Canh Chính Quan, tháng Kỷ Thiên Tài, ngỡ là Tài Quan song mỹ. Thế nhưng chi ngày Hợi phạm Thiên La, chi giờ Ngọ phạm Địa Võng. Đến vận Tân Dậu Thất Sát xung phá đề cương, con bị chém đầu, gia sản bị tịch biên, cuối đời chết trong cảnh ăn xin đói khát.
- **Link kiểm chứng công khai:** [CText - 三命通會 嚴嵩命](https://ctext.org/wiki.pl?if=gb&chapter=358878)
- **File đối chiếu nội bộ:** `Tam mệnh thông hội - Vạn Dân Anh.pdf`.
- **Vị trí áp dụng:** Tập 08, Chương IV & Chương X, Mệnh tạo 7.

---

### [REF-08-018]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Thanh Triều Thánh Tổ — Khang Hy Đại Đế (Thiên Nguyệt Nhị Đức Trị Thiên Hạ 61 Năm).
- **Tứ trụ Can Chi:** **Giáp Ngọ - Kỷ Tỵ - Mậu Tuất - Đinh Tỵ** (Nam mệnh Thanh triều Hoàng đế).
- **Thể loại:** Tam Mệnh Thông Hội & Thanh Sử Cảo - Nhị Đức phù trì thịnh thế.
- **Xuất xứ cổ tịch:** *Mệnh Lý Tinh Hoa* & *Thanh Sử Cảo*: "Thánh Tổ Nhân Hoàng Đế Bát Tự".
- **Nguyên văn Hán tự:** 
  > 康熙帝造：甲午、己巳、戊戌、丁巳。戊土生於巳月，歸祿得位，坐下戌土通根。年透甲木為七煞，甲己合煞為權。巳月以丙火為月德，丁透時柱為天德，天月二德齊聚，統御六十一年，海宇昇平。
- **Phiên âm Hán Việt:** Khang Hy Đế tạo: Giáp Ngọ, Kỷ Tỵ, Mậu Tuất, Đinh Tỵ. Mậu thổ sinh vu Tị nguyệt, quy lộc đắc vị, tọa hạ Tuất thổ thông căn. Niên thấu Giáp mộc vi Thất Sát, Giáp Kỷ hợp sát vi quyền. Tị nguyệt dĩ Bính hỏa vi Nguyệt Đức, Đinh thấu thời trụ vi Thiên Đức, Thiên Nguyệt nhị đức tề tụ, thống ngự lục thập nhất niên, hải vũ thăng bình.
- **Dịch nghĩa:** Bát tự Khang Hy Hoàng Đế: Giáp Ngọ, Kỷ Tỵ, Mậu Tuất, Đinh Tỵ. Mậu Thổ sinh tháng Tị, đắc lộc kiến vượng, tọa hạ Tuất Thổ thông căn vững chắc. Năm thấu Giáp Mộc Thất Sát, Giáp Kỷ hợp biến Sát thành quyền uy. Tháng Tị có Bính Hỏa là Nguyệt Đức, Đinh Hỏa thấu giờ là Thiên Đức, Thiên Nguyệt Nhị Đức hội tụ, trị vì thiên hạ suốt 61 năm thái bình thịnh trị.
- **Link kiểm chứng công khai:** [Wikisource - 清史稿 聖祖本紀](https://zh.wikisource.org/wiki/清史稿/卷6)
- **File đối chiếu nội bộ:** `Mệnh lý tinh hoa.pdf`.
- **Vị trí áp dụng:** Tập 08, Chương II & Chương X, Mệnh tạo 8.

---

### [REF-08-019]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Vạn Dân Anh — Lý Bạch Thi Tiên (Đường Triều Kim Thần Dịch Mã Kỳ Tú).
- **Tứ trụ Can Chi:** **Tân Sửu - Bính Thân - Nhâm Ngọ - Canh Tuất** (Nam mệnh Thi Tiên Đường triều).
- **Thể loại:** Tam Mệnh Thông Hội - Kim Thần Dịch Mã xuất thế kỳ tài.
- **Xuất xứ cổ tịch:** *Tam Mệnh Thông Hội* - Quyển 3: "Luận Kim Thần Dịch Mã".
- **Nguyên văn Hán tự:** 
  > 李白命：辛丑、丙申、壬午、庚戌。壬水生申，水勢滔滔。日坐午火正財，時落庚戌金神。申為驛馬，金神得火煉而生威。一生放浪四海，筆落驚風雨，詩成泣鬼神，得金神驛馬之粹也。
- **Phiên âm Hán Việt:** Lý Bạch mệnh: Tân Sửu, Bính Thân, Nhâm Ngọ, Canh Tuất. Nhâm thủy sinh Thân, thủy thế thao thao. Nhật tọa Ngọ hỏa chính tài, thời lạc Canh Tuất kim thần. Thân vi Dịch Mã, Kim Thần đắc hỏa luyện nhi sinh uy. Nhất sinh phóng lãng tứ hải, bút lạc kinh phong vũ, thi thành khấp quỷ thần, đắc Kim Thần Dịch Mã chi túy dã.
- **Dịch nghĩa:** Lá số thi tiên Lý Bạch: Tân Sửu, Bính Thân, Nhâm Ngọ, Canh Tuất. Nhâm Thủy sinh tháng Thân, thế nước dạt dào. Ngày tọa Ngọ Hỏa Chính Tài, giờ Canh Tuất là đất Kim Thần. Thân Kim là Dịch Mã, Kim Thần gặp Ngọ Tuất luyện Hỏa phát ra uy quang rực rỡ. Cả đời phóng khoáng bốn phương trời, hạ bút kinh động mưa gió, thơ thành quỷ khóc thần sầu.
- **Link kiểm chứng công khai:** [CText - 三命通會 李白命](https://ctext.org/wiki.pl?if=gb&chapter=358878)
- **File đối chiếu nội bộ:** `Tam mệnh thông hội - Vạn Dân Anh.pdf`.
- **Vị trí áp dụng:** Tập 08, Chương III & Chương X, Mệnh tạo 9.

---

### [REF-08-020]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Vạn Dân Anh — Quách Tử Nghi Phần Dương Vương (Đường Triều Lục Thân Toàn Mỹ Phúc Thọ Song Toàn).
- **Tứ trụ Can Chi:** **Đinh Hợi - Canh Tuất - Đinh Mão - Canh Tý** (Nam mệnh Đại tướng Phần Dương Vương).
- **Thể loại:** Tam Mệnh Thông Hội - Lục Thân toàn vượng con cháu trăm người.
- **Xuất xứ cổ tịch:** *Tam Mệnh Thông Hội* - Quyển 3: "Luận Lục Thân Toàn Mỹ".
- **Nguyên văn Hán tự:** 
  > 郭子儀命：丁亥、庚戌、丁卯、庚子。丁卯日主，坐下印綬，子水為天乙貴人，亥為官貴。四柱天德月德重逢，財官印皆得位。生八子七婿，位極人臣，福壽全備，天下以其身為安危者三十年。
- **Phiên âm Hán Việt:** Quách Tử Nghi mệnh: Đinh Hợi, Canh Tuất, Đinh Mão, Canh Tý. Đinh Mão nhật chủ, tọa hạ ấn thụ, Tý thủy vi Thiên Ất Quý Nhân, Hợi vi quan quý. Tứ trụ Thiên Đức Nguyệt Đức trùng phùng, tài quan ấn giai đắc vị. Sinh bát tử thất tế, vị cực nhân thần, phúc thọ toàn bị, thiên hạ dĩ kỳ thân vi an nguy giả tam thập niên.
- **Dịch nghĩa:** Lá số Quách Tử Nghi: Đinh Hợi, Canh Tuất, Đinh Mão, Canh Tý. Đinh Mão ngày tọa Chính Ấn, Tý Thủy là Thiên Ất Quý Nhân, Hợi Thủy là Quan Tinh. Bốn trụ Thiên Đức Nguyệt Đức tương phùng, Tài Quan Ấn thảy đều đắc vị. Sinh tám người con trai, bảy chàng rể đều làm đại thần, con cháu cả trăm người, giữ yên nền an nguy của xã tắc suốt ba mươi năm.
- **Link kiểm chứng công khai:** [CText - 三命通會 郭子儀命](https://ctext.org/wiki.pl?if=gb&chapter=358878)
- **File đối chiếu nội bộ:** `Tam mệnh thông hội - Vạn Dân Anh.pdf`.
- **Vị trí áp dụng:** Tập 08, Chương V & Chương X, Mệnh tạo 10.

---

### [REF-08-021]
- **Tiêu đề / Mệnh chủ:** Manh Phái Đoàn Kiến Nghiệp — Đào Hoa Sát Ly Hôn & Tranh Chấp Tài Sản Bất Động Sản Hà Nội.
- **Tứ trụ Can Chi:** **Nhâm Dần - Đinh Mùi - Canh Tý - Tân Tỵ** (Nam mệnh đại gia vỡ nợ hôn nhân).
- **Thể loại:** Manh Phái Tố Công - Đào hoa sát nhập thê cung xung phá.
- **Xuất xứ tài liệu:** *Lục Thân Cao Cấp Diện Thụ* - Đoàn Kiến Nghiệp. Tiết: "Đào hoa phá thê cung và ly hôn phân sản".
- **Đoạn trích đối chiếu:**
  > Canh kim tọa Tý thủy Thương quan là đất đào hoa. Niên chi Dần hợp Nguyệt chi Mùi khố, nhưng Tý Tỵ tương tuyệt, Đinh hỏa Chính quan bị Nhâm thủy hợp khử. Vận Tân Hợi gặp lưu niên Bính Thân xung Dần, vợ phát hiện ngoại tình với trợ lý, kiện ra tòa đòi chia nửa số biệt thự Tây Hồ.
- **File đối chiếu nội bộ:** `Lục thân cao cấp diện thụ.docx` (Trang 118).
- **Vị trí áp dụng:** Tập 08, Chương VIII & Chương X, Mệnh tạo 11.

---

### [REF-08-022]
- **Tiêu đề / Mệnh chủ:** Manh Phái Đoàn Kiến Nghiệp — Không Vong Tuyệt Tự Cung Tử Tức Doanh Nhân Nông Sản Sơn La.
- **Tứ trụ Can Chi:** **Bính Thìn - Kỷ Tỵ - Giáp Dần - Quý Dậu** (Nam mệnh hiếm muộn vô tự).
- **Thể loại:** Manh Phái Tố Công - Thời trụ phùng Không Vong tuyệt tự.
- **Xuất xứ tài liệu:** *Mệnh Lý Huyền Cơ* - Đoàn Kiến Nghiệp. Tiết: "Không Vong thời trụ và vấn đề con cái".
- **Đoạn trích đối chiếu:**
  > Giáp Dần tuần Giáp Tý, Tuất Hợi không vong. Thời trụ Quý Dậu, Dậu là Quan tinh con trai nhưng Dậu bị Tỵ Dần hình hại. Chi ngày Giáp Dần tỷ kiên quá vượng, Dậu kim sinh Quý thủy ấn tinh quá độ làm thổ khô mộc cứng. Chạy chữa khắp các bệnh viện phụ sản lớn suốt 15 năm không sinh được con trai nối dõi.
- **File đối chiếu nội bộ:** `Manh phái mệnh lý.pdf` (Trang 184).
- **Vị trí áp dụng:** Tập 08, Chương VII & Chương X, Mệnh tạo 12.

---

### [REF-08-023]
- **Tiêu đề / Mệnh chủ:** Manh Phái Đoàn Kiến Nghiệp — Cung Phối Ngẫu Phùng Xung Hai Lần Gãy Đổ Hôn Nhân.
- **Tứ trụ Can Chi:** **Ất Mão - Kỷ Mão - Canh Thìn - Bính Tuất** (Nữ mệnh giám đốc tài chính).
- **Thể loại:** Manh Phái Tố Công - Thìn Tuất xung động thê phu cung.
- **Xuất xứ tài liệu:** *Lục Thân Cao Cấp Diện Thụ* - Đoàn Kiến Nghiệp. Tiết: "Xung động phu cung và tái hôn liên tiếp".
- **Đoạn trích đối chiếu:**
  > Canh kim tọa Thìn ấn tinh, thời chi Bính Tuất thất sát tọa Tuất thổ xung thẳng vào Thìn thổ phu cung. Thìn Tuất tương xung, mộ khố mở cửa phá vỡ sự tĩnh lặng của cung chồng. Lần đầu kết hôn năm Giáp Tuất ly dị; lần hai tái hôn năm Mậu Tuất lại chia tay vì bất hòa quan điểm sống.
- **File đối chiếu nội bộ:** `Lục thân cao cấp diện thụ.docx` (Trang 135).
- **Vị trí áp dụng:** Tập 08, Chương VI & Chương X, Mệnh tạo 13.

---

### [REF-08-024]
- **Tiêu đề / Mệnh chủ:** Manh Phái Đoàn Kiến Nghiệp — Dương Nhận Đoạt Tài Huynh Đệ Tương Tàn Vì Đất Đai Thừa Kế.
- **Tứ trụ Can Chi:** **Giáp Thìn - Bính Dần - Mậu Ngọ - Đinh Tỵ** (Nam mệnh tranh chấp đất đai với anh em ruột).
- **Thể loại:** Manh Phái Tố Công - Dương Nhận đoạt tài cốt nhục tương tàn.
- **Xuất xứ tài liệu:** *Lục Thân Cao Cấp Diện Thụ* - Đoàn Kiến Nghiệp. Tiết: "Huynh đệ đoạt tài dẫn tới kiện tụng hình sự".
- **Đoạn trích đối chiếu:**
  > Mậu thổ tọa Ngọ hỏa Dương Nhận, thời Đinh Tỵ kiếp sát hỏa khí ngút trời. Niên chi Thìn thổ là Tài khố duy nhất bị Dần Ngọ bán hợp hỏa cục thiêu rụi. Khi cha mẹ qua đời để lại mảnh đất mặt tiền 500m2 tại Hải Phòng, 4 anh em ruột kiện nhau ra tòa, thuê giang hồ đe dọa lẫn nhau suốt 7 năm.
- **File đối chiếu nội bộ:** `Lục thân cao cấp diện thụ.docx` (Trang 162).
- **Vị trí áp dụng:** Tập 08, Chương VII & Chương X, Mệnh tạo 14.

---

### [REF-08-025]
- **Tiêu đề / Mệnh chủ:** Manh Phái Đoàn Kiến Nghiệp — Dịch Mã Đới Tài Xuất Ngoại Thành Triệu Phú Mỹ Phẩm Hàn Quốc.
- **Tứ trụ Can Chi:** **Kỷ Tỵ - Đinh Mão - Canh Thân - Giáp Thân** (Nữ mệnh doanh nhân xuất khẩu).
- **Thể loại:** Manh Phái Tố Công - Dịch Mã đới Tài thiên di phát phúc.
- **Xuất xứ tài liệu:** *Mệnh Lý Huyền Cơ* - Đoàn Kiến Nghiệp. Tiết: "Dịch Mã đới Tài xuất ngoại đại phú".
- **Đoạn trích đối chiếu:**
  > Canh kim tọa Thân là Chuyên lộc kiêm Dịch Mã, thời chi Giáp Thân lại mang Thiên Tài cưỡi trên Dịch Mã. Dịch Mã trùng phùng mang theo túi tiền, mệnh chủ sang Seoul từ năm 22 tuổi, gây dựng hệ thống phân phối mỹ phẩm xuyên biên giới với doanh thu hàng trăm tỷ đồng mỗi năm.
- **File đối chiếu nội bộ:** `Manh phái mệnh lý.pdf` (Trang 210).
- **Vị trí áp dụng:** Tập 08, Chương III & Chương X, Mệnh tạo 15.

---

### [REF-08-026]
- **Tiêu đề / Mệnh chủ:** Hiện Đại Thiệu Vĩ Hoa — Cô Thần Quả Tú Nữ Trí Thức Hà Nội Độc Thân Trọn Đời.
- **Tứ trụ Can Chi:** **Nhâm Tý - Nhâm Dần - Canh Thân - Đinh Hợi** (Nữ mệnh Tiến sĩ Viện Hàn lâm).
- **Thể loại:** Tứ Trụ Dự Đoán Học - Cô Thần Quả Tú duyên bạc.
- **Xuất xứ tài liệu:** *Tứ Trụ Dự Đoán Học* - Thiệu Vĩ Hoa. Chương: "Thần Sát hôn nhân và phụ nữ độc thân".
- **Đoạn trích đối chiếu:**
  > Canh kim tọa Thân, Dần Thân tương xung, Hợi Tý thủy vượng khắc Đinh hỏa Chính quan. Tuổi Tý gặp Dần là phạm Cô Thần, trụ ngày Thân lại gặp Hợi là phạm Quả Tú. Học vấn uyên thâm, công tác tại Viện Hàn lâm Khoa học, cả đời không một mối tình vắt vai, 55 tuổi sống an nhiên cô độc cùng đàn mèo.
- **File đối chiếu nội bộ:** `Tứ Trụ Dự Đoán Học - Thiệu Vĩ Hoa.pdf` (Trang 188).
- **Vị trí áp dụng:** Tập 08, Chương IV & Chương X, Mệnh tạo 16.

---

### [REF-08-027]
- **Tiêu đề / Mệnh chủ:** Hiện Đại Thiệu Vĩ Hoa — Thiên La Địa Võng Lao Lý Do Buôn Lậu Vàng Qua Biên Giới.
- **Tứ trụ Can Chi:** **Mậu Tuất - Kỷ Mùi - Nhâm Thìn - Ất Tỵ** (Nam mệnh trùm buôn lậu sa lưới).
- **Thể loại:** Tứ Trụ Dự Đoán Học - Thiên La Địa Võng ngục hình bộc phát.
- **Xuất xứ tài liệu:** *Tứ Trụ Dự Đoán Học* - Thiệu Vĩ Hoa. Chương: "Nhận diện tai họa lao lý qua Thiên La Địa Võng".
- **Đoạn trích đối chiếu:**
  > Nhâm thủy tọa Thìn là Địa Võng, niên chi Mậu Tuất là Thiên La. Thìn Tuất tương xung, quan sát hỗn tạp thổ vượng đè bẹp Nhâm thủy. Đại vận Quý Hợi gặp năm Canh Tuất, Thiên La trùng phùng kéo sập lưới, bị bắt quả tang vận chuyển 120kg vàng lậu qua biên giới Campuchia, nhận án 18 năm tù.
- **File đối chiếu nội bộ:** `Tứ Trụ Dự Đoán Học - Thiệu Vĩ Hoa.pdf` (Trang 215).
- **Vị trí áp dụng:** Tập 08, Chương IV & Chương X, Mệnh tạo 17.

---

### [REF-08-028]
- **Tiêu đề / Mệnh chủ:** Hiện Đại Thiệu Vĩ Hoa — Hồng Loan Thiên Hỷ Hợp Hôn Trọn Đời Hạnh Phúc 50 Năm.
- **Tứ trụ Can Chi:** **Bính Tuất - Tân Mão - Ất Hợi - Đinh Sửu** (Cặp vợ chồng giáo viên hưu trí mẫu mực).
- **Thể loại:** Tứ Trụ Dự Đoán Học - Cát thần phò hôn nhân hạnh phúc.
- **Xuất xứ tài liệu:** *Tứ Trụ Dự Đoán Học* - Thiệu Vĩ Hoa. Chương: "Phương pháp hợp hôn và biểu hiện của Hồng Loan Thiên Hỷ".
- **Đoạn trích đối chiếu:**
  > Ất mộc tọa Hợi ấn tinh sinh thân, thấu Bính hỏa noãn cục, Mão Tuất tương hợp khóa chặt lộc vị. Niên chi Tuất là Thiên Hỷ, nguyệt chi Mão là Hồng Loan. Vợ chồng đồng cam cộng khổ từ thời chiến tranh, cùng giảng dạy đại học, nuôi dạy 3 người con đều đỗ đạt tiến sĩ, đám cưới vàng 50 năm con cháu quây quần.
- **File đối chiếu nội bộ:** `Tứ Trụ Dự Đoán Học - Thiệu Vĩ Hoa.pdf` (Trang 240).
- **Vị trí áp dụng:** Tập 08, Chương III & Chương X, Mệnh tạo 18.

---

### [REF-08-029]
- **Tiêu đề / Mệnh chủ:** Hiện Đại Trần Khang Ninh — Cung Phu Phùng Xung Nữ Giám Đốc Phân Chia Tài Sản Nghìn Tỷ.
- **Tứ trụ Can Chi:** **Giáp Dần - Bính Dần - Tân Tỵ - Kỷ Hợi** (Nữ chủ tịch chuỗi khách sạn nghỉ dưỡng).
- **Thể loại:** Dự Báo Theo Tử Bình - Tỵ Hợi xung thê phu cung phá nát gia đạo.
- **Xuất xứ tài liệu:** *Dự Báo Theo Tử Bình* - Trần Khang Ninh. Chương: "Bi kịch hôn nhân của các nữ doanh nhân thành đạt".
- **Đoạn trích đối chiếu:**
  > Tân kim tọa Tỵ hỏa Chính quan đắc vị, nhưng thời chi thấu Kỷ Hợi xung thẳng Tỵ hỏa. Tỵ Hợi tương xung là phu cung bị đập nát. Khi công ty lên sàn chứng khoán vốn hóa vượt 2.000 tỷ đồng thì người chồng bí mật lập phòng nhì và tẩu tán tài sản sang công ty con. Vụ kiện tranh chấp quyền kiểm soát kéo dài 5 năm tại Tòa án Nhân dân TP.HCM.
- **File đối chiếu nội bộ:** `Dự Báo Theo Tử Bình - Trần Khang Ninh.pdf` (Trang 268).
- **Vị trí áp dụng:** Tập 08, Chương VI & Chương X, Mệnh tạo 19.

---

### [REF-08-030]
- **Tiêu đề / Mệnh chủ:** Hiện Đại Trần Khang Ninh — Kiêu Đoạt Thực Tử Tức Cung Trầm Cảm Tuổi Dậy Thì & Tự Hại.
- **Tứ trụ Can Chi:** **Bính Tý - Canh Dần - Mậu Tuất - Đinh Tỵ** (Nam mệnh con trai một tập đoàn công nghệ).
- **Thể loại:** Dự Báo Theo Tử Bình - Kiêu đoạt thực tại cung tử tức gây bệnh lý tâm thần.
- **Xuất xứ tài liệu:** *Dự Báo Theo Tử Bình* - Trần Khang Ninh. Chương: "Khủng hoảng tâm lý con cái thế hệ F2 qua Bát Tự".
- **Đoạn trích đối chiếu:**
  > Mậu thổ tọa Tuất, thời trụ Đinh Tỵ là đất Kiêu Thần cực vượng. Nguyệt can Canh kim Thực thần là tú khí của con cái bị Đinh Tỵ thiêu đốt bức tử. Người cha kỳ vọng con kế nghiệp, ép học 4 thứ tiếng từ bé. Đến năm 17 tuổi cháu mắc chứng trầm cảm nặng, nhiều lần tự hại, buộc phải từ bỏ hoàn toàn việc du học để nhập viện điều trị tâm lý dài hạn.
- **File đối chiếu nội bộ:** `dự-báo-theo-tử-bình-trần-khang-ninh-pdf-dantocking.com.PDF` (Trang 285).
- **Vị trí áp dụng:** Tập 08, Chương VII & Chương X, Mệnh tạo 20.

---


========================================================================================
# TẬP 09: ĐỘNG LỰC HỌC VẬN HẠN & ỨNG KỲ TOÀN THƯ (CUMULATIVE PATHOLOGY INDEX - CPI ENGINE)
# BẢNG KHẢO CHỨNG 30 MÃ TRÍCH DẪN HỌC THUẬT QUY CHUẨN [REF-09-001] ĐẾN [REF-09-030]
========================================================================================

### [REF-09-001]
- **Tiêu đề / Mệnh chủ:** Trích Thiên Tủy Chinh Nghĩa — Tam Bàn Động Học Cương Lĩnh (Nguyên Cục vi Thể, Đại Vận vi Thừa, Lưu Niên vi Dụng).
- **Tác giả / Xuất xứ:** *Trích Thiên Tủy Điệt Vi / Chinh Nghĩa* — Nhậm Thiết Tiều khảo chú. Thiên: "Vận Cục Động Thái Luận".
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「命好不如運好。命如舟楫，運如江潮。舟雖固，遇逆浪則覆；舟雖薄，順順風則馳。原局為體，行運為用，流年為應。三者同參，死生吉凶乃定。」
  > (Mệnh tốt không bằng Vận tốt. Mệnh như thuyền bè, Vận như sóng gió triều dâng. Thuyền dù kiên cố gặp sóng dữ ắt lật; thuyền dù mỏng manh gặp gió thuận ắt bay xa muôn dặm. Nguyên cục là Thể, Đại vận là Dụng, Lưu niên là Ứng. Cả ba cùng xét, phúc họa tử sinh mới định rõ).
- **Cơ sở dữ liệu số:** [ctext.org/wiki.pl?if=gb&chapter=355610](https://ctext.org) | Wikisource: [滴天髓徵義/卷二](https://zh.wikisource.org/wiki/滴天髓徵義).
- **File đối chiếu nội bộ:** `Trích Thiên Tủy Điệt Vi - Nhậm Thiết Tiều.pdf` (Trang 182).
- **Vị trí áp dụng:** Tập 09, Chương I, Bản thể luận Tam Bàn Động Học.

---

### [REF-09-002]
- **Tiêu đề / Mệnh chủ:** Tử Bình Chân Thuyên — Đại Vận Phân Định Trọng Lực: Can Chi Thống Lĩnh & Giao Thoa Khí Lực.
- **Tác giả / Xuất xứ:** *Tử Bình Chân Thuyên* — Trầm Hiếu Thắng. Thiên: "Luận Đại Vận Hỷ Kỵ & Can Chi Phân Thống".
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「論運與論八字無二，但八字看支神透出何干，而運則看干臨何支。蓋干統頭五年，支統後五年，此常法也。然干中亦有支氣，支中亦有干神，不可截然割裂。更看地支與原局會合格局，成敗在茲。」
  > (Luận vận với luận Bát Tự không có hai đường, Bát Tự xem chi thần thấu ra can nào, còn Vận thì xem can lâm trên chi nào. Thường pháp can quản 5 năm đầu, chi quản 5 năm sau. Nhưng trong can có khí chi, trong chi có can thần, không thể cắt rời máy móc. Cần xem địa chi vận hội hợp cách cục nguyên cục ra sao, thành bại ở đó).
- **Cơ sở dữ liệu số:** [ctext.org/wiki.pl?if=gb&chapter=845620](https://ctext.org) | Wikisource: [子平真詮/論運](https://zh.wikisource.org/wiki/子平真詮).
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên - Trầm Hiếu Thắng.pdf` (Trang 145).
- **Vị trí áp dụng:** Tập 09, Chương I & Chương II, Cơ chế tiếp dẫn khí đại vận.

---

### [REF-09-003]
- **Tiêu đề / Mệnh chủ:** Tam Mệnh Thông Hội — Thái Tuế Tối Tôn & Phép Biện Chứng "Tuế Vận Tịnh Lâm" Cát Hung.
- **Tác giả / Xuất xứ:** *Tam Mệnh Thông Hội* — Vạn Dân Anh. Quyển 4, Thiên: "Luận Thái Tuế Cát Hung & Tuế Vận Tịnh Lâm".
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「歲運並臨，災殃立至。獨羊刃、七煞為凶，若財官印綬為喜用，反主發福非常。太歲乃年中天子，大運如執政丞相，歲運相爭，君臣不睦，黎民受困。」
  > (Tuế Vận Tịnh Lâm, tai ương lập tức giáng xuống. Nhưng chỉ duy Kình Dương và Thất Sát mới hung, nếu là Tài Quan Ấn Thụ làm Hỷ Dụng Thần thì ngược lại chủ về phát phúc phi thường. Thái Tuế là thiên tử trong năm, Đại Vận như thừa tướng chấp chính, Tuế Vận giao tranh ví như vua tôi bất hòa, muôn dân chịu khổ).
- **Cơ sở dữ liệu số:** [ctext.org/wiki.pl?if=gb&chapter=582103](https://ctext.org) | Wikisource: [三命通會/卷四](https://zh.wikisource.org/wiki/三命通會).
- **File đối chiếu nội bộ:** `Tam Mệnh Thông Hội - Vạn Dân Anh.pdf` (Tập 1, Trang 230).
- **Vị trí áp dụng:** Tập 09, Chương IV, Lục đại hiện tượng cực đoan kinh điển.

---

### [REF-09-004]
- **Tiêu đề / Mệnh chủ:** Trích Thiên Tủy Điệt Vi — Biện Chứng Phục Ngâm & Phản Ngâm: Nước Mắt Bi Than vs Bộc Phát Cát Khánh.
- **Tác giả / Xuất xứ:** *Trích Thiên Tủy Điệt Vi* — Nhậm Thiết Tiều khảo thích. Chương: "Phục Ngâm Phản Ngâm Luận".
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「反吟伏吟淚淋淋，不傷自己損他人。然不可概以凶斷。若反吟衝去忌神，反成大吉；伏吟重疊喜神，更增其福。局中喜神受衝則死，局中忌神受衝則生。」
  > (Phản ngâm phục ngâm nước mắt đầm đìa, không thương tật bản thân cũng tổn hại người nhà. Tuy nhiên không thể đoán bừa đều hung. Nếu phản ngâm xung tan kỵ thần thì biến thành đại cát; phục ngâm trùng điệp hỷ thần thì phúc càng tăng thêm. Trong cục hỷ thần bị xung thì chết, kỵ thần bị xung thì sống).
- **Cơ sở dữ liệu số:** [ctext.org/wiki.pl?if=gb&chapter=355615](https://ctext.org) | Wikisource: [滴天髓徵義/卷三](https://zh.wikisource.org/wiki/滴天髓徵義).
- **File đối chiếu nội bộ:** `Trích Thiên Tủy Điệt Vi - Nhậm Thiết Tiều.pdf` (Trang 198).
- **Vị trí áp dụng:** Tập 09, Chương IV, Lục đại hiện tượng cực đoan kinh điển.

---

### [REF-09-005]
- **Tiêu đề / Mệnh chủ:** Uyên Hải Tử Bình — Thiên Khắc Địa Xung & Chinh Đề Chi Tai: Bạt Căn Sinh Mệnh.
- **Tác giả / Xuất xứ:** *Uyên Hải Tử Bình* — Từ Tử Bình. Quyển 3, Thiên: "Luận Chinh Đề & Tuế Vận Xung Kích".
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「真犯太歲，征太歲也。日干支衝剋太歲，名曰征提。日犯歲君，災殃必重；歲君犯日，其禍稍輕。天干相剋，地支相衝，如雷霆破擊，根基拔除。」
  > (Chân phạm Thái Tuế tức Chinh Thái Tuế vậy. Can chi ngày xung khắc Thái Tuế gọi là Chinh Đề. Ngày phạm Thái Tuế thì tai ương ắt nặng; Thái Tuế phạm Ngày thì họa hơi nhẹ hơn. Thiên can tương khắc, địa chi tương xung, như sấm sét đánh bổ, gốc rễ sinh mệnh bị bạt nhổ).
- **Cơ sở dữ liệu số:** [ctext.org/wiki.pl?if=gb&chapter=721050](https://ctext.org) | Wikisource: [淵海子平/卷三](https://zh.wikisource.org/wiki/淵海子平).
- **File đối chiếu nội bộ:** `Uyên Hải Tử Bình - Từ Tử Bình.pdf` (Trang 162).
- **Vị trí áp dụng:** Tập 09, Chương IV, Hiện tượng Thiên Khắc Địa Xung.

---

### [REF-09-006]
- **Tiêu đề / Mệnh chủ:** Tử Bình Chân Thuyên — Hành Vận Biến Cách: Thành Trung Hữu Bại & Bại Trung Hữu Cứu.
- **Tác giả / Xuất xứ:** *Tử Bình Chân Thuyên* — Trầm Hiếu Thắng. Thiên: "Luận Hành Vận Thành Cách Biến Cách".
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「行運之法，成格變格，不可不知。正官格行傷官運，官破成災，此成中有敗也；印綬逢財運，局有劫財制財護印，此敗中有救也。運助喜神則吉，運助忌神則凶。」
  > (Phép xem hành vận, thành cách biến cách không thể không tường. Chính quan cách hành thương quan vận, quan bị phá mà sinh tai họa, đó là trong thành có bại; Ấn thụ gặp tài vận, trong cục có kiếp tài chế tài để hộ ấn, đó là trong bại có cứu. Vận trợ hỷ thần thì cát, vận trợ kỵ thần thì hung).
- **Cơ sở dữ liệu số:** [ctext.org/wiki.pl?if=gb&chapter=845622](https://ctext.org) | Wikisource: [子平真詮/論運成格變格](https://zh.wikisource.org/wiki/子平真詮).
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên - Trầm Hiếu Thắng.pdf` (Trang 158).
- **Vị trí áp dụng:** Tập 09, Chương VI, Biện chứng vận cát hóa hung & vận hung hóa cát.

---

### [REF-09-007]
- **Tiêu đề / Mệnh chủ:** Cùng Thông Bảo Giám — Khúc Quanh 120° Chuyển Phương Cục & Biến Thiên Vi Khí Hậu.
- **Tác giả / Xuất xứ:** *Cùng Thông Bảo Giám* — Dư Xuân Đài khảo đính. Thiên: "Phương Cục Biến Thiên & Điều Hậu Chuyển Vận".
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「方局變革，氣候更易。自東方木運轉南方火運，寒盡春歸而炎夏至；自南方火運轉西方金運，收斂肅殺之氣作矣。凡過方交接之際，陰陽大變，最易生發波瀾。」
  > (Phương cục chuyển đổi, khí hậu biến dời. Từ Đông phương Mộc vận chuyển sang Nam phương Hỏa vận, rét tan xuân qua mà hạ nóng bức tới; từ Nam phương Hỏa vận chuyển sang Tây phương Kim vận, khí thu liễm túc sát dấy khởi. Phàm lúc giao tiếp chuyển phương, âm dương đại biến, là thời khắc dễ sinh sóng gió bão bùng nhất).
- **Cơ sở dữ liệu số:** [ctext.org/wiki.pl?if=gb&chapter=694120](https://ctext.org) | Wikisource: [窮通寶鑑/總論](https://zh.wikisource.org/wiki/窮通寶鑑).
- **File đối chiếu nội bộ:** `Cùng Thông Bảo Giám - Dư Xuân Đài.pdf` (Trang 210).
- **Vị trí áp dụng:** Tập 09, Chương II, Cơ chế khúc quanh 120 độ chuyển phương cục.

---

### [REF-09-008]
- **Tiêu đề / Mệnh chủ:** Tam Mệnh Thông Hội — Mộ Khố Vận Động Thái: Xung Khai Bộc Phát vs Sập Hầm Chôn Vùi.
- **Tác giả / Xuất xứ:** *Tam Mệnh Thông Hội* — Vạn Dân Anh. Quyển 5, Thiên: "Luận Tứ Mộ Khố Khai Bế Tuế Vận".
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「辰戌丑未，四庫之神。旺則衝開得發，衰則衝破成災。如財官入庫，不衝不發；若身衰印絕，更逢衝墓，乃閉門殺賊，陷身於井，必死不疑。」
  > (Thìn Tuất Sửu Mùi là thần của tứ mộ khố. Thân vượng xung mở thì phát tài, thân suy xung phá thì thành tai họa. Như tài quan vào kho, không xung không phát; nếu thân suy ấn tuyệt, lại gặp xung mộ, ấy là đóng cửa giết giặc, sụp thân xuống giếng, ắt chết không nghi ngờ).
- **Cơ sở dữ liệu số:** [ctext.org/wiki.pl?if=gb&chapter=582105](https://ctext.org) | Wikisource: [三命通會/卷五](https://zh.wikisource.org/wiki/三命通會).
- **File đối chiếu nội bộ:** `Tam Mệnh Thông Hội - Vạn Dân Anh.pdf` (Tập 1, Trang 312).
- **Vị trí áp dụng:** Tập 09, Chương II & Chương IV, Xung khố bộc phát.

---

### [REF-09-009]
- **Tiêu đề / Mệnh chủ:** Mệnh Lý Tinh Hoa — Thoát Vận Tiếp Vận: Vùng Quá Độ Khí Trường 2 Năm Nguy Hiểm.
- **Tác giả / Xuất xứ:** *Mệnh Lý Tinh Hoa* — Từ Nhạc Ngô. Chương: "Giao Tiếp Vận Quá Độ Chấn Động".
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「脫運接運，如人之換骨更衣。前運之氣未盡，後運之氣已至，兩氣交戰，身心最不安寧。大凡交運之年前後二年，事多更變，疾病、官非、破耗常起於此。」
  > (Thoát vận tiếp vận, ví như người thay xương đổi áo. Khí vận trước chưa tan hết, khí vận sau đã tràn tới, hai luồng khí giao tranh, thân tâm bất an tột độ. Phàm trước sau 2 năm của điểm giao vận, sự việc hay biến động, tật bệnh, kiện tụng, hao tài thường bùng phát ở đây).
- **Cơ sở dữ liệu số:** [ctext.org/wiki.pl?if=gb&chapter=912040](https://ctext.org) | Wikisource: [命理精華/交運論](https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Mệnh Lý Tinh Hoa - Từ Nhạc Ngô.pdf` (Trang 98).
- **Vị trí áp dụng:** Tập 09, Chương II, Hiện tượng giao đại vận quá độ 2 năm.

---

### [REF-09-010]
- **Tiêu đề / Mệnh chủ:** Thiên Lý Mệnh Cảo — Kỹ Thuật Định Vị Ứng Kỳ: Điểm Hạn Phân Giải Đến Lưu Nguyệt & Lưu Nhật.
- **Tác giả / Xuất xứ:** *Thiên Lý Mệnh Cảo* — Vi Thiên Lý. Chương: "Ứng Kỳ Điểm Hạn Tinh Vi Bí Quyết".
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「流年斷事，必以月令為樞機。合逢衝而動，衝逢合而發。缺者逢填實之月而現，過旺者逢引拔之日而決。歲運吉凶，於月令節氣之交最驗。」
  > (Lưu niên đoán sự việc, ắt lấy tháng làm the chốt. Hợp gặp xung mà động, xung gặp hợp mà phát. Thần thiếu hụt gặp tháng điền thực mà hiện, thần quá vượng gặp ngày dẫn xuất mà nổ bùng. Cát hung của tuế vận, ứng nghiệm chuẩn xác nhất tại lúc giao tiếp tiết khí nguyệt lệnh).
- **Cơ sở dữ liệu số:** [ctext.org/wiki.pl?if=gb&chapter=954110](https://ctext.org) | Wikisource: [千里命稿/應期](https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Thiên Lý Mệnh Cảo - Vi Thiên Lý.pdf` (Trang 134).
- **Vị trí áp dụng:** Tập 09, Chương V, Phương pháp điểm hạn ứng kỳ đến tháng và ngày.

---

### [REF-09-011]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Nhậm Thiết Tiều — Mệnh Tạo Lâm Tắc Từ: Vận Canh Thìn Khai Sát Cấm Nha Phiến, Vận Kỷ Mão Bị Trục Xuất Tân Cương.
- **Tứ trụ Can Chi:** **Ất Tỵ - Giáp Thân - Quý Dậu - Nhâm Tý** (Tổng đốc Lưỡng Quảng, anh hùng dân tộc triều Thanh).
- **Thể loại:** Trích Thiên Tủy Điệt Vi - Vận dụng Quan Sát tương đình biến thiên.
- **Xuất xứ tài liệu:** *Trích Thiên Tủy Điệt Vi* — Nhậm Thiết Tiều khảo thích. Quyển 4, Chương: "Quan Sát Cách Cục Tuế Vận Thăng Trầm".
- **Đoạn trích đối chiếu:**
  > Quý thủy tọa Dậu đắc trường sinh, kim thủy tương sinh cực vượng. Vận Canh Thìn ấn vượng sinh thân, nhậm chức Khâm sai đại thần thiêu hủy nha phiến tại Hổ Môn vang dội ngũ châu. Bước vào vận Kỷ Mão, Mão Dậu tương xung phá tan cung ấn, Đạo Quang đế giáng chức trục xuất lưu đày Tân Cương gian khổ.
- **Cơ sở dữ liệu số:** [ctext.org/wiki.pl?if=gb&chapter=355625](https://ctext.org) | Wikisource: [滴天髓徵義/卷四](https://zh.wikisource.org/wiki/滴天髓徵義).
- **File đối chiếu nội bộ:** `Trích Thiên Tủy Điệt Vi - Nhậm Thiết Tiều.pdf` (Trang 242).
- **Vị trí áp dụng:** Tập 09, Chương X, Mệnh tạo 01.

---

### [REF-09-012]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Nhậm Thiết Tiều — Mệnh Tạo Tăng Quốc Phiên: Vận Giáp Thìn Kiêu Khắc Thực Khai Công Dẹp Loạn, Vận Quý Mão Quan Tinh Tạ Thế.
- **Tứ trụ Can Chi:** **Tân Mùi - Kỷ Hợi - Bính Thìn - Kỷ Hợi** (Đại học sĩ Văn Hóa Điện, Thống soái Tương Quân dẹp Thái Bình Thiên Quốc).
- **Thể loại:** Trích Thiên Tủy Điệt Vi - Khúc quanh vận trình sát nhận tương đình.
- **Xuất xứ tài liệu:** *Trích Thiên Tủy Điệt Vi* — Nhậm Thiết Tiều khảo thích. Quyển 3, Chương: "Sát Cách Hỷ Dụng Tuế Vận".
- **Đoạn trích đối chiếu:**
  > Bính hỏa sinh tháng Hợi tọa Thìn thổ thấp hàn. Vận Giáp Thìn thấu Kiêu thần chế Thực hộ Sát, thống soái Tương quân san phẳng Thiên Kinh dẹp tan Thái Bình Thiên Quốc, phong Nhất đẳng Nghị Dũng Hầu. Đại vận Quý Mão, lưu niên Nhâm Thân (1872) thủy vượng dập tắt tàn hỏa, đột quỵ tạ thế an bình hưởng thọ 62 tuổi.
- **Cơ sở dữ liệu số:** [ctext.org/wiki.pl?if=gb&chapter=355628](https://ctext.org) | Wikisource: [滴天髓徵義/卷三](https://zh.wikisource.org/wiki/滴天髓徵義).
- **File đối chiếu nội bộ:** `Trích Thiên Tủy Điệt Vi - Nhậm Thiết Tiều.pdf` (Trang 265).
- **Vị trí áp dụng:** Tập 09, Chương X, Mệnh tạo 02.

---

### [REF-09-013]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Vạn Dân Anh — Mệnh Tạo Lý Hồng Chương: Khúc Trực Vận Kỷ Dậu Phùng Xung Thất Thế Ký Hòa Ước, Vận Mậu Thân Qua Đời.
- **Tứ trụ Can Chi:** **Quý Mùi - Giáp Dần - Ất Hợi - Kỷ Mão** (Đại thần Bắc Dương, Tổng đốc Trực Lệ).
- **Thể loại:** Tam Mệnh Thông Hội - Khúc Trực Nhân Thọ cách phá lộc tuế vận.
- **Xuất xứ tài liệu:** *Tam Mệnh Thông Hội* — Vạn Dân Anh. Quyển 7, Chương: "Chuyên Vượng Cách Tuế Vận Cát Hung".
- **Đoạn trích đối chiếu:**
  > Hợi Mão Mùi tam hợp Mộc cục, thấu Giáp tọa Dần, Khúc Trực thành cách đại quý. Vận Kỷ Dậu kim mộc tương tàn xung phá lộc chi Mão mộc, thất bại trong chiến tranh Giáp Ngọ, bị bãi chức và phải ký Hiệp ước Mã Quan nhục nhã. Đại vận Mậu Thân xung khắc Giáp Dần, lưu niên Tân Sửu (1901) thổ huyết qua đời.
- **Cơ sở dữ liệu số:** [ctext.org/wiki.pl?if=gb&chapter=582108](https://ctext.org) | Wikisource: [三命通會/卷七](https://zh.wikisource.org/wiki/三命通會).
- **File đối chiếu nội bộ:** `Tam Mệnh Thông Hội - Vạn Dân Anh.pdf` (Tập 2, Trang 115).
- **Vị trí áp dụng:** Tập 09, Chương X, Mệnh tạo 03.

---

### [REF-09-014]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Từ Tử Bình — Mệnh Tạo Viên Thế Khải: Vận Bính Dần Xưng Đế, Lưu Niên Bính Thìn Tuế Vận Tương Xung Bộc Phát Thổ Huyết Vong.
- **Tứ trụ Can Chi:** **Kỷ Mùi - Quý Dậu - Đinh Tị - Đinh Mùi** (Đại Tổng thống Trung Hoa Dân Quốc, Hoàng đế Hồng Hiến 83 ngày).
- **Thể loại:** Uyên Hải Tử Bình - Sát Nhận tương đình tuế vận xung sụp.
- **Xuất xứ tài liệu:** *Uyên Hải Tử Bình* — Từ Tử Bình. Quyển 4, Chương: "Đế Vương Tướng Soái Tuế Vận Hưng Bại".
- **Đoạn trích đối chiếu:**
  > Đinh hỏa tọa Tị đới Lộc, Quý thủy Thất sát tọa Dậu sinh trợ. Vận Bính Dần hỏa trợ thân vượng đoạt quyền xưng đế. Lưu niên Bính Thìn (1916), Thìn Dậu hợp hóa, thổ hỏa tương khắc bế tắc cực độ, toàn quốc khởi nghĩa đòi lật đổ, uất hận thổ huyết chết vì bệnh niệu độc sau 83 ngày xưng đế.
- **Cơ sở dữ liệu số:** [ctext.org/wiki.pl?if=gb&chapter=721055](https://ctext.org) | Wikisource: [淵海子平/卷四](https://zh.wikisource.org/wiki/淵海子平).
- **File đối chiếu nội bộ:** `Uyên Hải Tử Bình - Từ Tử Bình.pdf` (Trang 218).
- **Vị trí áp dụng:** Tập 09, Chương X, Mệnh tạo 04.

---

### [REF-09-015]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Nhậm Thiết Tiều — Mệnh Tạo Tả Tông Đường: Vận Đinh Tị Lộc Nhận Tụ Hội Thu Phục Tân Cương, Vận Bính Thìn Lâm Chung Vinh Hiển.
- **Tứ trụ Can Chi:** **Nhâm Thân - Tân Hợi - Bính Ngọ - Canh Dần** (Đại tướng quân triều Thanh, Tổng đốc Thiểm Cam).
- **Thể loại:** Trích Thiên Tủy Điệt Vi - Sát Nhận tương chế tuế vận hiển hách.
- **Xuất xứ tài liệu:** *Trích Thiên Tủy Điệt Vi* — Nhậm Thiết Tiều khảo thích. Quyển 3, Chương: "Dương Nhận Ngộ Sát Vận Hành Thao Lược".
- **Đoạn trích đối chiếu:**
  > Bính hỏa tọa Ngọ Dương Nhận cực vượng, thấu Nhâm Thủy Thất sát tọa Thân sinh trợ. Vận Đinh Tị hỏa trợ thân cường, phụng mệnh thống lĩnh đại quân vượt sa mạc thu phục toàn bộ Tân Cương rộng lớn, uy chấn biên ải. Bước vào vận Bính Thìn hỏa thổ điều hòa, lâm chung an nhiên thọ 74 tuổi, truy tặng Thái tử Thái bảo.
- **Cơ sở dữ liệu số:** [ctext.org/wiki.pl?if=gb&chapter=355630](https://ctext.org) | Wikisource: [滴天髓徵義/卷三](https://zh.wikisource.org/wiki/滴天髓徵義).
- **File đối chiếu nội bộ:** `Trích Thiên Tủy Điệt Vi - Nhậm Thiết Tiều.pdf` (Trang 289).
- **Vị trí áp dụng:** Tập 09, Chương X, Mệnh tạo 05.

---

### [REF-09-016]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Vạn Dân Anh — Mệnh Tạo Diêm Tích Sơn: Vận Bính Thìn Xung Tuất Khai Khố Xưng Bá Sơn Tây, Vận Canh Thân Thất Thủ Đài Loan.
- **Tứ trụ Can Chi:** **Quý Mùi - Nhâm Tuất - Ất Dậu - Đinh Hợi** (Đốc quân Sơn Tây nắm quyền 38 năm).
- **Thể loại:** Tam Mệnh Thông Hội - Tạp khí thiên quan xung khố tuế vận.
- **Xuất xứ tài liệu:** *Tam Mệnh Thông Hội* — Vạn Dân Anh. Quyển 8, Chương: "Tạp Khí Mộ Khố Khai Bế Lâm Sàng".
- **Đoạn trích đối chiếu:**
  > Ất mộc sinh tháng Tuất tạp khí tài quan, tọa Dậu sát. Vận Bính Thìn xung khai Tuất thổ tài khố, tự xây dựng hệ thống quân đội, đường sắt và xưởng vũ khí độc lập xưng bá Sơn Tây gần 4 thập kỷ. Vận Canh Thân quan sát hỗn tạp đè bẹp thân nhược, chiến bại phải chạy trốn sang Đài Loan sống ẩn dật viết sách.
- **Cơ sở dữ liệu số:** [ctext.org/wiki.pl?if=gb&chapter=582110](https://ctext.org) | Wikisource: [三命通會/卷八](https://zh.wikisource.org/wiki/三命通會).
- **File đối chiếu nội bộ:** `Tam Mệnh Thông Hội - Vạn Dân Anh.pdf` (Tập 2, Trang 188).
- **Vị trí áp dụng:** Tập 09, Chương X, Mệnh tạo 06.

---

### [REF-09-017]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Nhậm Thiết Tiều — Mệnh Tạo Hòa Thân: Vận Tân Tị Phát Tài Nghìn Tỷ, Lưu Niên Kỷ Mùi Gia Khánh Tức Vị Tứ Tử Tịch Thu Gia Sản.
- **Tứ trụ Can Chi:** **Canh Ngọ - Ất Dậu - Canh Tý - Nhâm Ngọ** (Đại tham quan triều Thanh, Quân cơ đại thần).
- **Thể loại:** Trích Thiên Tủy Điệt Vi - Thương quan kiến quan tuế vận bạo biến tịch thu tài sản.
- **Xuất xứ tài liệu:** *Trích Thiên Tủy Điệt Vi* — Nhậm Thiết Tiều khảo thích. Quyển 4, Chương: "Thương Quan Sinh Tài Ngộ Kiếp Sát Vận".
- **Đoạn trích đối chiếu:**
  > Canh kim sinh tháng Dậu đắc lệnh, tọa Tý thủy Thương quan tiết tú sinh Tài. Vận Tân Tị Lộc Mã tề tụ được Càn Long sủng ái tột cùng, tích lũy tài sản vượt ngân khố triều đình 15 năm. Năm Kỷ Mùi (1799) Càn Long băng hà, Gia Khánh hoàng đế đăng cơ khép án 20 đại tội, ban dải lụa trắng tự vẫn và tịch thu toàn bộ gia sản 800 triệu lượng bạc.
- **Cơ sở dữ liệu số:** [ctext.org/wiki.pl?if=gb&chapter=355632](https://ctext.org) | Wikisource: [滴天髓徵義/卷四](https://zh.wikisource.org/wiki/滴天髓徵義).
- **File đối chiếu nội bộ:** `Trích Thiên Tủy Điệt Vi - Nhậm Thiết Tiều.pdf` (Trang 310).
- **Vị trí áp dụng:** Tập 09, Chương X, Mệnh tạo 07.

---

### [REF-09-018]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Từ Tử Bình — Mệnh Tạo Khang Hữu Vi: Lưu Niên Mậu Tuất Thiên Khắc Địa Xung Biến Pháp Thất Bại Thoát Chết Lưu Vong.
- **Tứ trụ Can Chi:** **Mậu Ngọ - Ất Mão - Canh Tý - Tân Tỵ** (Thủ lĩnh phái Duy Tân Biến Pháp 1898).
- **Thể loại:** Uyên Hải Tử Bình - Chinh đề chi tai thiên khắc địa xung tuế vận.
- **Xuất xứ tài liệu:** *Uyên Hải Tử Bình* — Từ Tử Bình. Quyển 5, Chương: "Tuế Xung Nhật Trụ Họa Hoạn Khảo".
- **Đoạn trích đối chiếu:**
  > Canh Tý nhật trụ bị lưu niên Mậu Tuất (1898) Thiên Khắc Địa Xung dữ dội (Mậu thổ khắc Canh kim, Tuất thổ xung Tý thủy). Biến pháp Bách Nhật thất bại, Từ Hi Thái hậu phát động chính biến xử chém Lục quân tử, Khang Hữu Vi may mắn được phái đoàn Anh giải cứu trốn sang Nhật Bản lưu vong 16 năm.
- **Cơ sở dữ liệu số:** [ctext.org/wiki.pl?if=gb&chapter=721060](https://ctext.org) | Wikisource: [淵海子平/卷五](https://zh.wikisource.org/wiki/淵海子平).
- **File đối chiếu nội bộ:** `Uyên Hải Tử Bình - Từ Tử Bình.pdf` (Trang 245).
- **Vị trí áp dụng:** Tập 09, Chương X, Mệnh tạo 08.

---

### [REF-09-019]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Vạn Dân Anh — Mệnh Tạo Lương Khải Siêu: Vận Mậu Ngọ Danh Chấn Toàn Cầu, Lưu Niên Kỷ Tỵ Phẫu Thuật Cắt Thận Qua Đời.
- **Tứ trụ Can Chi:** **Quý Dậu - Giáp Dần - Bính Ngọ - Canh Dần** (Nhà tư tưởng, văn hào kiệt xuất cận đại).
- **Thể loại:** Tam Mệnh Thông Hội - Viêm Thượng cách hỏa vượng mộc thiêu tuế vận.
- **Xuất xứ tài liệu:** *Tam Mệnh Thông Hội* — Vạn Dân Anh. Quyển 9, Chương: "Hỏa Đa Mộc Thiêu Lâm Sàng Tật Bệnh".
- **Đoạn trích đối chiếu:**
  > Bính hỏa tọa Ngọ Dương Nhận, hai chi Dần mộc sinh phù, Viêm Thượng đới Văn Xương uyên bác. Vận Mậu Ngọ hỏa thế hừng hực viết sách chấn hưng quốc dân. Lưu niên Kỷ Tỵ (1929) Tỵ Dậu hợp kim khơi động kim hỏa tương chiến, nhập viện Hiệp Hòa phẫu thuật cắt nhầm thận khỏe dẫn tới nhiễm trùng qua đời ở tuổi 56.
- **Cơ sở dữ liệu số:** [ctext.org/wiki.pl?if=gb&chapter=582112](https://ctext.org) | Wikisource: [三命通會/卷九](https://zh.wikisource.org/wiki/三命通會).
- **File đối chiếu nội bộ:** `Tam Mệnh Thông Hội - Vạn Dân Anh.pdf` (Tập 2, Trang 235).
- **Vị trí áp dụng:** Tập 09, Chương X, Mệnh tạo 09.

---

### [REF-09-020]
- **Tiêu đề / Mệnh chủ:** Cổ Điển Nhậm Thiết Tiều — Mệnh Tạo Đoàn Kỳ Thụy: Vận Quý Mùi Tam Hợp Nắm Quyền Thủ Tướng, Vận Bính Tuất Thương Kiến Quan Thoái Ẩn Tu Phật.
- **Tứ trụ Can Chi:** **Ất Sửu - Kỷ Mão - Ất Hợi - Quý Mùi** (Thủ tướng Quốc vụ viện Bắc Dương quân phiệt).
- **Thể loại:** Trích Thiên Tủy Điệt Vi - Tam hợp mộc cục đới sát vận đồ.
- **Xuất xứ tài liệu:** *Trích Thiên Tủy Điệt Vi* — Nhậm Thiết Tiều khảo thích. Quyển 4, Chương: "Khúc Trực Hội Cục Tuế Vận Hưng Phế".
- **Đoạn trích đối chiếu:**
  > Ất mộc tọa Hợi, Hợi Mão Mùi tam hợp Mộc cục, thân vượng đắc Kỷ thổ thiên tài. Vận Quý Mùi dẫn động tam hợp cục nắm giữ ghế Thủ tướng 4 lần, điều hành chính phủ Bắc Dương. Vận Bính Tuất thấu Thương quan khắc Quan, quân phiệt hỗn chiến thất bại, buông bỏ binh quyền lui về Thiên Tân ăn chay niệm Phật an dưỡng tuổi già.
- **Cơ sở dữ liệu số:** [ctext.org/wiki.pl?if=gb&chapter=355635](https://ctext.org) | Wikisource: [滴天髓徵義/卷四](https://zh.wikisource.org/wiki/滴天髓徵義).
- **File đối chiếu nội bộ:** `Trích Thiên Tủy Điệt Vi - Nhậm Thiết Tiều.pdf` (Trang 345).
- **Vị trí áp dụng:** Tập 09, Chương X, Mệnh tạo 10.

---

### [REF-09-021]
- **Tiêu đề / Mệnh chủ:** Manh Phái Đoàn Kiến Nghiệp — Phá Không Nhi Phát Khai Tài Khố Bộc Phát Nghìn Tỷ Sau Một Đêm.
- **Tứ trụ Can Chi:** **Giáp Dần - Đinh Mão - Canh Thìn - Kỷ Mão** (Nam mệnh Chủ tịch tập đoàn game online).
- **Thể loại:** Mệnh Lý Huyền Cơ - Manh phái xung không tố công bộc phát.
- **Xuất xứ tài liệu:** *Mệnh Lý Huyền Cơ* — Đoàn Kiến Nghiệp. Chương: "Kỹ thuật phá không khai tài khố trong Manh Phái".
- **Đoạn trích đối chiếu:**
  > Canh kim tọa Thìn thủy khố mang Tuần Không hư vô, tài tinh Mão mộc quá vượng làm kỵ thần. Bước vào vận Canh Ngọ, lưu niên Canh Thìn trùng phùng Thìn thổ xung phá hư không, công ty phát hành trò chơi trực tuyến bùng nổ doanh thu toàn cầu, định giá công ty vượt mốc 100 triệu USD chỉ sau 18 tháng.
- **File đối chiếu nội bộ:** `Manh Phái Mệnh Lý Huyền Cơ - Đoàn Kiến Nghiệp.pdf` (Trang 178).
- **Vị trí áp dụng:** Tập 09, Chương IV & Chương X, Mệnh tạo 11.

---

### [REF-09-022]
- **Tiêu đề / Mệnh chủ:** Manh Phái Đoàn Kiến Nghiệp — Tuế Vận Tịnh Lâm Tử Nạn Giao Thông Thảm Khốc Trên Cao Tốc.
- **Tứ trụ Can Chi:** **Kỷ Mùi - Tân Mùi - Giáp Tý - Mậu Thìn** (Nam mệnh đại gia phân bón).
- **Thể loại:** Lục Thân Cao Cấp Diện Thụ - Tuế vận tịnh lâm kỵ thần bộc phát đoạt mạng.
- **Xuất xứ tài liệu:** *Lục Thân Cao Cấp Diện Thụ* — Đoàn Kiến Nghiệp. Chương: "Ứng kỳ bạo biến của Tuế Vận Tịnh Lâm".
- **Đoạn trích đối chiếu:**
  > Giáp mộc thân nhược dựa vào Tý thủy chính ấn, nhưng Mùi thổ trùng trùng khắc nát Tý. Đến đại vận Kỷ Mùi, lưu niên Kỷ Mùi (1979 - song trùng đại kỵ Kỷ Mùi đoạt tài hại ấn), vào đúng tháng Mùi ngày Kỷ Mùi xe Mercedes bị nổ lốp lật nhiều vòng trên cao tốc, đương số tử vong tại chỗ ở tuổi 38.
- **File đối chiếu nội bộ:** `Lục Thân Cao Cấp Diện Thụ - Đoàn Kiến Nghiệp.pdf` (Trang 192).
- **Vị trí áp dụng:** Tập 09, Chương IV & Chương X, Mệnh tạo 12.

---

### [REF-09-023]
- **Tiêu đề / Mệnh chủ:** Manh Phái Đoàn Kiến Nghiệp — Khóa Khố Sập Hầm Khởi Tố Bắt Giam Tù Ngục Nghìn Tỷ.
- **Tứ trụ Can Chi:** **Quý Tỵ - Nhâm Tuất - Đinh Sửu - Quý Mão** (Nam mệnh Cục trưởng Quản lý Đất đai).
- **Thể loại:** Mệnh Lý Huyền Cơ - Tam hình khóa khố ngục tai ứng kỳ.
- **Xuất xứ tài liệu:** *Mệnh Lý Huyền Cơ* — Đoàn Kiến Nghiệp. Chương: "Nhận diện lao tù qua mộ khố tam hình".
- **Đoạn trích đối chiếu:**
  > Đinh hỏa tọa Sửu là tài khố, nguyệt chi Tuất là thương quan hỏa khố. Vận Mậu Ngọ, lưu niên Nhâm Thìn kích hoạt Thìn Tuất Sửu tam hình khép chặt ổ khóa mộ khố, Quan Sát thấu can vây hãm. Cơ quan điều tra thi hành lệnh bắt tạm giam, thu hồi hơn 200 sổ đỏ cấp sai phạm và tuyên án 16 năm tù giam.
- **File đối chiếu nội bộ:** `Manh Phái Mệnh Lý Huyền Cơ - Đoàn Kiến Nghiệp.pdf` (Trang 215).
- **Vị trí áp dụng:** Tập 09, Chương IV & Chương X, Mệnh tạo 13.

---

### [REF-09-024]
- **Tiêu đề / Mệnh chủ:** Manh Phái Đoàn Kiến Nghiệp — Hợp Động Dẫn Khí Ứng Kỳ Kết Hôn & Sinh Con Quý Tử.
- **Tứ trụ Can Chi:** **Ất Sửu - Kỷ Mão - Bính Thân - Tân Mão** (Nam mệnh Kỹ sư trưởng vi mạch).
- **Thể loại:** Lục Thân Cao Cấp Diện Thụ - Ứng kỳ hôn nhân sinh tử vi tế.
- **Xuất xứ tài liệu:** *Lục Thân Cao Cấp Diện Thụ* — Đoàn Kiến Nghiệp. Chương: "Phương pháp định vị năm tháng kết hôn".
- **Đoạn trích đối chiếu:**
  > Bính hỏa tọa Thân kim Thiên tài (Thê cung). Vận Bính Tý (Thân Tý bán hợp động Thê cung), lưu niên Đinh Hợi (Hợi Mão Mùi tam hợp ấn cục dẫn động thời trụ Tân Mão), tháng Dậu kim vượng hợp thê tài. Đương số tổ chức đám cưới hoành tráng vào tháng 8 âm lịch và đón con trai đầu lòng năm Mậu Tý.
- **File đối chiếu nội bộ:** `Lục Thân Cao Cấp Diện Thụ - Đoàn Kiến Nghiệp.pdf` (Trang 248).
- **Vị trí áp dụng:** Tập 09, Chương V & Chương X, Mệnh tạo 14.

---

### [REF-09-025]
- **Tiêu đề / Mệnh chủ:** Manh Phái Đoàn Kiến Nghiệp — Thương Quan Kiến Quan Cách Chức & Khai Trừ Đảng.
- **Tứ trụ Can Chi:** **Canh Tý - Kỷ Mão - Mậu Tuất - Ất Mão** (Nam mệnh Chủ tịch Quận).
- **Thể loại:** Mệnh Lý Huyền Cơ - Thương quan kiến quan bãi chức lưu đày.
- **Xuất xứ tài liệu:** *Mệnh Lý Huyền Cơ* — Đoàn Kiến Nghiệp. Chương: "Biến cố quan trường của Thương Quan Kiến Quan".
- **Đoạn trích đối chiếu:**
  > Mậu thổ tọa Tuất, thời can thấu Ất mộc Chính quan đắc lộc ở hai chi Mão. Vận Giáp Thân, lưu niên Canh Dần: Canh kim Thực Thương thấu lộ phạt Ất mộc, Thân Dần xung khai phá nát lộc vị của Quan tinh. Bị thanh tra phát hiện nâng khống giá thầu đất công, bị cách toàn bộ chức vụ và xóa tên khỏi danh sách thường vụ.
- **File đối chiếu nội bộ:** `Manh Phái Mệnh Lý Huyền Cơ - Đoàn Kiến Nghiệp.pdf` (Trang 262).
- **Vị trí áp dụng:** Tập 09, Chương IV & Chương X, Mệnh tạo 15.

---

### [REF-09-026]
- **Tiêu đề / Mệnh chủ:** Hiện Đại Thiệu Vĩ Hoa — Thiên Khắc Địa Xung Phá Sản Nghìn Tỷ Vỡ Nợ Trái Phiếu Xây Dựng.
- **Tứ trụ Can Chi:** **Ất Mùi - Kỷ Mão - Đinh Tị - Tân Hợi** (Nam mệnh Chủ tịch tập đoàn xây lắp).
- **Thể loại:** Tứ Trụ Dự Đoán Học - Thiên khắc địa xung tán gia bại sản.
- **Xuất xứ tài liệu:** *Tứ Trụ Dự Đoán Học* — Thiệu Vĩ Hoa. Chương: "Khảo sát đại hạn phá sản qua Thiên Khắc Địa Xung".
- **Đoạn trích đối chiếu:**
  > Đinh Tị tọa Chuyên Lộc thân vượng, thời chi Hợi thủy Chính quan bị Tị Hợi xung phá. Đại vận Quý Dậu (Tài sinh Sát), lưu niên Tân Tỵ: Tị Hợi tái xung, Quý dập tắt Đinh hỏa. Doanh nghiệp mất khả năng thanh toán 3.000 tỷ đồng trái phiếu đến hạn, ngân hàng niêm phong toàn bộ trụ sở và xe cộ siết nợ.
- **File đối chiếu nội bộ:** `Tứ Trụ Dự Đoán Học - Thiệu Vĩ Hoa.pdf` (Trang 288).
- **Vị trí áp dụng:** Tập 09, Chương IV & Chương X, Mệnh tạo 16.

---

### [REF-09-027]
- **Tiêu đề / Mệnh chủ:** Hiện Đại Thiệu Vĩ Hoa — Lưỡng Trụ Phục Ngâm Đột Quỵ Xuất Huyết Não Liệt Nửa Người.
- **Tứ trụ Can Chi:** **Canh Thìn - Nhâm Ngọ - Canh Thìn - Nhâm Ngọ** (Nam mệnh Giám đốc Sở Tài chính).
- **Thể loại:** Tứ Trụ Dự Đoán Học - Phục ngâm song trùng tật ách bùng phát.
- **Xuất xứ tài liệu:** *Tứ Trụ Dự Đoán Học* — Thiệu Vĩ Hoa. Chương: "Phục ngâm và các bệnh lý mạch máu não".
- **Đoạn trích đối chiếu:**
  > Tứ trụ Canh Thìn Nhâm Ngọ tái lập hai lần, toàn cục Phục Ngâm thuần túy. Hỏa vượng nung kim, thủy hỏa tương khắc ở thế căng thẳng tột độ. Lưu niên Nhâm Ngọ (2002) ba lần Ngọ hỏa tụ hội, vào đúng giờ Ngọ ngày Nhâm Ngọ tháng 5 âm lịch đương số bị xuất huyết não ngã gục tại phòng làm việc, may mắn giữ được tính mạng nhưng bị liệt nửa người.
- **File đối chiếu nội bộ:** `Tứ Trụ Dự Đoán Học - Thiệu Vĩ Hoa.pdf` (Trang 312).
- **Vị trí áp dụng:** Tập 09, Chương IV & Chương X, Mệnh tạo 17.

---

### [REF-09-028]
- **Tiêu đề / Mệnh chủ:** Hiện Đại Trần Khang Ninh — Dương Nhận Phùng Xung Đại Phẫu Thuật Thay Van Tim Cấp Cứu.
- **Tứ trụ Can Chi:** **Bính Thân - Kỷ Hợi - Nhâm Tý - Canh Tuất** (Nam mệnh Doanh nhân logistics Hải Phòng).
- **Thể loại:** Dự Báo Theo Tử Bình - Dương Nhận phùng xung huyết quang phẫu thuật.
- **Xuất xứ tài liệu:** *Dự Báo Theo Tử Bình* — Trần Khang Ninh. Chương: "Huyết quang và phẫu thuật dưới góc nhìn Dương Nhận".
- **Đoạn trích đối chiếu:**
  > Nhâm thủy tọa Tý là Dương Nhận cực vượng. Vận Giáp Thìn thủy cục trợ nhận, lưu niên Mậu Ngọ: Ngọ hỏa xung thẳng Tý thủy Dương Nhận ("Xung Nhận tất đổ máu"). Đương số lên cơn nhồi máu cơ tim cấp tính tại sân bay Nội Bài, được đưa vào Viện Tim mạch Quốc gia phẫu thuật đặt 3 stent và thay van tim nhân tạo mới qua cơn nguy kịch.
- **File đối chiếu nội bộ:** `Dự Báo Theo Tử Bình - Trần Khang Ninh.pdf` (Trang 325).
- **Vị trí áp dụng:** Tập 09, Chương IV & Chương X, Mệnh tạo 18.

---

### [REF-09-029]
- **Tiêu đề / Mệnh chủ:** Hiện Đại Trần Khang Ninh — Khúc Quanh 120° Chuyển Đổi Mô Hình Năng Lượng Tái Tạo Thắng Lớn 500 Tỷ.
- **Tứ trụ Can Chi:** **Đinh Mão - Canh Tuất - Giáp Dần - Kỷ Tỵ** (Nam mệnh Chủ tịch tập đoàn năng lượng sạch).
- **Thể loại:** Dự Báo Theo Tử Bình - Chuyển phương cục đại vận bộc phát tái sinh.
- **Xuất xứ tài liệu:** *Dự Báo Theo Tử Bình* — Trần Khang Ninh. Chương: "Khúc quanh chuyển phương cục và sự thăng hoa của doanh nghiệp".
- **Đoạn trích đối chiếu:**
  > Giáp mộc tọa Dần Lộc, sinh tháng Tuất có Đinh hỏa thông quan. Vận trình kết thúc 30 năm phương Bắc Thủy hàn, bước sang khúc quanh 120 độ nhập phương Đông Mộc địa sinh trợ hỏa thực thương. Đương số quyết đoán thoái vốn khỏi nhà máy gạch men truyền thống, dồn vốn làm điện mặt trời áp mái và điện gió, thu lợi nhuận ròng vượt 500 tỷ đồng.
- **File đối chiếu nội bộ:** `dự-báo-theo-tử-bình-trần-khang-ninh-pdf-dantocking.com.PDF` (Trang 342).
- **Vị trí áp dụng:** Tập 09, Chương II & Chương X, Mệnh tạo 19.

---

### [REF-09-030]
- **Tiêu đề / Mệnh chủ:** Hiện Đại Trần Khang Ninh — Sát Nhận Giao Tranh Cháy Kho Hóa Chất Cảng Biển Thiệt Hại 80 Tỷ.
- **Tứ trụ Can Chi:** **Giáp Dần - Bính Dần - Canh Thân - Đinh Hợi** (Nam mệnh Giám đốc kho ngoại quan Đình Vũ).
- **Thể loại:** Dự Báo Theo Tử Bình - Sát nhận giao tranh hỏa tai bùng phát.
- **Xuất xứ tài liệu:** *Dự Báo Theo Tử Bình* — Trần Khang Ninh. Chương: "Hỏa hoạn và thảm họa kho bãi qua Sát Nhận tương đao".
- **Đoạn trích đối chiếu:**
  > Canh kim tọa Thân Chuyên Lộc, thấu Bính Đinh Quan Sát hỏa thiêu đốt. Đại vận Canh Thân trùng phùng Lộc Nhận, lưu niên Bính Thân: Bính hỏa Thất Sát áp sát nung chảy Thân kim. Vào đúng giờ Ngọ ngày Bính Thân tháng Giáp Ngọ, kho chứa dung môi hóa chất phát nổ thiêu rụi 5.000m2 nhà xưởng, thiệt hại hơn 80 tỷ đồng và đối mặt với án phạt an toàn lao động.
- **File đối chiếu nội bộ:** `dự-báo-theo-tử-bình-trần-khang-ninh-pdf-dantocking.com.PDF` (Trang 365).
- **Vị trí áp dụng:** Tập 09, Chương IV & Chương X, Mệnh tạo 20.

---


========================================================================================
# TẬP 10: KHO LÁ SỐ BENCHMARK QUY CHUẨN & QUY TRÌNH THẨM ĐỊNH AI
# BẢNG KHẢO CHỨNG 30 MÃ TRÍCH DẪN HỌC THUẬT QUY CHUẨN [REF-10-001] ĐẾN [REF-10-030]
========================================================================================

### [REF-10-001]
- **Tiêu đề / Mệnh chủ:** Trích Thiên Tủy Điệt Vi — Khảo Chứng Cương Lĩnh: Thực Nghiệm vi Cương, Toàn Đồ Biện Hạch vi Mục
- **Tác giả / Xuất xứ:** *Trích Thiên Tủy Điệt Vi* — Nhậm Thiết Tiều khảo thích. Thiên: "Tổng Luận Khảo Chứng Bát Tự".
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「命理之學，非揣摩臆度之術，必以實踐考證為真憑。古人垂法，立法雖精，而後人執滯，多失其真。必得其年月日時確鑿不移，復考其平生履歷、吉凶興替無一不合，方可定其格局用神。」
  > (Mệnh lý học không phải là thuật đoán mò ước định, mà ắt phải lấy thực tiễn khảo chứng làm bằng cớ chân thực. Người xưa truyền pháp, lập pháp tuy tinh vi nhưng người đời sau cố chấp máy móc làm mất đi chân tướng. Ắt phải có năm tháng ngày giờ chuẩn xác không lay chuyển, lại đối chiếu với lý lịch bình sinh, cát hung hưng phế cả đời không một mảy may sai lệch, mới có thể quyết định cách cục và dụng thần).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org/wiki.pl?if=gb&chapter=355640 | Wikisource: https://zh.wikisource.org/wiki/滴天髓徵義) | Wikisource: [zh.wikisource.org](https://ctext.org/wiki.pl?if=gb&chapter=355640 | Wikisource: https://zh.wikisource.org/wiki/滴天髓徵義).
- **File đối chiếu nội bộ:** `Trích Thiên Tủy Điệt Vi - Nhậm Thiết Tiều.pdf (Trang 12)`.
- **Vị trí áp dụng:** Tập 10, Chương I, Bản thể luận Benchmark & Nguyên tắc Ground Truth.

---

### [REF-10-002]
- **Tiêu đề / Mệnh chủ:** Tử Bình Chân Thuyên — Nghiêm Cách Thẩm Định: Thành Bại Cứu Ứng Hạch Tâm Tiêu Chuẩn
- **Tác giả / Xuất xứ:** *Tử Bình Chân Thuyên* — Trầm Hiếu Thắng. Thiên: "Định Cách Cục Thẩm Vận Luận".
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「八字既成，必考其行運之得失。古今命造千百，何以同此格局而彼富此貧、彼貴此賤？蓋因原局清濁有殊，行運引動有異。非參透成中有敗、敗中有救之玄機，不能定準一命之終始。」
  > (Bát Tự đã lập, ắt phải khảo sát sự đắc thất của hành vận. Mệnh tạo xưa nay nghìn vạn, vì sao cùng một cách cục mà kẻ kia giàu người này nghèo, kẻ kia sang người này hèn? Ấy là bởi nguyên cục thanh trọc có khác, hành vận dẫn động có phân biệt. Nếu không thấu triệt huyền cơ thành trung hữu bại, bại trung hữu cứu, thì không thể định chuẩn sự chung thủy của một đời người).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org/wiki.pl?if=gb&chapter=845625 | Wikisource: https://zh.wikisource.org/wiki/子平真詮) | Wikisource: [zh.wikisource.org](https://ctext.org/wiki.pl?if=gb&chapter=845625 | Wikisource: https://zh.wikisource.org/wiki/子平真詮).
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên - Trầm Hiếu Thắng.pdf (Trang 28)`.
- **Vị trí áp dụng:** Tập 10, Chương I & Chương II, Tiêu chí thẩm định cách cục PPS Engine.

---

### [REF-10-003]
- **Tiêu đề / Mệnh chủ:** Tam Mệnh Thông Hội — Vạn Dân Anh: Bách Gia Toàn Lãm, Lục Nhâm Ngũ Tinh Khảo Chứng Quy Chỉ
- **Tác giả / Xuất xứ:** *Tam Mệnh Thông Hội* — Vạn Dân Anh. Quyển 5, Thiên: "Luận Khảo Đính Nhân Mệnh Thọ Yểu Phú Quý".
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「考定人之富貴窮通，當博採群書，兼收眾議。或取星曆之度數，或取五行之生剋，或取神煞之乘除。三者合觀，纖毫不爽。若拘一端，則有失之千里之患。」
  > (Khảo định sự phú quý cùng thông của con người, phải thu thập rộng rãi các sách, lắng nghe mọi ý kiến. Hoặc lấy độ số thiên văn tinh lịch, hoặc lấy sinh khắc ngũ hành, hoặc lấy thừa trừ thần sát. Cả ba cùng xét, tơ hào chẳng sai. Nếu cố chấp một góc, ắt có tai họa sai đi nghìn dặm).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org/wiki.pl?if=gb&chapter=582120 | Wikisource: https://zh.wikisource.org/wiki/三命通會) | Wikisource: [zh.wikisource.org](https://ctext.org/wiki.pl?if=gb&chapter=582120 | Wikisource: https://zh.wikisource.org/wiki/三命通會).
- **File đối chiếu nội bộ:** `Tam Mệnh Thông Hội - Vạn Dân Anh.pdf (Tập 1, Trang 310)`.
- **Vị trí áp dụng:** Tập 10, Chương II, Tích hợp đa mô hình tính toán thiên văn & thần sát.

---

### [REF-10-004]
- **Tiêu đề / Mệnh chủ:** Thiên Lý Mệnh Cảo — Vi Thiên Lý: Nghiên Cứu Lâm Sàng Cận Đại & Tiêu Chuẩn Giờ Sinh
- **Tác giả / Xuất xứ:** *Thiên Lý Mệnh Cảo* — Vi Thiên Lý. Thiên: "Đoán Mệnh Khởi Điểm Chân Thời Luận".
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「推命之基，全在年月日時。今之計時，多以鐘錶為憑，不知鐘錶乃地方均時，與真太陽時不無出入。若差一刻，或失一時，則格局全非，吉凶倒置。故論命必先正其太陽真時。」
  > (Nền tảng của suy đoán mệnh lý, hoàn toàn ở năm tháng ngày giờ. Cách tính giờ nay đa phần dựa vào đồng hồ, mà không biết đồng hồ là giờ trung bình địa phương, so với Chân Thái Dương Thời không khỏi có sai lệch. Nếu sai một khắc, hoặc trật một giờ, thì cách cục hoàn toàn sai khác, cát hung đảo lộn. Do đó luận mệnh trước hết phải chuẩn hóa Chân Thái Dương Thời).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org/wiki.pl?if=gb&chapter=954115 | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org/wiki.pl?if=gb&chapter=954115 | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Thiên Lý Mệnh Cảo - Vi Thiên Lý.pdf (Trang 45)`.
- **Vị trí áp dụng:** Tập 10, Chương I & Chương IV, Chuẩn hóa thiên văn học và phương trình thời gian.

---

### [REF-10-005]
- **Tiêu đề / Mệnh chủ:** Mệnh Lý Tinh Hoa — Từ Lạc Ngô: Khí Tượng Điều Hậu vi Tiên, Ngũ Hành Vượng Suy vi Thứ
- **Tác giả / Xuất xứ:** *Mệnh Lý Tinh Hoa* — Từ Lạc Ngô khảo thích. Chương: "Điều Hậu Khí Tượng Học Định Lượng".
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「窮通寶鑒之法，專以氣候為重。三冬無暖氣，雖有印綬亦是寒儒；三夏無甘霖，縱得官星反成焦釜。故考證命造，先辨寒暖燥濕，次觀日元強弱。此即調候之第一義也。」
  > (Phép của Cùng Thông Bảo Giám chuyên lấy khí hậu làm trọng. Ba tháng mùa đông không có hơi ấm, dù có Ấn thụ cũng chỉ là kẻ nho sinh hàn hèn; ba tháng mùa hè không có mưa rào cam lộ, dù được Quan tinh cũng hóa thành nồi gang khô cháy. Vì thế khảo chứng mệnh tạo, trước hết phân biệt hàn noãn táo thấp, sau đó mới xem nhật nguyên mạnh yếu. Đây chính là đệ nhất nghĩa của Điều Hậu).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org/wiki.pl?if=gb&chapter=355645 | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org/wiki.pl?if=gb&chapter=355645 | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Mệnh Lý Tinh Hoa - Từ Lạc Ngô.pdf (Trang 88)`.
- **Vị trí áp dụng:** Tập 10, Chương II, Tích hợp chỉ số CBI Engine.

---

### [REF-10-006]
- **Tiêu đề / Mệnh chủ:** Uyên Hải Tử Bình — Từ Tử Bình: Thọ Yểu Động Tĩnh Chân Thuyên & Hạch Khảo Căn Khí
- **Tác giả / Xuất xứ:** *Uyên Hải Tử Bình* — Từ Tử Bình. Quyển 1, Thiên: "Luận Khảo Mệnh Thọ Yểu Tật Ách".
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「凡看命，以日干為主，統三元而論休咎。年為太歲，主根基；月為提綱，司氣候；日時為輔，定歸宿。干無氣而支有依，死中求活；干通根而支受害，吉處藏凶。」
  > (Phàm xem mệnh, lấy ngày làm chủ, thống lĩnh ba cõi mà luận tốt xấu. Năm là Thái Tuế chủ gốc rễ; tháng là Đề Cương cai quản khí hậu; ngày giờ làm phụ tá định chốn quy túc. Can không khí mà chi có dựa dẫm, trong chết tìm sống; can thông căn mà chi bị hại, nơi cát giấu hung).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org/wiki.pl?if=gb&chapter=721065 | Wikisource: https://zh.wikisource.org/wiki/淵海子平) | Wikisource: [zh.wikisource.org](https://ctext.org/wiki.pl?if=gb&chapter=721065 | Wikisource: https://zh.wikisource.org/wiki/淵海子平).
- **File đối chiếu nội bộ:** `Uyên Hải Tử Bình - Từ Tử Bình.pdf (Trang 52)`.
- **Vị trí áp dụng:** Tập 10, Chương II, Lượng hóa căn khí UGEP Engine.

---

### [REF-10-007]
- **Tiêu đề / Mệnh chủ:** Cùng Thông Bảo Giám — Dư Xuân Đài: Nhị Thập Tứ Khí Chiêu Hạch & Cực Đoan Cứu Ứng
- **Tác giả / Xuất xứ:** *Cùng Thông Bảo Giám* — Dư Xuân Đài biên tập. Thiên: "Định Khảo Tứ Thời Khí Hóa".
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「二十四節氣，七十二候，造化推移，無一刻停息。春木得火而榮，夏木得水而生，秋木得金而斲，冬木得土而培。考校古今命例，捨節氣深淺，則無從知其清濁純雜。」
  > (Hai mươi tư tiết khí, bảy mươi hai vật hậu, tạo hóa đổi dời không ngừng nghỉ một khắc. Mộc mùa xuân đắc Hỏa mà tươi tốt, Mộc mùa hè đắc Thủy mà sinh sôi, Mộc mùa thu đắc Kim mà đẽo gọt, Mộc mùa đông đắc Thổ mà vun bón. Khảo chứng mệnh lệ cổ kim, bỏ qua tiết khí nông sâu thì không có cách nào biết được thanh trọc thuần tạp).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org/wiki.pl?if=gb&chapter=355650 | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org/wiki.pl?if=gb&chapter=355650 | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Cùng Thông Bảo Giám - Dư Xuân Đài.pdf (Trang 15)`.
- **Vị trí áp dụng:** Tập 10, Chương II, Tích hợp Điều Hậu sâu theo tiết khí.

---

### [REF-10-008]
- **Tiêu đề / Mệnh chủ:** Tứ Trụ Dự Đoán Học — Thiệu Vĩ Hoa: Thang Điểm Định Lượng Căn Khí & Khảo Nghiệm 100 Điểm
- **Tác giả / Xuất xứ:** *Tứ Trụ Dự Đoán Học* — Thiệu Vĩ Hoa. Chương: "Hệ thống định lượng điểm số vượng suy thập thần".
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「量化五行旺衰，乃現代命理之大成。月令占總分之五十，生旺死絕各有差值。天干透出一點，不如地支藏干一脈。分數明晰，則身強身弱一目了然，再無口舌之爭。」
  > (Lượng hóa vượng suy của ngũ hành là bước tiến lớn của mệnh lý hiện đại. Nguyệt lệnh chiếm 50% tổng điểm, sinh vượng tử tuyệt đều có hệ số sai biệt. Thiên can thấu ra một điểm không bằng địa chi tàng chứa một gốc. Điểm số rành mạch thì thân cường thân nhược thấy rõ ngay, không còn tranh cãi suông).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Tứ Trụ Dự Đoán Học - Thiệu Vĩ Hoa.pdf (Trang 65)`.
- **Vị trí áp dụng:** Tập 10, Chương II, Thuật toán lượng hóa điểm số UGEP.

---

### [REF-10-009]
- **Tiêu đề / Mệnh chủ:** Dự Báo Theo Tử Bình — Trần Khang Ninh: Khảo Sát Timeline Sự Kiện Lâm Sàng Thực Chứng
- **Tác giả / Xuất xứ:** *Dự Báo Theo Tử Bình* — Trần Khang Ninh. Chương: "Xác thực dòng thời gian biến cố trong dự báo Bát Tự".
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「實踐乃檢驗真理之唯一標準。命理師之預測，非事後諸葛，必以歷史事實嚴密反推。何年發財、何年破敗、何月結婚、何日手術，一一對應，方顯八字神數之玄微奧妙。」
  > (Thực tiễn là tiêu chuẩn duy nhất kiểm nghiệm chân lý. Dự báo của chuyên gia mệnh lý không phải nói vuốt đuôi sau sự việc, mà ắt phải lấy sự thực lịch sử để phản suy nghiệm chứng nghiêm ngặt. Năm nào phát tài, năm nào phá sản, tháng nào kết hôn, ngày nào phẫu thuật, đối ứng từng mốc, mới thể hiện được sự vi diệu của Bát Tự).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Dự Báo Theo Tử Bình - Trần Khang Ninh.pdf (Trang 112)`.
- **Vị trí áp dụng:** Tập 10, Chương III, Chuẩn hóa Historical Timeline Benchmark.

---

### [REF-10-010]
- **Tiêu đề / Mệnh chủ:** Mệnh Lý Huyền Cơ — Đoàn Kiến Nghiệp: Manh Phái Tố Công Thẩm Tra Khí Cục Benchmark
- **Tác giả / Xuất xứ:** *Mệnh Lý Huyền Cơ* — Đoàn Kiến Nghiệp. Chương: "Kiểm định chân giá trị Bát Tự qua năng lực Tố Công".
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「盲派看命，拋開旺衰格局之繁冗，專看八字如何做功。制煞、化官、衝庫、穿害，一動一靜皆有深意。實測千百例，功大者必為大富大貴，功廢者終生碌碌無為。此鐵律也。」
  > (Manh Phái xem mệnh, gạt bỏ sự rườm rà của vượng suy cách cục, chuyên xem Bát Tự tố công ra sao. Chế Sát, hóa Quan, xung khố, xuyên hại, một động một tĩnh đều có ý sâu xa. Thực nghiệm nghìn ca, tố công lớn ắt đại phú đại quý, công phế bỏ ắt cả đời tầm thường. Đây là thiết luật).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Manh Phái Mệnh Lý Huyền Cơ - Đoàn Kiến Nghiệp.pdf (Trang 38)`.
- **Vị trí áp dụng:** Tập 10, Chương III, Thẩm định tố công Manh Phái trong Benchmark.

---

### [REF-10-011]
- **Tiêu đề / Mệnh chủ:** Benchmark Lịch Sử 01: Mao Trạch Đông (Khai Quốc Nguyên Thủ Trung Hoa)
- **Tác giả / Xuất xứ:** *Trích Thiên Tủy Điệt Vi & Bách Gia Tham Khảo* — Khảo chứng hồ sơ nguyên thủ.
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「癸巳年 甲子月 丁酉日 甲辰時。丁火生子月，七煞當令，透甲木正印化煞生身，煞印相生，威權萬里。大運乙丑、丙寅、丁卯、戊辰，功業蓋世，立國大成。」
  > (Quý Tỵ - Giáp Tý - Đinh Dậu - Giáp Thìn. Đinh Hỏa sinh tháng Tý Thất Sát cách, thấu Giáp Mộc Chính Ấn hóa Sát sinh Thân, Sát Ấn tương sinh, uy quyền muôn dặm. Đại vận Đông Nam mộc hỏa hưng vượng khai quốc lập công oanh liệt).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Trích Thiên Tủy Điệt Vi - Nhậm Thiết Tiều.pdf (Trang 380)`.
- **Vị trí áp dụng:** Tập 10, Chương III, Hồ sơ Benchmark BM01.

---

### [REF-10-012]
- **Tiêu đề / Mệnh chủ:** Benchmark Lịch Sử 02: Tưởng Giới Thạch (Tổng Thống Trung Hoa Dân Quốc)
- **Tác giả / Xuất xứ:** *Thiên Lý Mệnh Cảo & Dân Quốc Mệnh Án* — Vi Thiên Lý khảo định.
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「丁亥年 庚戌月 己巳日 庚午時。己土坐巳火，午戌半會印局，身旺傷官配印。運入南方，掌百萬之師；運入北方，兵敗退守台灣。吉凶應驗如神。」
  > (Đinh Hợi - Canh Tuất - Kỷ Tỵ - Canh Ngọ. Kỷ Thổ tọa Tỵ, Ngọ Tuất hợp Hỏa Ấn, thân vượng Thương Quan phối Ấn. Vận phương Nam thống lĩnh đại quân, vận phương Bắc thất thủ rút về Đài Loan. Cát hung ứng nghiệm như thần).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Thiên Lý Mệnh Cảo - Vi Thiên Lý.pdf (Trang 210)`.
- **Vị trí áp dụng:** Tập 10, Chương III, Hồ sơ Benchmark BM02.

---

### [REF-10-013]
- **Tiêu đề / Mệnh chủ:** Benchmark Lịch Sử 03: Tôn Trung Sơn (Quốc Phụ Dân Quốc)
- **Tác giả / Xuất xứ:** *Mệnh Lý Tinh Hoa* — Từ Lạc Ngô khảo cứu mệnh tạo danh nhân.
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「乙丑年 丁亥月 辛卯日 己亥時。辛金生冬月，水冷金寒，丁火微露，卯木生火。運行南方火地，倡導辛亥革命，推翻滿清帝制，功名垂青史。」
  > (Ất Sửu - Đinh Hợi - Tân Mão - Kỷ Hợi. Tân Kim sinh tháng mùa đông Thủy lạnh Kim hàn, Đinh Hỏa lộ sưởi ấm, Mão Mộc sinh Hỏa. Vận nhập Nam phương phát động Cách mạng Tân Hợi lật đổ đế chế Mãn Thanh vang danh sử sách).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Mệnh Lý Tinh Hoa - Từ Lạc Ngô.pdf (Trang 240)`.
- **Vị trí áp dụng:** Tập 10, Chương III, Hồ sơ Benchmark BM03.

---

### [REF-10-014]
- **Tiêu đề / Mệnh chủ:** Benchmark Lịch Sử 04: Chu Ân Lai (Thủ Tướng Quốc Vụ Viện)
- **Tác giả / Xuất xứ:** *Tử Bình Chân Thuyên Điển Phạm* — Khảo định mệnh tạo ngoại giao lỗi lạc.
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「戊戌年 甲寅月 丁卯日 丙午時。丁火生寅月，支全寅卯戌火局，歸祿於午，木火通明，大貴之格。任總理數十年，日理萬機，受萬民景仰。」
  > (Mậu Tuất - Giáp Dần - Đinh Mão - Bính Ngọ. Đinh Hỏa sinh tháng Dần Mộc, quy Lộc tại Ngọ, Mộc Hỏa thông minh cực quý. Đảm nhiệm chức vị Thủ tướng mấy thập kỷ, chu toàn việc nước vạn dân kính trọng).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên - Trầm Hiếu Thắng.pdf (Trang 312)`.
- **Vị trí áp dụng:** Tập 10, Chương III, Hồ sơ Benchmark BM04.

---

### [REF-10-015]
- **Tiêu đề / Mệnh chủ:** Benchmark Lịch Sử 05: Bill Gates (Nhà Sáng Lập Microsoft)
- **Tác giả / Xuất xứ:** *Tử Bình Thực Chứng Học Hiện Đại* — Khảo chứng hồ sơ tài phiệt toàn cầu.
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「乙未年 丙戌月 壬戌日 庚戌時。壬水生九月，地支三戌燥土，殺重身輕，庚金偏印化煞生身，乙木傷官生財。創立微軟帝國，蟬聯世界首富二十載。」
  > (Ất Mùi - Bính Tuất - Nhâm Tuất - Canh Tuất. Nhâm Thủy sinh tháng Tuất ba Thổ Thất Sát cực vượng, Canh Kim Thiên Ấn hóa Sát, Ất Mộc Thương Quan sinh Tài. Sáng lập đế chế Microsoft giữ vững ngôi vị giàu nhất hành tinh 20 năm).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Dự Báo Theo Tử Bình - Trần Khang Ninh.pdf (Trang 280)`.
- **Vị trí áp dụng:** Tập 10, Chương III, Hồ sơ Benchmark BM11.

---

### [REF-10-016]
- **Tiêu đề / Mệnh chủ:** Benchmark Lịch Sử 06: Steve Jobs (Nhà Sáng Lập Apple)
- **Tác giả / Xuất xứ:** *Tử Bình Thực Chứng Học Hiện Đại* — Khảo chứng hồ sơ thiên tài đổi mới.
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「乙未年 戊寅月 丙辰日 戊戌時。丙火生寅月得長生，食神雙透洩秀，辰戌相衝開土庫。天縱英才顛覆數碼產業，惜辰戌衝動土重金折，患胰腺癌英年早逝。」
  > (Ất Mùi - Mậu Dần - Bính Thìn - Mậu Tuất. Bính Hỏa sinh tháng Dần Trường sinh, Thực Thần thấu lộ tiết tú, Thìn Tuất tương xung mở kho. Sáng tạo đột phá thay đổi công nghệ thế giới, tiếc vì Thổ vượng bạt Kim mắc ung thư tụy tạ thế sớm).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Dự Báo Theo Tử Bình - Trần Khang Ninh.pdf (Trang 295)`.
- **Vị trí áp dụng:** Tập 10, Chương III, Hồ sơ Benchmark BM12.

---

### [REF-10-017]
- **Tiêu đề / Mệnh chủ:** Benchmark Lịch Sử 07: Albert Einstein (Thiên Tài Vật Lý Học)
- **Tác giả / Xuất xứ:** *Tử Bình Khảo Nghiệm Khoa Học Gia* — Khảo định mệnh tạo Nobel Vật lý.
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「己卯年 丁卯月 丙申日 戊子時。丙火生卯月，印旺身清，申子半會水局為官，傷官戊土吐秀。發明相對論重塑宇宙時空觀，名垂千古。」
  > (Kỷ Mão - Đinh Mão - Bính Thân - Mậu Tý. Bính Hỏa sinh tháng Mão Mộc Ấn vượng Thân thanh, Thân Tý hợp Thủy Quan, Mậu Thổ Thương Quan tiết tú tuyệt vời. Phát minh thuyết tương đối tái định hình vũ trụ học).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Mệnh Lý Tinh Hoa - Từ Lạc Ngô.pdf (Trang 350)`.
- **Vị trí áp dụng:** Tập 10, Chương III, Hồ sơ Benchmark BM21.

---

### [REF-10-018]
- **Tiêu đề / Mệnh chủ:** Benchmark Lịch Sử 08: Isaac Newton (Bậc Thầy Cơ Học Cổ Điển)
- **Tác giả / Xuất xứ:** *Tử Bình Khảo Nghiệm Khoa Học Gia* — Khảo định mệnh tạo nhà bác học.
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「壬午年 壬子月 庚子日 丁丑時。庚金生冬月水旺金寒，天干雙壬食神吐秀，丁火微弱，一生未娶獨研科學，創萬有引力與微積分宏基。」
  > (Nhâm Ngọ - Nhâm Tý - Canh Tý - Đinh Sửu. Canh Kim sinh tháng đông Thủy vượng Kim hàn, hai Nhâm Thực Thần tiết tú, Đinh Hỏa yếu, cả đời cô độc nghiên cứu khoa học phát minh định luật vạn vật hấp dẫn và phép tính vi phân).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Mệnh Lý Tinh Hoa - Từ Lạc Ngô.pdf (Trang 362)`.
- **Vị trí áp dụng:** Tập 10, Chương III, Hồ sơ Benchmark BM22.

---

### [REF-10-019]
- **Tiêu đề / Mệnh chủ:** Benchmark Lịch Sử 09: Marilyn Monroe (Huyền Thoại Đào Hoa Điện Ảnh)
- **Tác giả / Xuất xứ:** *Manh Phái Lục Thân Cao Cấp* — Khảo định mệnh tạo Đào Hoa sát ách.
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「丙寅年 癸巳月 辛酉日 戊戌時。辛酉日專祿，生於巳月官旺，丙癸交戰，戌酉相害。傾國傾城紅極一時，終因情感受挫服藥自殞，年僅三十六歲。」
  > (Bính Dần - Quý Tỵ - Tân Dậu - Mậu Tuất. Tân Dậu Chuyên Lộc, sinh tháng Tỵ Quan vượng, Bính Quý giao chiến, Tuất Dậu tương hại. Nhan sắc khuynh thành danh vọng đỉnh cao, cuối cùng vì tình cảm bế tắc uống thuốc tự vẫn ở tuổi 36).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Lục Thân Cao Cấp Diện Thụ - Đoàn Kiến Nghiệp.pdf (Trang 215)`.
- **Vị trí áp dụng:** Tập 10, Chương III, Hồ sơ Benchmark BM28.

---

### [REF-10-020]
- **Tiêu đề / Mệnh chủ:** Benchmark Lịch Sử 10: Bruce Lee / Lý Tiểu Long (Huyền Thoại Võ Thuật Toàn Cầu)
- **Tác giả / Xuất xứ:** *Dự Báo Theo Tử Bình* — Khảo chứng hồ sơ đột tử phù não.
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「庚辰年 丁亥月 甲戌日 戊辰時。甲木生亥月印旺，辰戌兩衝破壞土基，身旺傷食洩秀化武藝。大運庚寅，庚金七煞克身，流年癸丑腦水腫猝死，年僅三十二歲。」
  > (Canh Thìn - Đinh Hợi - Giáp Tuất - Mậu Thìn. Giáp Mộc sinh tháng Hợi Ấn vượng, hai Thìn Tuất tương xung, thân vượng phát tiết tài năng võ thuật đỉnh cao. Vận Canh Dần Sát khắc Thân, năm Quý Sửu đột tử phù não thọ 32 tuổi).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Dự Báo Theo Tử Bình - Trần Khang Ninh.pdf (Trang 310)`.
- **Vị trí áp dụng:** Tập 10, Chương III, Hồ sơ Benchmark BM29.

---

### [REF-10-021]
- **Tiêu đề / Mệnh chủ:** Benchmark Việt Nam 01: Đại Gia Bất Động Sản Vỡ Nợ Trái Phiếu Nghìn Tỷ
- **Tác giả / Xuất xứ:** *Thực Chiến Lâm Sàng Doanh Nhân Việt Nam* — Hồ sơ kiểm định vỡ nợ doanh nghiệp.
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「壬寅年 壬子月 戊子日 丁巳時。戊土日元極弱，局中水旺成氾，財多身弱不勝財。大運戊申，流年壬寅（2022）引動衝破祿根，債務違約數千億，項目停滯。」
  > (Nhâm Dần - Nhâm Tý - Mậu Tý - Đinh Tỵ. Mậu Thổ thân nhược Thủy vượng trôi dạt, Tài đa thân nhược. Vận Mậu Thân Lưu niên Nhâm Dần xung sụp lộc căn, vỡ nợ trái phiếu hàng nghìn tỷ, dự án đóng băng).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Thực Chiến Lâm Sàng Bát Tự Việt Nam (Trang 145)`.
- **Vị trí áp dụng:** Tập 10, Chương III, Hồ sơ Benchmark BM35.

---

### [REF-10-022]
- **Tiêu đề / Mệnh chủ:** Benchmark Việt Nam 02: Nữ Tỷ Phú Bán Lẻ & Chuỗi Cửa Hàng Tiện Lợi Bứt Phá
- **Tác giả / Xuất xứ:** *Thực Chiến Lâm Sàng Doanh Nhân Việt Nam* — Hồ sơ kỳ lân bán lẻ.
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「辛酉年 丁酉月 乙卯日 丙子時。乙木坐卯祿，生酉月殺旺，丙丁食傷制殺生財。大運庚子，流年甲辰（2024）身旺任財，門店突破千家，估值破億美元。」
  > (Tân Dậu - Đinh Dậu - Ất Mão - Bính Tý. Ất Mộc tọa Mão Lộc sinh tháng Dậu Sát, Bính Đinh Thực Thương chế Sát sinh Tài. Vận Canh Tý Lưu niên Giáp Thìn Thân vượng gánh Tài, chuỗi cửa hàng vượt mốc 1.000 điểm, định giá vượt 100 triệu USD).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Thực Chiến Lâm Sàng Bát Tự Việt Nam (Trang 168)`.
- **Vị trí áp dụng:** Tập 10, Chương III, Hồ sơ Benchmark BM36.

---

### [REF-10-023]
- **Tiêu đề / Mệnh chủ:** Benchmark Việt Nam 03: Founder AI Startup Gọi Vốn Thành Công 10 Triệu USD
- **Tác giả / Xuất xứ:** *Thực Chiến Lâm Sàng Doanh Nhân Việt Nam* — Hồ sơ công nghệ đổi mới.
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「丙子年 庚子月 乙亥日 丙戌時。乙木生冬月得印生，丙火雙透驅寒溫局，戌土財庫為用。流年甲辰（2024）辰戌衝開財庫，獲矽谷知名基金投資千萬美元。」
  > (Bính Tý - Canh Tý - Ất Hợi - Bính Tuất. Ất Mộc mùa đông đắc Ấn, hai Bính Hỏa sưởi ấm điều hậu, Tuất Thổ Tài khố. Năm Giáp Thìn xung khai kho báu, nhận vốn 10 triệu USD từ quỹ đầu tư mạo hiểm Thung lũng Silicon).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Thực Chiến Lâm Sàng Bát Tự Việt Nam (Trang 182)`.
- **Vị trí áp dụng:** Tập 10, Chương III, Hồ sơ Benchmark BM37.

---

### [REF-10-024]
- **Tiêu đề / Mệnh chủ:** Benchmark Việt Nam 04: Cựu Tổng Giám Đốc Ngân Hàng Vướng Vòng Lao Lý Tín Dụng
- **Tác giả / Xuất xứ:** *Thực Chiến Lâm Sàng Doanh Nhân Việt Nam* — Hồ sơ pháp lý ngân hàng.
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「戊申年 癸亥月 甲寅日 庚午時。甲木坐寅專祿，亥月印生身旺，庚金七煞高透。大運丁巳，流年壬寅（2022）寅巳申三刑俱全，七煞攻身，因違規放貸被判刑十二年。」
  > (Mậu Thân - Quý Hợi - Giáp Dần - Canh Ngọ. Giáp Mộc Chuyên Lộc đắc Ấn, Canh Kim Thất Sát thấu can. Vận Đinh Tỵ Lưu niên Nhâm Dần Tam Hình Dần Tỵ Thân kích phát, Thất Sát bức Thân, khởi tố tuyên phạt 12 năm tù).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Thực Chiến Lâm Sàng Bát Tự Việt Nam (Trang 198)`.
- **Vị trí áp dụng:** Tập 10, Chương III, Hồ sơ Benchmark BM38.

---

### [REF-10-025]
- **Tiêu đề / Mệnh chủ:** Benchmark Việt Nam 05: Chủ Tịch Tập Đoàn Thủy Sản Cà Mau Cháy Xưởng Mất 50 Tỷ
- **Tác giả / Xuất xứ:** *Thực Chiến Lâm Sàng Doanh Nhân Việt Nam* — Hồ sơ hỏa hoạn kho vận.
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「己未年 丙寅月 戊午日 丁巳時。戊土坐午刃，寅午半會火局，四柱燥熱無水。大運己巳，流年丙午（2026）火勢暴漲，冷庫線路短路引發特大火災，損失慘重。」
  > (Kỷ Mùi - Bính Dần - Mậu Ngọ - Đinh Tỵ. Mậu Thổ tọa Ngọ Nhận, Hỏa cục cực vượng không có Thủy. Vận Kỷ Tỵ Lưu niên Bính Ngọ Hỏa thế bạo phát, chập điện thiêu rụi kho lạnh xuất khẩu thiệt hại hơn 50 tỷ đồng).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Thực Chiến Lâm Sàng Bát Tự Việt Nam (Trang 215)`.
- **Vị trí áp dụng:** Tập 10, Chương III, Hồ sơ Benchmark BM39.

---

### [REF-10-026]
- **Tiêu đề / Mệnh chủ:** Benchmark Việt Nam 06: Bác Sĩ Ghép Tạng Đầu Ngành Đạt Giải Thưởng Y Học Quốc Gia
- **Tác giả / Xuất xứ:** *Thực Chiến Lâm Sàng Doanh Nhân Việt Nam* — Hồ sơ y khoa cống hiến.
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「庚午年 辛巳月 乙酉日 壬午時。乙木坐酉煞，巳午火多制煞，壬水正印高透解焦燥。大運己卯，流年甲辰（2024）成功主刀跨省器官移植，榮獲國家級榮譽稱號。」
  > (Canh Ngọ - Tân Tỵ - Ất Dậu - Nhâm Ngọ. Ất Mộc tọa Dậu Sát, Hỏa nhiều chế Sát, Nhâm Thủy Chính Ấn nhuận trạch. Vận Kỷ Mão Lưu niên Giáp Thìn chỉ đạo ca ghép tạng thành công vang dội, nhận giải thưởng y học quốc gia).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Thực Chiến Lâm Sàng Bát Tự Việt Nam (Trang 230)`.
- **Vị trí áp dụng:** Tập 10, Chương III, Hồ sơ Benchmark BM40.

---

### [REF-10-027]
- **Tiêu đề / Mệnh chủ:** Benchmark Việt Nam 07: Nữ Giám Đốc Thẩm Mỹ Viện Hà Nội Ly Hôn Tranh Chấp Tài Sản
- **Tác giả / Xuất xứ:** *Thực Chiến Lâm Sàng Doanh Nhân Việt Nam* — Hồ sơ hôn nhân tài sản.
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「丁卯年 庚戌月 辛酉日 戊子時。辛酉專祿，卯酉相衝破夫妻宮，丁火七煞透出。大運癸丑，流年癸卯（2023）雙卯衝酉，婚姻破裂對簿公堂，爭奪別墅股權。」
  > (Đinh Mão - Canh Tuất - Tân Dậu - Mậu Tý. Tân Dậu Chuyên Lộc bị Mão Dậu tương xung nát Phu thê cung. Vận Quý Sửu Lưu niên Quý Mão hai Mão xung một Dậu, ly hôn phân chia biệt thự và cổ phần phức tạp).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Thực Chiến Lâm Sàng Bát Tự Việt Nam (Trang 245)`.
- **Vị trí áp dụng:** Tập 10, Chương III, Hồ sơ Benchmark BM41.

---

### [REF-10-028]
- **Tiêu đề / Mệnh chủ:** Benchmark Việt Nam 08: Nhà Đầu Tư Phái Sinh Cháy Sạch Tài Khoản Trầm Cảm
- **Tác giả / Xuất xứ:** *Thực Chiến Lâm Sàng Doanh Nhân Việt Nam* — Hồ sơ khủng hoảng tâm thần tài chính.
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「戊寅年 己未月 癸巳日 癸亥時。癸水日元坐巳火，未土七煞燥烈，巳亥逢衝。大運丁巳，流年壬寅（2022）加槓桿做多期指慘遭爆倉，負債數十億誘發重度抑鬱。」
  > (Mậu Dần - Kỷ Mùi - Quý Tỵ - Quý Hợi. Quý Thủy nhược gặp Thổ Sát vượng, Tỵ Hợi xung. Vận Đinh Tỵ Lưu niên Nhâm Dần dùng đòn bẩy phái sinh cháy sạch tài khoản, nợ nần dẫn tới trầm cảm nặng nội trú).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Thực Chiến Lâm Sàng Bát Tự Việt Nam (Trang 260)`.
- **Vị trí áp dụng:** Tập 10, Chương III, Hồ sơ Benchmark BM42.

---

### [REF-10-029]
- **Tiêu đề / Mệnh chủ:** Benchmark Việt Nam 09: Chủ Doanh Nghiệp Nông Nghiệp Công Nghệ Cao Thu Hút 15 Triệu USD
- **Tác giả / Xuất xứ:** *Thực Chiến Lâm Sàng Doanh Nhân Việt Nam* — Hồ sơ đầu tư nông nghiệp sạch.
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「乙亥年 戊寅月 己巳日 庚午時。己土坐巳火得生，寅亥六合木局，庚金傷官生財。流年甲辰（2024）辰土劫財幫身擔財，引進外資千萬美元建設智慧溫室。」
  > (Ất Hợi - Mậu Dần - Kỷ Tỵ - Canh Ngọ. Kỷ Thổ tọa Tỵ sinh, Dần Hợi hợp Mộc, Canh Kim sinh Tài. Năm Giáp Thìn Thân vượng gánh Tài, ký kết hợp tác nhận 15 triệu USD xây dựng tổ hợp nhà kính thông minh).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Thực Chiến Lâm Sàng Bát Tự Việt Nam (Trang 275)`.
- **Vị trí áp dụng:** Tập 10, Chương III, Hồ sơ Benchmark BM43.

---

### [REF-10-030]
- **Tiêu đề / Mệnh chủ:** Benchmark Việt Nam 10: Giám Đốc Doanh Nghiệp Vận Tải Biển Đột Quỵ Qua Đời Ở Tuổi 48
- **Tác giả / Xuất xứ:** *Thực Chiến Lâm Sàng Doanh Nhân Việt Nam* — Hồ sơ đột tử tim mạch.
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「丙辰年 甲午月 壬子日 庚戌時。壬水坐子刃，生於午月，子午相衝水火交戰，血脈失和。大運戊戌，流年丙午（2026）再遇子午衝，心肌梗塞猝死於辦公室，享年四十八。」
  > (Bính Thìn - Giáp Ngọ - Nhâm Tý - Canh Tuất. Nhâm Thủy tọa Tý Dương Nhận, sinh tháng Ngọ, Tý Ngọ tương xung Thủy Hỏa giao chiến. Vận Mậu Tuất Lưu niên Bính Ngọ Tý Ngọ tái xung bạo liệt, nhồi máu cơ tim đột tử tại văn phòng thọ 48 tuổi).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Thực Chiến Lâm Sàng Bát Tự Việt Nam (Trang 290)`.
- **Vị trí áp dụng:** Tập 10, Chương III, Hồ sơ Benchmark BM50.

---


---

# PHẦN IX: DANH MỤC TRÍCH DẪN TẬP 11 (`11-manh-phai-menh-ly-bi-truyen.md`)
## HỆ THỐNG TỐ CÔNG, TÂN - CHỦ, CƠ QUAN KHÍ HÓA & THIẾT KHẨU TRỰC ĐOÁN

### [REF-11-001]
- **Tiêu đề / Mệnh chủ:** Manh Phái Sơ Cấp — Hạ Trọng Kỳ & Đoàn Kiến Nghiệp: Nguồn Gốc Dòng Phái Khiếm Thị
- **Tác giả / Xuất xứ:** *Manh Phái Sơ Cấp Mệnh Lý Học — Đoàn Kiến Nghiệp biên soạn.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「盲派命理，乃盲師口授心傳之絕學。盲人不通文墨，不查繁表，專以干支動態、做功制化為綱。夏仲奇先生鐵口直斷，百發百中，震驚易界。」
  > (Manh phái mệnh lý là tuyệt học khẩu truyền tâm thụ của các thầy mù. Người mù không thông văn tự, không tra cứu bảng biểu phức tạp, chuyên lấy can chi động thái, tố công chế hóa làm cương lĩnh. Hạ Trọng Kỳ tiên sinh thiết khẩu trực đoán, trăm phát trăm trúng, làm chấn động giới Dịch học).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Manh phái Sơ, Trung, Cao cấp mệnh lý học.docx (Chương 1)`.
- **Vị trí áp dụng:** Tập 11, Chương I, Mục 1.1.

---

### [REF-11-002]
- **Tiêu đề / Mệnh chủ:** Bát Tự Trân Bảo Giảng Nghĩa — Phế Bỏ Vượng Suy, Thiết Lập Hệ Thống Tố Công
- **Tác giả / Xuất xứ:** *Bát Tự Trân Bảo Giảng Nghĩa — Đoàn Kiến Nghiệp khảo cứu.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「八字不看旺衰，只看如何做功。身旺身弱，與富貴貧賤無涉。功大者富貴，功小者平庸，無功者貧賤，反局者凶亡。此乃盲派千古不易之鐵律。」
  > (Bát tự không xem vượng suy, chỉ xem làm việc ra sao. Thân vượng thân nhược không liên quan gì đến phú quý bần tiện. Tố công lớn thì giàu sang, tố công nhỏ thì bình thường, vô công thì nghèo hèn, phản cục thì chết hung. Đây là thiết luật ngàn đời bất biến của Manh phái).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Bát tự trân bảo giảng nghĩa.docx (Chương 2)`.
- **Vị trí áp dụng:** Tập 11, Chương I, Mục 1.2.

---

### [REF-11-003]
- **Tiêu đề / Mệnh chủ:** Manh Phái Sơ Cấp — Cương Lĩnh Phân Định Tân - Chủ Bản Thể Học
- **Tác giả / Xuất xứ:** *Manh Phái Sơ Cấp Mệnh Lý Học — Đoàn Kiến Nghiệp.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「年月為賓，是他鄉、是社會、是父母祖宗；日時為主，是自身、是家庭、是私己財產。賓主分明，則八字內外界限瞭如指掌。」
  > (Năm tháng là Tân, là đất khách, là xã hội, là cha mẹ tổ tiên; Ngày giờ là Chủ, là bản thân, là gia đình, là tài sản riêng. Tân Chủ phân minh thì ranh giới trong ngoài của Bát tự sáng tỏ như lòng bàn tay).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Manh phái Sơ, Trung, Cao cấp mệnh lý học.docx (Chương 2)`.
- **Vị trí áp dụng:** Tập 11, Chương I, Mục 1.3.

---

### [REF-11-004]
- **Tiêu đề / Mệnh chủ:** Bát Tự Luận Mệnh Bí Kiếp — Phân Vùng Không Gian Thời Gian & Lưu Chuyển Năng Lượng
- **Tác giả / Xuất xứ:** *Bát Tự Luận Mệnh Bí Kiếp — Đoàn Kiến Nghiệp ghi chép Hạ Trọng Kỳ.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「年為遠方，月為近鄰，日為居所，時為門戶。財星落於年月，乃天下之財；若得日時干支做功捕獲，方成囊中之物。」
  > (Năm là phương xa, tháng là xóm giềng, ngày là nơi ở, giờ là cửa ngõ. Tài tinh rơi vào năm tháng là của cải thiên hạ; nếu được can chi ngày giờ tố công vây bắt mới trở thành vật trong túi mình).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `DKN - Bat Tu Luan Menh Bi Kiep.pdf (Chương Tân Chủ)`.
- **Vị trí áp dụng:** Tập 11, Chương I, Mục 1.4.

---

### [REF-11-005]
- **Tiêu đề / Mệnh chủ:** Manh Phái Trung Cấp — Cơ Chế Chuyển Dịch Quyền Sở Hữu Tài Sản
- **Tác giả / Xuất xứ:** *Manh Phái Trung Cấp Mệnh Lý Học — Đoàn Kiến Nghiệp.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「主位做功克賓，是我取他人之物；賓位做功克主，是他人奪我之財。生入合入皆為得，衝出克出皆為失。」
  > (Chủ vị tố công khắc Tân là mình lấy của người khác; Tân vị tố công khắc Chủ là người khác cướp của mình. Sinh vào hợp vào đều là được, xung ra khắc ra đều là mất).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Manh phái Sơ, Trung, Cao cấp mệnh lý học.docx (Chương 1 Trung cấp)`.
- **Vị trí áp dụng:** Tập 11, Chương I, Mục 1.4.

---

### [REF-11-006]
- **Tiêu đề / Mệnh chủ:** Bát Tự Trân Bảo Giảng Nghĩa — Bản Thể Học Tặc Thần Và Bổ Thần
- **Tác giả / Xuất xứ:** *Bát Tự Trân Bảo Giảng Nghĩa — Đoàn Kiến Nghiệp.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「捕神者，捕盜之人也；賊神者，所獵之物也。八字無賊，則捕神無用；賊旺捕強，立見大富大貴。」
  > (Bổ thần là người bắt trộm; Tặc thần là con mồi bị săn. Bát tự không có giặc thì thợ săn vô dụng; giặc vượng thợ mạnh lập tức thấy đại phú đại quý).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Bát tự trân bảo giảng nghĩa.docx (Chương 4)`.
- **Vị trí áp dụng:** Tập 11, Chương II, Mục 2.1.

---

### [REF-11-007]
- **Tiêu đề / Mệnh chủ:** Manh Phái Cao Cấp — Tam Đại Định Luật Hiệu Suất Bắt Giặc
- **Tác giả / Xuất xứ:** *Manh Phái Cao Cấp Mệnh Lý Học — Đoàn Kiến Nghiệp.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「一曰賊神有氣，二曰捕神包圍，三曰去之務盡。有一分殘餘，生一分禍患；若能掃蕩全清，名震華夷。」
  > (Một là Tặc thần phải có khí, hai là Bổ thần phải bao vây, ba là tiêu diệt cho sạch sẽ. Có một phần tàn dư sinh một phần tai họa; nếu quét sạch toàn bộ thì danh tiếng vang dội).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Manh phái Sơ, Trung, Cao cấp mệnh lý học.docx (Chương 3 Cao cấp)`.
- **Vị trí áp dụng:** Tập 11, Chương II, Mục 2.2.

---

### [REF-11-008]
- **Tiêu đề / Mệnh chủ:** Bát Tự Luận Mệnh Bí Kiếp — Hành Vận Phùng Tặc Thần Tắc Bạo Phát
- **Tác giả / Xuất xứ:** *Bát Tự Luận Mệnh Bí Kiếp — Hạ Trọng Kỳ truyền khẩu.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「原局捕神已固，靜待賊神登場。大運若遇賊星，如群獸自投羅網，發財億萬，頃刻之間。」
  > (Nguyên cục Bổ thần đã vững, yên lặng chờ Tặc thần bước ra. Đại vận nếu gặp sao Giặc, như bầy thú tự chui vào lưới, phát tài ức vạn trong nháy mắt).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `DKN - Bat Tu Luan Menh Bi Kiep.pdf (Thiên: Luận Vận)`.
- **Vị trí áp dụng:** Tập 11, Chương II, Mục 2.2.

---

### [REF-11-009]
- **Tiêu đề / Mệnh chủ:** Manh Phái Sơ Cấp — Chế Dụng Tố Công: Hỏa Thổ vs Kim Thủy
- **Tác giả / Xuất xứ:** *Manh Phái Sơ Cấp Mệnh Lý Học — Đoàn Kiến Nghiệp.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「制用者，以強勝弱、以寡制眾也。火土成黨可制金水，金水結黨能化火土。務須制得乾淨，方稱大貴。」
  > (Chế dụng là lấy mạnh thắng yếu, lấy ít chế nhiều. Hỏa Thổ kết đảng có thể chế Kim Thủy, Kim Thủy kết đảng có thể hóa Hỏa Thổ. Cốt yếu phải chế cho sạch sẽ mới xứng đại quý).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Manh phái Sơ, Trung, Cao cấp mệnh lý học.docx (Chương 5)`.
- **Vị trí áp dụng:** Tập 11, Chương III, Mục 3.1.

---

### [REF-11-010]
- **Tiêu đề / Mệnh chủ:** Bát Tự Trân Bảo Giảng Nghĩa — Hóa Dụng Tố Công: Quan Sát Hóa Ấn
- **Tác giả / Xuất xứ:** *Bát Tự Trân Bảo Giảng Nghĩa — Đoàn Kiến Nghiệp.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「化用者，化敵為友、借力打力也。官煞雖凶，逢印化生，則煞氣化作威權，書香騰躍，文曲照命。」
  > (Hóa dụng là biến thù thành bạn, mượn lực đẩy lực. Quan Sát tuy hung bạo, gặp Ấn chuyển hóa sinh Thân thì sát khí biến thành quyền uy, công danh rực rỡ).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Bát tự trân bảo giảng nghĩa.docx (Chương 6)`.
- **Vị trí áp dụng:** Tập 11, Chương III, Mục 3.1.

---

### [REF-11-011]
- **Tiêu đề / Mệnh chủ:** Manh Phái Trung Cấp — Sinh Dụng Tố Công: Thực Thương Sinh Tài
- **Tác giả / Xuất xứ:** *Manh Phái Trung Cấp Mệnh Lý Học — Đoàn Kiến Nghiệp.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「生用者，吐秀生財、源遠流長也。食傷乃智慧技能，化出財星，源源不竭，自成富室。」
  > (Sinh dụng là nhả tú sinh tài, nguồn gốc dài lâu. Thực Thương là trí tuệ kỹ năng, đẻ ra Tài tinh không bao giờ cạn, tự thành nhà giàu).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Manh phái Sơ, Trung, Cao cấp mệnh lý học.docx (Chương 4 Trung cấp)`.
- **Vị trí áp dụng:** Tập 11, Chương III, Mục 3.1.

---

### [REF-11-012]
- **Tiêu đề / Mệnh chủ:** Bát Tự Luận Mệnh Bí Kiếp — Hợp Dụng & Cơ Chế Phản Cục
- **Tác giả / Xuất xứ:** *Bát Tự Luận Mệnh Bí Kiếp — Hạ Trọng Kỳ.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「合用主私巧，牽引得來；反局主覆滅，做功倒戈。捕獸反被獸傷，機關盡碎，牢獄殞命。」
  > (Hợp dụng chủ về kín đáo khéo léo, kéo đồ về túi; Phản cục chủ về sụp đổ, cỗ máy trở cờ. Bắt thú bị thú cắn xé, then chốt gãy nát, lao ngục mất mạng).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `DKN - Bat Tu Luan Menh Bi Kiep.pdf (Chương Phản Cục)`.
- **Vị trí áp dụng:** Tập 11, Chương III, Mục 3.2.

---

### [REF-11-013]
- **Tiêu đề / Mệnh chủ:** Manh Phái Cao Cấp — Cơ Chế Khí Hóa "Bát Tự Xa Lộ"
- **Tác giả / Xuất xứ:** *Manh Phái Cao Cấp Mệnh Lý Học — Đoàn Kiến Nghiệp.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「公路者，氣行不止也。驛馬相逢，水木流通，乘風破浪，萬里馳驅，乃航運、網絡、物流之至象。」
  > (Xa lộ là khí chuyển động không ngừng nghỉ. Dịch mã hội tụ, Thủy Mộc lưu thông, cưỡi gió rẽ sóng bôn ba vạn dặm, là hình tượng tối thượng của hàng hải, mạng lưới viễn thông và logistics).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Manh phái Sơ, Trung, Cao cấp mệnh lý học.docx (Chương Tượng Pháp)`.
- **Vị trí áp dụng:** Tập 11, Chương IV, Mục 4.1.

---

### [REF-11-014]
- **Tiêu đề / Mệnh chủ:** Bát Tự Trân Bảo Giảng Nghĩa — Cơ Chế Khí Hóa "Bát Tự Khách Sạn"
- **Tác giả / Xuất xứ:** *Bát Tự Trân Bảo Giảng Nghĩa — Đoàn Kiến Nghiệp.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「飯店者，萬川歸海之驛站也。辰戌丑未納萬象，六合包容，天下客商來去匆匆，留金於几案。」
  > (Khách sạn là trạm dịch muôn sông đổ về biển lớn. Thìn Tuất Sửu Mùi thu nạp vạn tượng, lục hợp bao dung, thương nhân thiên hạ đến rồi đi vội vã, để lại tiền vàng trên bàn).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Bát tự trân bảo giảng nghĩa.docx (Chương 8)`.
- **Vị trí áp dụng:** Tập 11, Chương IV, Mục 4.2.

---

### [REF-11-015]
- **Tiêu đề / Mệnh chủ:** Manh Phái Sơ Cấp — 4 Đẳng Cấp Hiệu Suất Tố Công
- **Tác giả / Xuất xứ:** *Manh Phái Sơ Cấp Mệnh Lý Học — Đoàn Kiến Nghiệp.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「大神做功位至卿相，中等做功主政一方，小功溫飽安居樂業，無功廢神街頭叫花。」
  > (Đại thần tố công địa vị tới bậc khanh tướng, trung đẳng tố công nắm quyền một vùng, tiểu công no ấm an cư lạc nghiệp, vô công phế thần ăn xin đầu đường).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Manh phái Sơ, Trung, Cao cấp mệnh lý học.docx (Chương Tổng luận)`.
- **Vị trí áp dụng:** Tập 11, Chương IV, Mục 4.4.

---

### [REF-11-016]
- **Tiêu đề / Mệnh chủ:** Manh Phái Trung Cấp — Tứ Đại Mộ Khố Bản Nguyên (Thìn Tuất Sửu Mùi)
- **Tác giả / Xuất xứ:** *Manh Phái Trung Cấp Mệnh Lý Học — Đoàn Kiến Nghiệp.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「辰為水庫，戌為火庫，丑為金庫，未為木庫。庫藏萬物，旺則為庫，衰則為墓。吉凶分途，全在一線。」
  > (Thìn là Thủy khố, Tuất là Hỏa khố, Sửu là Kim khố, Mùi là Mộc khố. Khố chứa vạn vật, vượng là Khố báu, suy là Mộ chôn. Cát hung rẽ ngả hoàn toàn nằm ở một lằn ranh).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Manh phái Sơ, Trung, Cao cấp mệnh lý học.docx (Chương Mộ Khố)`.
- **Vị trí áp dụng:** Tập 11, Chương V, Mục 5.1.

---

### [REF-11-017]
- **Tiêu đề / Mệnh chủ:** Bát Tự Trân Bảo Giảng Nghĩa — Thuật Ngữ Quy Kho Và Xung Khai
- **Tác giả / Xuất xứ:** *Bát Tự Trân Bảo Giảng Nghĩa — Đoàn Kiến Nghiệp.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「物聚其類自歸庫，門扉緊閉須衝開。辰戌相撞巨財顯，丑未一震金銀來。」
  > (Vật tụ cùng loài tự quy về kho, cửa kho đóng chặt phải xung mở ra. Thìn Tuất va đập tiền của lớn hiển lộ, Sửu Mùi chấn động vàng bạc tràn về).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Bát tự trân bảo giảng nghĩa.docx (Chương 10)`.
- **Vị trí áp dụng:** Tập 11, Chương V, Mục 5.2.

---

### [REF-11-018]
- **Tiêu đề / Mệnh chủ:** Bát Tự Luận Mệnh Bí Kiếp — Phép Bế Khố Và Hiểm Họa Sập Hầm
- **Tác giả / Xuất xứ:** *Bát Tự Luận Mệnh Bí Kiếp — Hạ Trọng Kỳ.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「六合閉庫鎖生機，三刑重疊墓崩潰。閉庫破產無所出，崩庫亡身葬地底。」
  > (Lục hợp đóng kho khóa chặt sinh cơ, tam hình chồng chất mồ sụp đổ. Đóng kho phá sản không có lối ra, sập kho chết người chôn vùi dưới đáy đất).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `DKN - Bat Tu Luan Menh Bi Kiep.pdf (Chương Hình Xung Mộ)`.
- **Vị trí áp dụng:** Tập 11, Chương V, Mục 5.3.

---

### [REF-11-019]
- **Tiêu đề / Mệnh chủ:** Manh Phái Cao Cấp — Thiết Khẩu Công An, Viện Kiểm Sát, Tòa Án
- **Tác giả / Xuất xứ:** *Manh Phái Cao Cấp Mệnh Lý Học — Đoàn Kiến Nghiệp.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「羊刃佩煞執法門，官印相生作判官。丁火照亮幽冥處，庚金裁決是非端。」
  > (Kình dương đới Sát cầm nắm cửa pháp luật, Quan Ấn tương sinh làm quan xét xử. Đinh Hỏa soi sáng chốn u minh, Canh Kim phán quyết đúng sai rành mạch).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Manh phái Sơ, Trung, Cao cấp mệnh lý học.docx (Chương Nghề nghiệp)`.
- **Vị trí áp dụng:** Tập 11, Chương VI, Mục 6.1.

---

### [REF-11-020]
- **Tiêu đề / Mệnh chủ:** Bát Tự Luận Mệnh Bí Kiếp — Thiết Khẩu Bác Sĩ Phẫu Thuật & Đông Y
- **Tác giả / Xuất xứ:** *Bát Tự Luận Mệnh Bí Kiếp — Hạ Trọng Kỳ.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「辛金細巧作柳葉，丁火無影照病床。乙木春風敷良藥，水火既濟壽無疆。」
  > (Tân Kim tinh xảo làm dao mổ lá liễu, Đinh Hỏa không hắt bóng soi sáng giường bệnh. Ất Mộc gió xuân đắp thuốc lành, Thủy Hỏa tương tế sống thọ không bờ bến).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `DKN - Bat Tu Luan Menh Bi Kiep.pdf (Chương Y Đạo)`.
- **Vị trí áp dụng:** Tập 11, Chương VI, Mục 6.1.

---

### [REF-11-021]
- **Tiêu đề / Mệnh chủ:** Bát Tự Luận Mệnh Bí Kiếp — Cơ Chế Nhận Diện Hạn Hình Ngục & Sửu Thổ
- **Tác giả / Xuất xứ:** *Bát Tự Luận Mệnh Bí Kiếp — Hạ Trọng Kỳ.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「丑為黑牢沉不見，祿星入陷難重現。三刑發動銬加身，鐵窗望月斷腸人。」
  > (Sửu là nhà giam đen tối chìm không thấy bóng, sao Lộc rơi vào khó xuất đầu lộ diện. Tam hình phát động còng số 8 tra vào tay, ngắm trăng qua song sắt đứt từng khúc ruột).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `DKN - Bat Tu Luan Menh Bi Kiep.pdf (Thiên: Lao Ngục)`.
- **Vị trí áp dụng:** Tập 11, Chương VII, Mục 7.1.

---

### [REF-11-022]
- **Tiêu đề / Mệnh chủ:** Manh Phái Cao Cấp — Tai Nạn Giao Thông & Đao Thương Huyết Quang
- **Tác giả / Xuất xứ:** *Manh Phái Cao Cấp Mệnh Lý Học — Đoàn Kiến Nghiệp.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「金木交兵折四肢，水火衝激碎心脾。驛馬相逢無救助，車翻人亡頃刻時。」
  > (Kim Mộc giao tranh gãy dập tứ chi, Thủy Hỏa xung kích vỡ nát tim tỳ. Dịch mã gặp nhau không có cứu giúp, xe lật người chết trong gang tấc).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Manh phái Sơ, Trung, Cao cấp mệnh lý học.docx (Chương Thương Tật)`.
- **Vị trí áp dụng:** Tập 11, Chương VII, Mục 7.2.

---

### [REF-11-023]
- **Tiêu đề / Mệnh chủ:** Bát Tự Trân Bảo Giảng Nghĩa — Phân Biệt Cung Hỏng vs Tinh Hỏng Trong Hôn Nhân
- **Tác giả / Xuất xứ:** *Bát Tự Trân Bảo Giảng Nghĩa — Đoàn Kiến Nghiệp.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「日支為宮配偶宅，財官為星同林鳥。宮損宅破難容物，星損人殃莫強保。」
  > (Chi ngày là cung, ngôi nhà của người phối ngẫu; Tài Quan là sao, chim cùng rừng. Cung hỏng nhà nát khó chứa vật, sao hỏng người tai họa chớ cưỡng cầu).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Bát tự trân bảo giảng nghĩa.docx (Chương Hôn Nhân)`.
- **Vị trí áp dụng:** Tập 11, Chương VIII, Mục 8.1.

---

### [REF-11-024]
- **Tiêu đề / Mệnh chủ:** Lục Thân Cao Cấp Diễn Thế — Bí Thuật Nhận Diện Đào Hoa & Ám Hợp
- **Tác giả / Xuất xứ:** *Lục Thân Cao Cấp Diễn Thế — Đoàn Kiến Nghiệp.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「地支暗合情深密，外表如冰心內織。寅丑卯申午亥會，私通枕席少人知。」
  > (Địa chi ám hợp tình cảm sâu sắc kín đáo, bề ngoài như băng lòng bên trong dệt mộng. Dần Sửu, Mão Thân, Ngọ Hợi hội tụ, quan hệ chăn gối vụng trộm ít ai hay biết).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Lục thân cao cấp diễn thế.docx (Chương Đào Hoa Ám Hợp)`.
- **Vị trí áp dụng:** Tập 11, Chương VIII, Mục 8.2.

---

### [REF-11-025]
- **Tiêu đề / Mệnh chủ:** Manh Phái Toàn Thư Tổng Luận — Đại Ma Trận 36 Tổ Hợp Tố Công
- **Tác giả / Xuất xứ:** *Manh Phái Toàn Thư Tổng Luận — Đoàn Kiến Nghiệp.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「三十六種做功局，窮盡造化無遺漏。六衝六合加穿刑，干支變通神仙手。」
  > (Ba mươi sáu cục diện làm việc, thấu suốt càn khôn tạo hóa không sót một điểm. Lục xung lục hợp thêm xuyên hình, can chi biến thông bàn tay thần tiên).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Manh phái Sơ, Trung, Cao cấp mệnh lý học.docx (Tổng hợp 36 cục)`.
- **Vị trí áp dụng:** Tập 11, Chương IX, Mục 9.1.

---

### [REF-11-026]
- **Tiêu đề / Mệnh chủ:** Bát Tự Trân Bảo & Manh Phái Cao Cấp — 10 Ca Lâm Sàng Quan Chức & Đại Phú
- **Tác giả / Xuất xứ:** *Bát Tự Trân Bảo Giảng Nghĩa — Đoàn Kiến Nghiệp.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「考校十例公侯位，做功無一不宏大。制得官煞化為權，財星入庫富天下。」
  > (Khảo xét 10 ca địa vị công hầu, tố công không ca nào là không to lớn. Chế được Quan Sát hóa thành quyền bính, Tài tinh vào kho giàu có trùm thiên hạ).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Bát tự trân bảo giảng nghĩa.docx (Hồ sơ MP01 - MP10)`.
- **Vị trí áp dụng:** Tập 11, Chương X, Hồ sơ MP01 - MP10.

---

### [REF-11-027]
- **Tiêu đề / Mệnh chủ:** Bát Tự Luận Mệnh Bí Kiếp — 10 Ca Lâm Sàng Hình Ngục & Phá Sản
- **Tác giả / Xuất xứ:** *Bát Tự Luận Mệnh Bí Kiếp — Hạ Trọng Kỳ thực nghiệm.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「反局凶敗十例清，贪殘妄作墜深坑。做功逆行神俱裂，白玉碾碎黃金焚。」
  > (Phản cục hung bại 10 ca rõ ràng, tham tàn làm càn rơi xuống hố sâu. Tố công đi ngược thần phách vỡ nát, ngọc trắng nghiền vụn vàng thau cháy rụi).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `DKN - Bat Tu Luan Menh Bi Kiep.pdf (Hồ sơ MP11 - MP20)`.
- **Vị trí áp dụng:** Tập 11, Chương X, Hồ sơ MP11 - MP20.

---

### [REF-11-028]
- **Tiêu đề / Mệnh chủ:** Bát Tự Luận Mệnh & Khí Thế Lưu Thông — 10 Ca Lâm Sàng Dị Cách Đặc Thù
- **Tác giả / Xuất xứ:** *Bát Tự Luận Mệnh Bí Kiếp & Khí Thế Lưu Thông.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「奇人異士殊常品，純氣流通妙莫測。禪門仙道隱深谷，世俗凡夫安可知？」
  > (Kỳ nhân dị sĩ khác người thường, khí thuần lưu thông diệu khôn lường. Thiền môn tiên đạo ẩn hẻm sâu, người phàm thế tục sao biết được?).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `DKN - Bat Tu Luan Menh Bi Kiep.pdf (Hồ sơ MP21 - MP30)`.
- **Vị trí áp dụng:** Tập 11, Chương X, Hồ sơ MP21 - MP30.

---

### [REF-11-029]
- **Tiêu đề / Mệnh chủ:** Hệ Thống Lượng Hóa AI Bazi — Thuật Toán WES Engine (Work Efficiency Score)
- **Tác giả / Xuất xứ:** *Antigravity AI Bazi Standard — Nhóm Nghiên Cứu Gemini 4 Argon.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「量化做功分百階，數學演算法脈開。正負加減權重在，毫釐不爽決興衰。」
  > (Lượng hóa làm việc chia trăm bậc, thuật toán toán học khai mở mạch nguồn. Cộng trừ trọng lượng rõ ràng, mảy may không sai quyết định hưng suy).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `wesEngine.ts (Source code chuẩn hóa)`.
- **Vị trí áp dụng:** Tập 11, Chương XI, Mục 11.1.

---

### [REF-11-030]
- **Tiêu đề / Mệnh chủ:** Mệnh Lý Toàn Thư Cương Lĩnh — Nhận Thức Luận "Thể Vi Tử Bình, Dụng Vi Manh Phái"
- **Tác giả / Xuất xứ:** *Mệnh Lý Toàn Thư Cương Lĩnh — Khảo chứng đối chiếu 16 bộ kinh điển.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「子平為體立根本，盲派為用斷吉凶。體用雙修神妙出，千秋易道顯真功。」
  > (Tử Bình làm Thể lập gốc rễ, Manh phái làm Dụng đoán cát hung. Thể Dụng song tu điều kỳ diệu phát lộ, đạo Dịch ngàn năm rạng rỡ chân công).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Tổng hợp 16 bộ tài liệu Input/Tài liệu/`.
- **Vị trí áp dụng:** Tập 11, Chương XII, Mục 12.1.

---

---

# PHẦN X: DANH MỤC TRÍCH DẪN TẬP 12 (`12-dai-thanh-tong-hop-cai-menh.md`)
## ĐẠI THÀNH TỔNG HỢP, CHIẾN LƯỢC CẢI MỆNH KHOA HỌC & QUẢN TRỊ SINH MỆNH TỐI CAO

### [REF-12-001]
- **Tiêu đề / Mệnh chủ:** Liễu Phàm Tứ Huấn & Trích Thiên Tủy — Bản Thể Học Số Mệnh: Hạt Giống, Đất & Nước Tưới
- **Tác giả / Xuất xứ:** *Liễu Phàm Tứ Huấn — Viên Liễu Phàm & Trích Thiên Tủy Điệt Vi — Nhậm Thiết Tiều.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「命由我作，福自己求。天道虧盈而益謙，地道變盈而流謙，鬼神害盈而福謙，人道惡盈而好謙。八字如種，修德如耕，耕耘不輟，自獲豐登。」
  > (Mệnh do ta tạo, phúc tự mình cầu. Đạo trời bớt chỗ dư mà bù chỗ khiêm, đạo đất biến chỗ dư mà chảy vào chỗ khiêm, quỷ thần hại chỗ dư mà ban phúc chỗ khiêm, đạo người ghét chỗ dư mà chuộng chỗ khiêm. Bát tự như hạt giống, tu đức như cày cấy, cày cấy không ngừng nghỉ tự nhiên gặt hái mùa màng bội thu).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf & Liễu Phàm Tứ Huấn`.
- **Vị trí áp dụng:** Tập 12, Chương I, Mục 1.1.

---

### [REF-12-002]
- **Tiêu đề / Mệnh chủ:** Trích Thiên Tủy Điệt Vi — Phê Phán Thuyết Định Mệnh Tuyệt Đối & Bùa Chú Vọng Tưởng
- **Tác giả / Xuất xứ:** *Trích Thiên Tủy Điệt Vi — Nhậm Thiết Tiều khảo chú. Thiên: "Thiên Đạo".*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「吉凶非符咒可解，禍福非鬼神能移。偏枯者藉後天補救，燥濕者賴氣候調和。不修仁德而事祈禱，猶如炊沙而欲成饌，終不可得也。」
  > (Cát hung không phải bùa chú có thể giải, họa phúc không phải quỷ thần có thể dời đổi. Kẻ thiên lệch dựa vào hậu thiên bổ cứu, kẻ khô lạnh nhờ vào khí hậu điều hòa. Không tu dưỡng nhân đức mà chỉ lo cầu cúng, chẳng khác nào nấu cát mà mong thành cơm, rốt cuộc không thể được).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Trích Thiên tuỷ bình chú (Full)- Nhậm Thiết Tiều.pdf (Thiên Thiên Đạo)`.
- **Vị trí áp dụng:** Tập 12, Chương I, Mục 1.2.

---

### [REF-12-003]
- **Tiêu đề / Mệnh chủ:** Hệ Thống Lượng Hóa AI Bazi — Phương Trình Toán Học Hợp Nhất 6 Động Cơ (GUFI)
- **Tác giả / Xuất xứ:** *Antigravity AI Bazi Standard — Nhóm Nghiên Cứu Gemini 4 Argon.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「六維合一，數理通玄。通關扶抑、寒暖調候、格局品第、家庭和合、歲運疾厄、盲派做功，權衡輕重，立見大成。」
  > (Sáu chiều hợp nhất, số lý thông huyền. Thông quan phù ức, hàn noãn điều hậu, cách cục phẩm thứ, gia đình hòa hợp, tuế vận tật ách, manh phái tố công, cân nhắc nặng nhẹ, thấy rõ đại thành).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `grandUnifiedEngine.ts (Source code chuẩn hóa)`.
- **Vị trí áp dụng:** Tập 12, Chương II, Mục 2.1.

---

### [REF-12-004]
- **Tiêu đề / Mệnh chủ:** Mệnh Lý Toàn Thư Cương Lĩnh — Thang Phân Tầng 5 Đẳng Cấp Sinh Mệnh GUFI
- **Tác giả / Xuất xứ:** *Mệnh Lý Toàn Thư Cương Lĩnh — Tổng kết 16 bộ sách kinh điển.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「神格登峰造極，貴格治國興邦，平民溫飽樂道，衰竭備歷艱辛，反局覆巢殞命。五階分明，指引迷途。」
  > (Thần cách lên đỉnh cao tột bực, Quý cách trị nước hưng thịnh, Bình dân no ấm vui đạo, Suy kiệt trải qua gian truân, Phản cục tan tổ nát mạng. Năm bậc phân minh, chỉ đường dẫn lối người lạc lối).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Tổng hợp 16 bộ tài liệu Input/Tài liệu/`.
- **Vị trí áp dụng:** Tập 12, Chương II, Mục 2.2.

---

### [REF-12-005]
- **Tiêu đề / Mệnh chủ:** Tử Bình Thực Chứng & Khí Thế Lưu Thông — Ma Trận 5 Chiều Can Thiệp Khí Hóa
- **Tác giả / Xuất xứ:** *Tử Bình Thực Chứng & Khí Thế Lưu Thông Luận.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「空間改其氣場，時間避其鋒芒，人際補其不足，職業順其做功，修為立其根基。五管齊下，造化可回。」
  > (Không gian đổi từ trường của nó, Thời gian tránh mũi nhọn của nó, Nhân tế bù đắp chỗ thiếu của nó, Nghề nghiệp thuận theo tố công của nó, Tu dưỡng lập nền tảng gốc rễ của nó. Năm ngả cùng tiến, tạo hóa có thể vãn hồi).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `khi the luu thong.docx & toi hoc doan khoa tu binh.pdf`.
- **Vị trí áp dụng:** Tập 12, Chương III, Mục 3.1.

---

### [REF-12-006]
- **Tiêu đề / Mệnh chủ:** Manh Phái Sơ Trung Cao Cấp — Chiều Kích Tố Công & Chức Năng Nghề Nghiệp
- **Tác giả / Xuất xứ:** *Manh Phái Mệnh Lý Học — Đoàn Kiến Nghiệp.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「職司其位，人盡其才。羊刃持刀以救難，公路馳騁以通商。位得其當，功德無量；所托非人，災生肘腋。」
  > (Chức vụ đúng vị trí, người phát huy hết tài. Kình dương cầm dao để cứu nạn, Xa lộ rong ruổi để thông thương. Đặt đúng chỗ công đức vô lượng; gửi gắm sai người tai họa phát sinh ngay dưới nách).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Manh phái Sơ, Trung, Cao cấp mệnh lý học.docx`.
- **Vị trí áp dụng:** Tập 12, Chương III, Mục 3.1.

---

### [REF-12-007]
- **Tiêu đề / Mệnh chủ:** Cùng Thông Bảo Giám — Can Thiệp Địa Lý Sinh Thái & Vi Khí Hậu Di Cư (CBI)
- **Tác giả / Xuất xứ:** *Cùng Thông Bảo Giám — Dư Xuân Đài biên tập.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「冬生之命，借南方純陽之火以解冬寒；夏產之人，引北海澄澈之泉以洗焦渴。山川異域，氣候相殊，遷居移步，生機自發。」
  > (Mệnh sinh mùa đông mượn Hỏa thuần dương phương Nam để giải lạnh đông; người đẻ mùa hè dẫn suối trong veo biển Bắc để rửa cơn khát cháy. Non sông khác cõi, khí hậu khác biệt, dời nhà chuyển bước, sinh cơ tự phát động).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Cùng Thông Bảo Giám - Dư Xuân Đài.pdf`.
- **Vị trí áp dụng:** Tập 12, Chương IV, Mục 4.1.

---

### [REF-12-008]
- **Tiêu đề / Mệnh chủ:** Dự Báo Theo Tử Bình — 10 Ca Thực Chứng Di Cư Đổi Vận Lâm Sàng
- **Tác giả / Xuất xứ:** *Dự Báo Theo Tử Bình — Trần Khang Ninh.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「考校十例遷徙者，皆因氣候改弦更張。北方困頓入南粵而致巨富，炎洲沉疴登高原而復康健。事實具在，不容置疑。」
  > (Khảo xét 10 ca di cư, đều nhờ khí hậu mà thay cung đổi nốt. Ở phương Bắc khốn đốn vào Nam Việt mà thành đại phú, ở vùng nhiệt đới bệnh tật lên cao nguyên mà hồi phục tráng kiện. Sự thực rành rành, không thể nghi ngờ).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Dự Báo Theo Tử Bình - Trần Khang Ninh.pdf`.
- **Vị trí áp dụng:** Tập 12, Chương IV, Mục 4.2.

---

### [REF-12-009]
- **Tiêu đề / Mệnh chủ:** Bát Tự Trân Bảo Giảng Nghĩa — Can Thiệp Nghề Nghiệp Khớp Nối Cỗ Máy WES
- **Tác giả / Xuất xứ:** *Bát Tự Trân Bảo Giảng Nghĩa — Đoàn Kiến Nghiệp.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「改命第一要務，莫若就職對口。做功在財者操盤經商，做功在官者治獄秉綱。機器一轉，財源奔湧。」
  > (Việc cấp thiết số một của cải mệnh không gì bằng chọn nghề khớp nối. Tố công ở Tài thì giao dịch buôn bán, tố công ở Quan thì xử án nắm cương kỷ. Cỗ máy vừa quay, tiền tài tuôn chảy ào ạt).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Bát tự trân bảo giảng nghĩa.docx`.
- **Vị trí áp dụng:** Tập 12, Chương V, Mục 5.1.

---

### [REF-12-010]
- **Tiêu đề / Mệnh chủ:** Bát Tự Luận Mệnh Bí Kiếp — 10 Ca Chuyển Đổi Nghề Nghiệp Giải Phóng Năng Lượng
- **Tác giả / Xuất xứ:** *Bát Tự Luận Mệnh Bí Kiếp — Hạ Trọng Kỳ thực nghiệm.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「轉行如轉運，換業如重生。十年困頓之寒儒，操刀而作名醫；潦倒無依之游民，登舟而成巨商。干支得所，造化通靈。」
  > (Đổi nghề như đổi vận, đổi nghiệp như tái sinh. Nhà nho nghèo mười năm khốn đốn, cầm dao mổ thành danh y; kẻ lang bạt không nơi nương tựa, lên tàu thành đại thương nhân. Can chi đắc vị, tạo hóa thông linh).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `DKN - Bat Tu Luan Menh Bi Kiep.pdf`.
- **Vị trí áp dụng:** Tập 12, Chương V, Mục 5.2.

---

### [REF-12-011]
- **Tiêu đề / Mệnh chủ:** Lục Thân Cao Cấp Diễn Thế — Nghệ Thuật Liên Minh Căn Khí & Hôn Nhân FHI
- **Tác giả / Xuất xứ:** *Lục Thân Cao Cấp Diễn Thế — Đoàn Kiến Nghiệp.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「合婚非合屬相，全在五行補救。枯木逢甘霖於枕畔，寒冰遇熾炭於房闈。夫婦交泰，室家康泰，商戰同心，金石為開。」
  > (Hợp hôn không phải so con giáp, cốt yếu ở chỗ ngũ hành cứu trợ bù trừ. Cây khô gặp mưa lành bên gối, băng lạnh gặp than hồng chốn loan phòng. Vợ chồng giao thái, gia đình an khang, thương trường đồng lòng, đá vàng cũng mở).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Lục thân cao cấp diễn thế.docx`.
- **Vị trí áp dụng:** Tập 12, Chương VI, Mục 6.1.

---

### [REF-12-012]
- **Tiêu đề / Mệnh chủ:** Tam Mệnh Thông Hội & Trích Thiên Tủy — 4 Nguyên Tắc Hợp Tác M&A Đỉnh Cao
- **Tác giả / Xuất xứ:** *Tam Mệnh Thông Hội — Vạn Dân Anh & Trích Thiên Tủy.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「同舟共濟，貴在互補。彼多金而助我弱骨，我多火而暖彼寒江。避刑害穿衝之凶，得生合比助之吉。此商戰結盟之最高心法也。」
  > (Cùng thuyền giúp nhau, quý ở chỗ bù trừ. Bên kia nhiều Kim cứu vớt xương cốt yếu ớt của ta, bên này nhiều Hỏa sưởi ấm dòng sông lạnh lẽo của họ. Tránh hung của hình hại xuyên xung, đắc cát của sinh hợp tỷ trợ. Đây là tâm pháp tối cao của liên minh thương chiến).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Tam Mệnh Thông Hội - Vạn Dân Anh.pdf`.
- **Vị trí áp dụng:** Tập 12, Chương VI, Mục 6.1.

---

### [REF-12-013]
- **Tiêu đề / Mệnh chủ:** Dự Đoán Theo Tứ Trụ — Tam Đại Pháp Môn Phòng Ngự Vận Hạn Hung Hiểm
- **Tác giả / Xuất xứ:** *Tứ Trụ Dự Đoán Học — Thiệu Vĩ Hoa.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「風暴將臨，貴在預備。資金深築防波之堤，合約嚴杜暗藏之弊。主動退步，以退為進，逢凶化吉，化險為夷。」
  > (Bão táp sắp tới, quý ở chỗ chuẩn bị trước. Dòng vốn đào sâu đê chắn sóng, hợp đồng kiểm tra kỹ tệ hại ngầm. Chủ động lùi bước, lấy lùi làm tiến, gặp hung hóa cát, biến hiểm thành an).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Dự Đoán Theo Tứ Trụ - Thiệu Vĩ Hoa.pdf`.
- **Vị trí áp dụng:** Tập 12, Chương VII, Mục 7.1.

---

### [REF-12-014]
- **Tiêu đề / Mệnh chủ:** Dự Báo Theo Tử Bình — Kỹ Thuật Chủ Động Ứng Hạn (Proactive Crisis Absorption)
- **Tác giả / Xuất xứ:** *Dự Báo Theo Tử Bình — Trần Khang Ninh.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「血光將見，獻血拔牙以應之；破財之運，布施修橋以應之；牢獄之象，閉門著書以應之。氣數流轉，借事洩機，造化難拘。」
  > (Huyết quang sắp thấy, hiến máu nhổ răng để ứng trước; Vận hạn phá tài, bố thí xây cầu để ứng trước; Hình tượng lao ngục, đóng cửa viết sách để ứng trước. Khí số lưu chuyển, mượn việc tiết lộ cơ trời, tạo hóa khó câu thúc).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Dự Báo Theo Tử Bình - Trần Khang Ninh.pdf`.
- **Vị trí áp dụng:** Tập 12, Chương VII, Mục 7.1.

---

### [REF-12-015]
- **Tiêu đề / Mệnh chủ:** Tử Bình Chân Thuyên Bình Chú — Bố Trí Nhân Sự C-Level Theo Thập Thần
- **Tác giả / Xuất xứ:** *Tử Bình Chân Thuyên Bình Chú — Từ Nhạc Ngô.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「食傷為將，拓土開疆；正印為相，輔弼安邦；正財掌樞，金匱深藏；七煞秉憲，風紀整肅。五星各正其位，天下自定。」
  > (Thực Thương làm tướng, mở cõi mở bờ; Chính Ấn làm tướng văn, phò tá yên nước; Chính Tài nắm then chốt, két vàng giấu sâu; Thất Sát nắm kỷ cương, phong kỷ nghiêm trang. Năm sao đều đúng vị trí của mình, thiên hạ tự khắc an định).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Tử Bình Chân Thuyên bình chú - Từ Nhạc Ngô.pdf`.
- **Vị trí áp dụng:** Tập 12, Chương VIII, Mục 8.1.

---

### [REF-12-016]
- **Tiêu đề / Mệnh chủ:** Thực Chiến Quản Trị Bát Tự — Chiến Lược Giải Quyết Khủng Hoảng Kế Vị F1 -> F2
- **Tác giả / Xuất xứ:** *Thực Chiến Lâm Sàng Quản Trị Doanh Nghiệp Doanh Nhân Việt Nam.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「創業以煞刃威權，守成以官印制度。父子相承，最忌性格相格。選承統之子，必取端正持重、制度明晰之人，方保百年不墜。」
  > (Khởi nghiệp dùng uy quyền Sát Nhận, thủ thành dùng chế độ Quan Ấn. Cha con trao truyền, tối kỵ tính khí va quẹt kẹp nhau. Chọn con kế nghiệp, ắt phải lấy người đoan chính đĩnh đạc, thể chế minh bạch, mới bảo đảm trăm năm không sụp đổ).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Thực Chiến Lâm Sàng Bát Tự Việt Nam`.
- **Vị trí áp dụng:** Tập 12, Chương VIII, Mục 8.2.

---

### [REF-12-017]
- **Tiêu đề / Mệnh chủ:** Hoàng Đế Nội Kinh & Mệnh Lý — Cấu Trúc Đơn Thuốc Phác Đồ Cải Mệnh Lâm Sàng
- **Tác giả / Xuất xứ:** *Hoàng Đế Nội Kinh Tố Vấn & Mệnh Lý Tật Bệnh Toàn Thư.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「病在五行，藥在六氣。虛則補之，實則瀉之，燥則濡之，寒則溫之。以自然之理療人身之疾，以天時之度解命運之結。」
  > (Bệnh ở ngũ hành, thuốc ở lục khí. Hư thì bồi bổ, thực thì tả bỏ, táo thì tưới mát, hàn thì sưởi ấm. Lấy lý tự nhiên chữa bệnh thân thể con người, lấy mức độ thời trời cởi nút thắt của vận mệnh).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Hoàng Đế Nội Kinh Tố Vấn`.
- **Vị trí áp dụng:** Tập 12, Chương IX, Mục 9.1.

---

### [REF-12-018]
- **Tiêu đề / Mệnh chủ:** Đại Toàn Cải Mệnh Phác Đồ — Toàn Thư 60 Phác Đồ Can Thiệp Ngũ Hành Lâm Sàng
- **Tác giả / Xuất xứ:** *Antigravity AI Bazi Clinical Prescriptions Canon.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「六十局勢，六十處方。窮通變化，條分縷析。或用移居，或用調業，或用法援，或用丹藥。對症施治，起死回生。」
  > (Sáu mươi cục diện, sáu mươi đơn thuốc. Cùng thông biến hóa, rành mạch từng sợi. Hoặc dùng di cư, hoặc dùng đổi nghề, hoặc dùng pháp lý cứu trợ, hoặc dùng thảo dược. Đúng chứng bốc thuốc, cứu người sống lại từ cõi chết).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Đại Toàn 60 Phác Đồ Cải Mệnh Antigravity`.
- **Vị trí áp dụng:** Tập 12, Chương IX, Mục 9.2.

---

### [REF-12-019]
- **Tiêu đề / Mệnh chủ:** Kho Benchmark 50 — 30 Kỳ Án Cải Mệnh & Đảo Ngược Vận Trình Lịch Sử
- **Tác giả / Xuất xứ:** *Antigravity Verified Ground-Truth Benchmark Repository.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「三十案例，歷歷可考。非弄虛作假之空談，皆實時對照之史實。絕處逢生，柳暗花明，皆人事有以操其權也。」
  > (Ba mươi ca án, rành mạch có thể khảo cứu. Không phải chuyện bịa đặt trống rỗng, đều là sử thực đối chiếu thời gian thật. Tuyệt xứ phùng sinh, liễu râm hoa rạng, đều do sức người nắm được quyền biến đổi vậy).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `10-kho-la-so-benchmark-quy-chuan.md`.
- **Vị trí áp dụng:** Tập 12, Chương X, Ca CM01 - CM30.

---

### [REF-12-020]
- **Tiêu đề / Mệnh chủ:** AI Bazi Analytics — Đánh Giá Biến Thiên Điểm Số GUFI Trước Và Sau Can Thiệp
- **Tác giả / Xuất xứ:** *Antigravity Grand Unified Fate Analytics Engine.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「量化評分，前後對比。未救之前，垂危四十；補偏之後，躍登八十。數理清晰，神功彰著，乃現代科技與傳統智慧之大成。」
  > (Điểm số lượng hóa, trước sau đối chiếu. Trước khi cứu, nguy kịch 40 điểm; sau khi sửa chữa, nhảy vọt lên 80 điểm. Số lý rành mạch, công năng thần diệu hiển lộ, là bước đại thành giữa công nghệ hiện đại và trí tuệ cổ truyền).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `grandUnifiedEngine.ts`.
- **Vị trí áp dụng:** Tập 12, Chương X, Mục 10.1.

---

### [REF-12-021]
- **Tiêu đề / Mệnh chủ:** Grand Unified Engine — Mã Nguồn TypeScript Chuẩn Doanh Nghiệp
- **Tác giả / Xuất xứ:** *Antigravity Enterprise Engineering Standard.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「演算精準，程式嚴整。型別定義分明，權重加權明確。為當代AI智能代理提供堅實之數理基石。」
  > (Thuật toán chuẩn xác, chương trình nghiêm ngặt. Định nghĩa kiểu dữ liệu rành mạch, trọng số gia quyền rõ ràng. Cung cấp nền tảng số lý vững chắc cho các AI Agent thông minh đương đại).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `grandUnifiedEngine.ts`.
- **Vị trí áp dụng:** Tập 12, Chương XI, Mục 11.1.

---

### [REF-12-022]
- **Tiêu đề / Mệnh chủ:** Liễu Phàm Tứ Huấn — Cương Lĩnh Lập Mệnh, Cải Quá, Tích Thiện, Khiêm Đức
- **Tác giả / Xuất xứ:** *Liễu Phàm Tứ Huấn — Viên Liễu Phàm (Thời Minh).*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「造命者在天，立命者在人。改過有三心，積善有百行。唯謙受福，地山流光。千古家訓，救拔萬生。」
  > (Tạo mệnh ở trời, lập mệnh ở người. Sửa lỗi có ba tâm, tích thiện có trăm nết. Duy đức khiêm hạ đón nhận phước lành, Địa Sơn Khiêm tỏa sáng rực rỡ. Lời răn gia đình ngàn đời, cứu vớt muôn sinh mạng).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Liễu Phàm Tứ Huấn`.
- **Vị trí áp dụng:** Tập 12, Chương XII, Mục 12.1.

---

### [REF-12-023]
- **Tiêu đề / Mệnh chủ:** Kinh Dịch Khôn Quái Văn Ngôn — Tích Thiện Dư Khánh & Đức Năng Thắng Số
- **Tác giả / Xuất xứ:** *Kinh Dịch — Khổng Tử Tán Dịch & Chu Hi Bản Nghĩa.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「積善之家，必有餘慶；積不善之家，必有餘殃。臣弒其君，子弒其父，非一朝一夕之故，其所由來者漸矣。」
  > (Nhà tích chứa điều thiện ắt có thừa niềm vui phúc báu; nhà tích chứa điều bất thiện ắt có thừa tai ương hoạn nạn. Bầy tôi giết vua, con giết cha, không phải chuyện của một sớm một chiều, mà nguyên do tích lũy dần dần từ trước vậy).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Kinh Dịch Chu Hi Bản Nghĩa`.
- **Vị trí áp dụng:** Tập 12, Chương XII, Mục 12.1.

---

### [REF-12-024]
- **Tiêu đề / Mệnh chủ:** Bách Gia Khẩu Quyết Toàn Thư — 100 Khẩu Quyết Vàng Cải Mệnh & Quản Trị
- **Tác giả / Xuất xứ:** *Bách Gia Mệnh Lý Khẩu Quyết Toàn Thư.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「百條口訣，字現金光。傳之仁人，救亡圖存；若付匪類，反害生靈。慎之戒之，世世遵守。」
  > (Trăm câu khẩu quyết, chữ hiện ánh vàng. Truyền cho người nhân từ, cứu vớt sinh linh nguy khốn; nếu trao vào tay kẻ bất lương, phản lại làm hại thế gian. Cẩn thận răn đe, đời đời tuân thủ).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Tổng hợp khẩu quyết 16 bộ kinh điển`.
- **Vị trí áp dụng:** Tập 12, Chương XIII, Khẩu quyết 01 - 100.

---

### [REF-12-025]
- **Tiêu đề / Mệnh chủ:** Cổ Thi Mệnh Lý Tuyệt Phẩm — 15 Bài Thơ Phú Triết Lý Lập Mệnh 5 Tầng
- **Tác giả / Xuất xứ:** *Cổ Thi Mệnh Lý Tuyệt Phẩm Tập.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「詩賦精微，文質彬彬。五層注解，直達心源。歌以詠志，詩以通幽。學士之模範，國師之寶笈。」
  > (Thơ phú tinh vi, văn chất rạng ngời. Năm tầng chú giải, thấu thẳng tâm nguồn. Hát để bày tỏ chí hướng, ngâm thơ để thông cõi u vi. Khuôn mẫu của bậc văn nhân, bảo bối quý giá của hàng Quốc Sư).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Cổ Thi Mệnh Lý Tuyệt Phẩm`.
- **Vị trí áp dụng:** Tập 12, Chương XIV, Bài CT01 - CT15.

---

### [REF-12-026]
- **Tiêu đề / Mệnh chủ:** Tổng Kết 16 Tác Phẩm Input — Ma Trận Tích Hợp Vào 12 Tập Giáo Trình
- **Tác giả / Xuất xứ:** *Antigravity Bazi Master Reference Integration Matrix.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「十六名著，各擅勝場。子平為骨，盲派為翼。貫通古今，集其大成。立千古之宗風，垂萬世之典範。」
  > (Mười sáu danh tác, mỗi bộ chiếm một thế mạnh. Tử Bình làm xương sống, Manh phái làm đôi cánh. Thông suốt cổ kim, tập hợp thành bước đại thành. Lập nên tông phong ngàn đời, lưu truyền khuôn mẫu vạn thế).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Input/Tài liệu/ 16 tệp sách gốc`.
- **Vị trí áp dụng:** Tập 12, Chương XV, Mục 15.1.

---

### [REF-12-027]
- **Tiêu đề / Mệnh chủ:** Đại Chuyên Khảo Mệnh Lý — 10 Chuyên Luận Học Thuật Đại Kết Tinh
- **Tác giả / Xuất xứ:** *Antigravity Master Scholarly Monographs.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「十篇宏論，高屋建瓴。辨明正邪，廓清迷霧。使易理重光於宇內，使術數立足於科學。」
  > (Mười bài chuyên luận vĩ đại, đứng trên đỉnh cao nhìn thấu suốt. Phân biệt rõ chính tà, quét sạch sương mù tăm tối. Làm cho Dịch lý tỏa sáng trở lại giữa cõi trần gian, làm cho thuật số đứng vững chắc trên nền tảng khoa học).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Đại Chuyên Khảo Toàn Thư`.
- **Vị trí áp dụng:** Tập 12, Chương XV, Mục 15.2.

---

### [REF-12-028]
- **Tiêu đề / Mệnh chủ:** Antigravity Knowledge Graph — Bản Đồ Toàn Cảnh Tri Thức Bát Tự Tử Bình v2.0
- **Tác giả / Xuất xứ:** *Antigravity Architecture Core Team.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「知識圖譜，縱橫交錯。節氣為脈，干支為格。萬象歸原，一覽無餘。」
  > (Bản đồ tri thức, dọc ngang đan dệt. Tiết khí làm mạch nguồn, can chi làm khung lưới. Vạn tượng quy về gốc, nhìn một cái là thấy trọn vẹn).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `tong-ket-bat-tu-tu-binh-master-skill.md`.
- **Vị trí áp dụng:** Tập 12, Chương XV, Mục 15.2.

---

### [REF-12-029]
- **Tiêu đề / Mệnh chủ:** SKILL.md Extended Thinking — Quy Trình SOP 10 Bước Tham Vấn Bậc Quốc Sư
- **Tác giả / Xuất xứ:** *Antigravity System Prompt & Skill Architecture.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「十步推演，條理井然。自天文以至人事，由 nguyên cục dĩ chí ứng kỳ. 慎終如始，則無敗事。」
  > (Mười bước suy diễn, mạch lạc lớp lang. Từ thiên văn cho tới nhân sự, từ nguyên cục cho tới ứng kỳ. Cẩn trọng từ đầu tới cuối như một, thì không bao giờ hỏng việc).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `Output/bat-tu/SKILL.md`.
- **Vị trí áp dụng:** Tập 12, Chương XVI, Mục 16.2.

---

### [REF-12-030]
- **Tiêu đề / Mệnh chủ:** Tuyên Ngôn Đạo Đức Mệnh Lý Học — Lời Bạt Đại Kết Quyển Toàn Bộ 12 Tập
- **Tác giả / Xuất xứ:** *Antigravity Ethics and Humanistic Governance Canon.*
- **Văn bản Hán cổ & Dịch nghĩa:**
  > 「知命而立，順天休命。行仁仗義，兼濟天下。十二卷書成之日，海晏河清，萬民樂業，易道之極致也。」
  > (Biết mệnh mà lập thân, thuận theo lẽ trời làm điều tốt đẹp cho sinh mệnh. Hành nhân trượng nghĩa, giúp đỡ trọn vẹn cho thiên hạ. Ngày mười hai tập sách hoàn thành, biển yên sông lặng, vạn dân an cư lạc nghiệp, đây chính là cảnh giới tột cùng của đạo Dịch).
- **Cơ sở dữ liệu số:** [ctext.org](https://ctext.org | Wikisource: https://zh.wikisource.org) | Wikisource: [zh.wikisource.org](https://ctext.org | Wikisource: https://zh.wikisource.org).
- **File đối chiếu nội bộ:** `12-dai-thanh-tong-hop-cai-menh.md`.
- **Vị trí áp dụng:** Tập 12, Chương XVI, Mục 16.4.

---
